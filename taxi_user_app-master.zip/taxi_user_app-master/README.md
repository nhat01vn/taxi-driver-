# futter_user

## Project setup

### 1. Install [Flutter for macOS](https://docs.flutter.dev/get-started/install/macos)

### 2. Install [Xcode](https://apps.apple.com/us/app/xcode/id497799835?mt=12) and [Android Studio](https://developer.android.com/studio)

### 3. Export PATH

```bash
~/.zshrc

export ANDROID_HOME="$HOME/Library/Android/sdk"
export PATH="$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/tools/bin:$ANDROID_HOME/platform-tools"
export PATH="$PATH:$HOME/flutter/bin"
```

### 4. Fix environment errors

```bash
flutter doctor
```

### 5. Install [Git Large File Storage](https://docs.github.com/en/repositories/working-with-files/managing-large-files/installing-git-large-file-storage)

### 6. Generate localization files (l10n)

```bash
flutter gen-l10n
```

### 7. Regenerate Database schema

- Open `pubspec.yaml` and turn `generate` to `false`
- Then run

```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

- Then turn `generate` back to `true`

### 8. In-App Purchases

#### iOS

- Navigate to folder `ios`
- Open `Runner.xcworkspace` (using Xcode)
- Open Terminal and run `pod install`
- Deploy the app to iOS Simulator 1 time to make sure the Testing Configuration for In-App Purchase works
- Also every time you delete the app on the device, you need to do this again

#### Android

- Will update later

### 9. Lints

```bash
flutter analyze
```

### 10. IDEs

#### Plugins for Android Studio

- [Dart](https://plugins.jetbrains.com/plugin/6351-dart)
- [Flutter](https://plugins.jetbrains.com/plugin/9212-flutter)
- [Flutter Riverpod Snippets](https://plugins.jetbrains.com/plugin/14641-flutter-riverpod-snippets)
- [Flutter Snippets](https://plugins.jetbrains.com/plugin/12348-flutter-snippets)
- [Dart Data Class](https://plugins.jetbrains.com/plugin/12429-dart-data-class)
- [ktfmt](https://plugins.jetbrains.com/plugin/14912-ktfmt)

#### Extensions for Visual Studio Code

- [Dart](https://marketplace.visualstudio.com/items?itemName=Dart-Code.dart-code)
- [Dart Data Class Generator](https://marketplace.visualstudio.com/items?itemName=hzgood.dart-data-class-generator)
- [Error Lens](https://marketplace.visualstudio.com/items?itemName=usernamehw.errorlens)
- [Flutter](https://marketplace.visualstudio.com/items?itemName=Dart-Code.flutter)
- [Flutter Widget Snippets](https://marketplace.visualstudio.com/items?itemName=alexisvt.flutter-snippets)
- [File Watcher](https://marketplace.visualstudio.com/items?itemName=appulate.filewatcher)

#### Setting for Visual Studio Code

```json
{
  "debug.openDebug": "openOnDebugBreak",
  "debug.internalConsoleOptions": "openOnSessionStart",
  "dart.previewFlutterUiGuides": true,
  "dart.openDevTools": "flutter",
  "dart.debugExternalPackageLibraries": false,
  "dart.debugSdkLibraries": false,
  "[dart]": {
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
      "source.fixAll": true
    },
    "editor.selectionHighlight": false,
    "editor.suggest.snippetsPreventQuickSuggestions": false,
    "editor.suggestSelection": "first",
    "editor.tabCompletion": "onlySnippets",
    "editor.wordBasedSuggestions": false
  },
  "filewatcher.commands": [
    {
      // Watch localization files was changed and re-generated
      "match": ".*\/l10n\/app_.*.arb",
      "isAsync": true,
      "cmd": "cd ${workspaceRoot} && flutter gen-l10n",
      "event": "onFileChange"
    },
  ],
}
```

### 11. Clean Pub Cache

```bash
rm -r /Users/username/.pub-cache
```

### 12. Change App Icons

```bash
flutter pub run flutter_launcher_icons
```
