import 'package:flutter_svg/svg.dart';
import 'package:flutter/material.dart';
import 'package:futter_user/src/core/constants/app_color.dart';

class ImageHelper {
  ImageHelper(String icoConversation);

  static Widget loadFromAsset(
    String imageFilePath, {
    double? width,
    double? height,
    BorderRadius? radius,
    BoxFit? fit,
    Color? tintColor,
    Alignment? alignment,
  }) {
    if (imageFilePath.toLowerCase().endsWith('svg')) {
      return ClipRRect(
        borderRadius: radius ?? BorderRadius.zero,
        child: SvgPicture.asset(
          imageFilePath,
          width: width,
          height: height,
          fit: fit ?? BoxFit.contain,
          alignment: alignment ?? Alignment.center,
          colorFilter:
              ColorFilter.mode(tintColor ?? AppColor.white, BlendMode.srcIn),
        ),
      );
    } else {
      return ClipRRect(
        borderRadius: radius ?? BorderRadius.zero,
        child: Image.asset(
          imageFilePath,
          width: width,
          height: height,
          fit: fit ?? BoxFit.contain,
          color: tintColor,
          alignment: alignment ?? Alignment.center,
        ),
      );
    }
  }
}
