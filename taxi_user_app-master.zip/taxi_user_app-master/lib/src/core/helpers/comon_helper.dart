import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/constants/app_config.dart';
import 'package:futter_user/src/data_sample/variable.dart';
import 'package:futter_user/src/domain/address_model.dart';
import 'package:futter_user/src/domain/direction_details_model.dart';
import 'package:futter_user/src/domain/online_nearby_drivers.dart';
import 'package:futter_user/src/presentation/controllers/app_info.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;

class CommonHelper {
  checkConnectivity(BuildContext context) async {
    var connectionResult = await Connectivity().checkConnectivity();

    if (connectionResult != ConnectivityResult.mobile &&
        connectionResult != ConnectivityResult.wifi) {
      if (!context.mounted) return;
      displaySnackBar(
        'your Internet is not Available. Check your connection. Try Again.',
        context,
      );
    }
  }

  displaySnackBar(String messageText, BuildContext context) {
    var snackBar = SnackBar(content: Text(messageText));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  static sendRequestToAPI(String apiUrl) async {
    http.Response responseFromAPI = await http.get(Uri.parse(apiUrl));

    try {
      if (responseFromAPI.statusCode == 200) {
        String dataFromApi = responseFromAPI.body;
        var dataDecoded = jsonDecode(dataFromApi);
        return dataDecoded;
      } else {
        return 'error';
      }
    } catch (errorMsg) {
      return 'error';
    }
  }

  ///Reverse GeoCoding
  static Future<void> convertGeoGraphicCoOrdinatesIntoHumanReadableAddress(
    Position position,
    BuildContext context,
    WidgetRef ref,
  ) async {
    AddressModel model = AddressModel();
    String apiGeoCodingUrl =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=$googleMapKey';

    // TODO for debug
    Map responseFromAPI =
        convertGeoGraphicCoOrdinatesIntoHumanReadableAddressData;
    // var responseFromAPI = await sendRequestToAPI(apiGeoCodingUrl);

    if (responseFromAPI != 'error') {
      String humanReadableAddress =
          responseFromAPI['results'][0]['formatted_address'];

      model.humanReadableAddress = humanReadableAddress;
      model.placeName = humanReadableAddress;
      model.longitudePosition = position.longitude;
      model.latitudePosition = position.latitude;
      ref.read(appInfoControllerProvider.notifier).updatePickUpLocation(model);
    }

    return;
  }

  ///Directions API
  static Future<DirectionDetailsModel?> getDirectionDetailsFromAPI(
    LatLng source,
    LatLng destination, {
    int test = 1,
  }) async {
    String urlDirectionsAPI =
        'https://maps.googleapis.com/maps/api/directions/json?destination=${destination.latitude},${destination.longitude}&origin=${source.latitude},${source.longitude}&mode=driving&key=$googleMapKey';

    // TODO for debug
    Map responseFromDirectionsAPI;
    if (test == 1) {
      responseFromDirectionsAPI = getDirectionDetailsFromAPIDataFromUserToDes;
    } else {
      responseFromDirectionsAPI =
          getDirectionDetailsFromAPIDataFromDriverToUser;
    }
    // var responseFromDirectionsAPI = await sendRequestToAPI(urlDirectionsAPI);

    if (responseFromDirectionsAPI == 'error') {
      return null;
    }

    DirectionDetailsModel detailsModel = DirectionDetailsModel();

    detailsModel.distanceTextString =
        responseFromDirectionsAPI['routes'][0]['legs'][0]['distance']['text'];
    detailsModel.distanceValueDigits =
        responseFromDirectionsAPI['routes'][0]['legs'][0]['distance']['value'];

    detailsModel.durationTextString =
        responseFromDirectionsAPI['routes'][0]['legs'][0]['duration']['text'];
    detailsModel.durationValueDigits =
        responseFromDirectionsAPI['routes'][0]['legs'][0]['duration']['value'];

    detailsModel.encodedPoints =
        responseFromDirectionsAPI['routes'][0]['overview_polyline']['points'];

    return detailsModel;
  }

  calculateFareAmount(DirectionDetailsModel directionDetails) {
    double distancePerKmAmount = 0.4;
    double durationPerMinuteAmount = 0.3;
    double baseFareAmount = 2;

    double totalDistanceTravelFareAmount =
        (directionDetails.distanceValueDigits! / 1000) * distancePerKmAmount;
    double totalDurationSpendFareAmount =
        (directionDetails.durationValueDigits! / 60) * durationPerMinuteAmount;

    double overAllTotalFareAmount = baseFareAmount +
        totalDistanceTravelFareAmount +
        totalDurationSpendFareAmount;

    return overAllTotalFareAmount.toStringAsFixed(2);
  }

  static List<OnlineNearbyDrivers> nearbyOnlineDriversList = [];

  static void removeDriverFromList(String driverID) {
    int index = nearbyOnlineDriversList
        .indexWhere((driver) => driver.uidDriver == driverID);

    if (nearbyOnlineDriversList.isNotEmpty) {
      nearbyOnlineDriversList.removeAt(index);
    }
  }

  static void updateOnlineNearbyDriversLocation(
    OnlineNearbyDrivers nearbyOnlineDriverInformation,
  ) {
    int index = nearbyOnlineDriversList.indexWhere(
      (driver) => driver.uidDriver == nearbyOnlineDriverInformation.uidDriver,
    );

    nearbyOnlineDriversList[index].latDriver =
        nearbyOnlineDriverInformation.latDriver;
    nearbyOnlineDriversList[index].lngDriver =
        nearbyOnlineDriverInformation.lngDriver;
  }
}
