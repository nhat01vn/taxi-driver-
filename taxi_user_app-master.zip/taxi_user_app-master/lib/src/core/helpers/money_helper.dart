import 'dart:io';
import 'package:intl/intl.dart';

class Money {
  num value = 0;

  Money(this.value);

  display({String? currency, bool isShowSymbol = true}) {
    return _currencyByLocale(
      currency ?? Platform.localeName,
      isShowSymbol: isShowSymbol,
    ).format(value);
  }

  NumberFormat _currencyByLocale(String currency, {bool isShowSymbol = true}) {
    switch (currency.toString().toLowerCase()) {
      case 'en':
      case 'usd':
        return NumberFormat.currency(
          name: 'USD',
          decimalDigits: 2,
          symbol: isShowSymbol ? '\$' : '',
        );
      case 'ja':
      case 'jpy':
        return NumberFormat.currency(
          name: 'JPY',
          decimalDigits: 0,
          symbol: isShowSymbol ? '¥' : '',
        );
      case 'vi':
      case 'vnd':
        return NumberFormat.currency(
          decimalDigits: 0,
          customPattern: isShowSymbol ? '#,### đ' : '#,###',
        );
      default:
        return NumberFormat.simpleCurrency(locale: 'EN-us', decimalDigits: 2);
    }
  }
}
