import 'package:easy_localization/easy_localization.dart';

class ErrorPresenters {
  static String? errorDisplay(dynamic errors, String key, [String? fieldName]) {
    if (errors != null &&
        errors['details'] != null &&
        errors['details'][key] != null) {
      List<String> fullErrorMessages =
          errors['details'][key].map<String>((fieldError) {
        final field = fieldName ?? convertSnakeCaseToTitleCase(key);
        final message = 'serverErrors.types.${fieldError['error']}'.tr(
          namedArgs: {'length': fieldError['count'].toString()},
        );
        return '$field $message';
      }).toList();
      return fullErrorMessages.join(', ');
    }
    return null;
  }

  static String convertSnakeCaseToTitleCase(String input) {
    List<String> words = input.split('_');
    String result = '';
    for (String word in words) {
      if (word.isNotEmpty) {
        if (result.isNotEmpty) {
          result += ' ';
        }
        result += word[0].toUpperCase() + word.substring(1);
      }
    }
    return result;
  }
}
