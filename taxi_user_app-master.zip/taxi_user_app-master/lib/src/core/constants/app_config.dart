import 'package:futter_user/src/domain/user.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

String googleMapKey = 'AIzaSyBX4Lgs9JjEONsbApnU6Xy3bA-_6vTyQoI';
String serverKeyFCM =
    'key=AAAAb_rhw5s:APA91bHIoM9njarX7WIxJpW-8FjBmXBXF2iVQSm3SBpnRGp2SpkdTFNlqwTb9Hh75qjKc93P1WqRh1y7MdD05J1zo62zbd_eJ19nLFeFMaEFoQwO0ox3jyPQHo61gGZ38zUl79VYC4GL';

const CameraPosition googlePlexInitialPosition = CameraPosition(
  target: LatLng(10.76295706120165, 106.68246310611696),
  zoom: 14.4746,
);

User? currentUser;
String userName = '';
String userPhone = '';
String userID = '';

String nameDriver = '';
String photoDriver = '';
String phoneNumberDriver = '';
int requestTimeoutDriver = 20;
String status = '';
String carDetailsDriver = '';
String tripStatusDisplay = 'Driver is Arriving';
