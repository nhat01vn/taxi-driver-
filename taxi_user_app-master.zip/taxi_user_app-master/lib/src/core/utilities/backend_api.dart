// ignore_for_file: public_member_api_docs, sort_constructors_first

import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:japx/japx.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

String httpUrl =
    Platform.isIOS ? 'http://localhost:5001' : 'http://10.0.2.2:5001/';
String baseUrl = kDebugMode ? httpUrl : 'https://production-api.com/';

class BackendAPI {
  BackendAPI(
    this.method,
    this.path, {
    this.data,
    this.headers,
    this.options,
  });

  final String method;
  final String path;
  Map<String, dynamic>? data;
  Map<String, dynamic>? headers;
  Map<String, dynamic>? options;

  final _dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
    ),
  );

  static Future<Map<String, dynamic>> makeRequest(
    String method,
    String path, {
    Map<String, dynamic>? data,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? options,
  }) async {
    return BackendAPI(
      method,
      path,
      data: data,
      headers: headers,
      options: options,
    ).request();
  }

  Future<Map<String, dynamic>> request() async {
    _initLogger();
    try {
      final response = await _dio.request(
        path,
        data: _requestData(),
        options: Options(
          method: method.toString(),
          headers: await _requestHeaders(),
        ),
      );

      var json = response.data;
      if (_requestOptions()['isJsonAPI']) {
        json = Japx.decode(json, includeList: includeList());
      }

      return Future.value(json);
    } on DioException catch (e) {
      if (e.response != null) {
        return Future.error(e.response?.data);
      } else {
        return Future.error(e);
      }
    }
  }

  Object? _requestData() {
    if ((data ?? {}).isEmpty) return null;

    return json.encode(data);
  }

  String includeList() {
    if ((data ?? {}).isEmpty) return '';
    if (!data!.keys.contains('include')) return '';

    return data!['include'];
  }

  Map<String, dynamic> _requestOptions() {
    return {
      'isJsonAPI': false,
      ...options ?? {},
    };
  }

  Future<Map<String, String>> _requestHeaders() async {
    return {
      'Accept': 'application/json',
      'Content-type': 'application/json',
      ...await _userTokenHeaders(),
      ...headers ?? {},
    };
  }

  Future<Map<String, String>> _userTokenHeaders() async {
    final userToken = await localStorage.loadUserToken();

    return {'Api-Token': userToken.token};
  }

  _initLogger() {
    if (!kDebugMode) return;

    _dio.interceptors.add(
      PrettyDioLogger(
        requestHeader: true,
        requestBody: true,
        responseBody: true,
        responseHeader: false,
        error: true,
        compact: true,
        maxWidth: 90,
      ),
    );
  }
}
