// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ICreateUserParams {
  String get name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String get password => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $ICreateUserParamsCopyWith<ICreateUserParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ICreateUserParamsCopyWith<$Res> {
  factory $ICreateUserParamsCopyWith(
          ICreateUserParams value, $Res Function(ICreateUserParams) then) =
      _$ICreateUserParamsCopyWithImpl<$Res, ICreateUserParams>;
  @useResult
  $Res call({String name, String email, String phone, String password});
}

/// @nodoc
class _$ICreateUserParamsCopyWithImpl<$Res, $Val extends ICreateUserParams>
    implements $ICreateUserParamsCopyWith<$Res> {
  _$ICreateUserParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? password = null,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ICreateUserParamsImplCopyWith<$Res>
    implements $ICreateUserParamsCopyWith<$Res> {
  factory _$$ICreateUserParamsImplCopyWith(_$ICreateUserParamsImpl value,
          $Res Function(_$ICreateUserParamsImpl) then) =
      __$$ICreateUserParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String email, String phone, String password});
}

/// @nodoc
class __$$ICreateUserParamsImplCopyWithImpl<$Res>
    extends _$ICreateUserParamsCopyWithImpl<$Res, _$ICreateUserParamsImpl>
    implements _$$ICreateUserParamsImplCopyWith<$Res> {
  __$$ICreateUserParamsImplCopyWithImpl(_$ICreateUserParamsImpl _value,
      $Res Function(_$ICreateUserParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? password = null,
  }) {
    return _then(_$ICreateUserParamsImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ICreateUserParamsImpl implements _ICreateUserParams {
  _$ICreateUserParamsImpl(
      {required this.name,
      required this.email,
      required this.phone,
      required this.password});

  @override
  final String name;
  @override
  final String email;
  @override
  final String phone;
  @override
  final String password;

  @override
  String toString() {
    return 'ICreateUserParams(name: $name, email: $email, phone: $phone, password: $password)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ICreateUserParamsImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.password, password) ||
                other.password == password));
  }

  @override
  int get hashCode => Object.hash(runtimeType, name, email, phone, password);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ICreateUserParamsImplCopyWith<_$ICreateUserParamsImpl> get copyWith =>
      __$$ICreateUserParamsImplCopyWithImpl<_$ICreateUserParamsImpl>(
          this, _$identity);
}

abstract class _ICreateUserParams implements ICreateUserParams {
  factory _ICreateUserParams(
      {required final String name,
      required final String email,
      required final String phone,
      required final String password}) = _$ICreateUserParamsImpl;

  @override
  String get name;
  @override
  String get email;
  @override
  String get phone;
  @override
  String get password;
  @override
  @JsonKey(ignore: true)
  _$$ICreateUserParamsImplCopyWith<_$ICreateUserParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IFetchUserParams {
  String get id => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IFetchUserParamsCopyWith<IFetchUserParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IFetchUserParamsCopyWith<$Res> {
  factory $IFetchUserParamsCopyWith(
          IFetchUserParams value, $Res Function(IFetchUserParams) then) =
      _$IFetchUserParamsCopyWithImpl<$Res, IFetchUserParams>;
  @useResult
  $Res call({String id});
}

/// @nodoc
class _$IFetchUserParamsCopyWithImpl<$Res, $Val extends IFetchUserParams>
    implements $IFetchUserParamsCopyWith<$Res> {
  _$IFetchUserParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IFetchUserParamsImplCopyWith<$Res>
    implements $IFetchUserParamsCopyWith<$Res> {
  factory _$$IFetchUserParamsImplCopyWith(_$IFetchUserParamsImpl value,
          $Res Function(_$IFetchUserParamsImpl) then) =
      __$$IFetchUserParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String id});
}

/// @nodoc
class __$$IFetchUserParamsImplCopyWithImpl<$Res>
    extends _$IFetchUserParamsCopyWithImpl<$Res, _$IFetchUserParamsImpl>
    implements _$$IFetchUserParamsImplCopyWith<$Res> {
  __$$IFetchUserParamsImplCopyWithImpl(_$IFetchUserParamsImpl _value,
      $Res Function(_$IFetchUserParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
  }) {
    return _then(_$IFetchUserParamsImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IFetchUserParamsImpl implements _IFetchUserParams {
  _$IFetchUserParamsImpl({required this.id});

  @override
  final String id;

  @override
  String toString() {
    return 'IFetchUserParams(id: $id)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IFetchUserParamsImpl &&
            (identical(other.id, id) || other.id == id));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IFetchUserParamsImplCopyWith<_$IFetchUserParamsImpl> get copyWith =>
      __$$IFetchUserParamsImplCopyWithImpl<_$IFetchUserParamsImpl>(
          this, _$identity);
}

abstract class _IFetchUserParams implements IFetchUserParams {
  factory _IFetchUserParams({required final String id}) =
      _$IFetchUserParamsImpl;

  @override
  String get id;
  @override
  @JsonKey(ignore: true)
  _$$IFetchUserParamsImplCopyWith<_$IFetchUserParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IFetchDriverParams {
  String get uid => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IFetchDriverParamsCopyWith<IFetchDriverParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IFetchDriverParamsCopyWith<$Res> {
  factory $IFetchDriverParamsCopyWith(
          IFetchDriverParams value, $Res Function(IFetchDriverParams) then) =
      _$IFetchDriverParamsCopyWithImpl<$Res, IFetchDriverParams>;
  @useResult
  $Res call({String uid});
}

/// @nodoc
class _$IFetchDriverParamsCopyWithImpl<$Res, $Val extends IFetchDriverParams>
    implements $IFetchDriverParamsCopyWith<$Res> {
  _$IFetchDriverParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? uid = null,
  }) {
    return _then(_value.copyWith(
      uid: null == uid
          ? _value.uid
          : uid // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IFetchDriverParamsImplCopyWith<$Res>
    implements $IFetchDriverParamsCopyWith<$Res> {
  factory _$$IFetchDriverParamsImplCopyWith(_$IFetchDriverParamsImpl value,
          $Res Function(_$IFetchDriverParamsImpl) then) =
      __$$IFetchDriverParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String uid});
}

/// @nodoc
class __$$IFetchDriverParamsImplCopyWithImpl<$Res>
    extends _$IFetchDriverParamsCopyWithImpl<$Res, _$IFetchDriverParamsImpl>
    implements _$$IFetchDriverParamsImplCopyWith<$Res> {
  __$$IFetchDriverParamsImplCopyWithImpl(_$IFetchDriverParamsImpl _value,
      $Res Function(_$IFetchDriverParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? uid = null,
  }) {
    return _then(_$IFetchDriverParamsImpl(
      uid: null == uid
          ? _value.uid
          : uid // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IFetchDriverParamsImpl implements _IFetchDriverParams {
  _$IFetchDriverParamsImpl({required this.uid});

  @override
  final String uid;

  @override
  String toString() {
    return 'IFetchDriverParams(uid: $uid)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IFetchDriverParamsImpl &&
            (identical(other.uid, uid) || other.uid == uid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, uid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IFetchDriverParamsImplCopyWith<_$IFetchDriverParamsImpl> get copyWith =>
      __$$IFetchDriverParamsImplCopyWithImpl<_$IFetchDriverParamsImpl>(
          this, _$identity);
}

abstract class _IFetchDriverParams implements IFetchDriverParams {
  factory _IFetchDriverParams({required final String uid}) =
      _$IFetchDriverParamsImpl;

  @override
  String get uid;
  @override
  @JsonKey(ignore: true)
  _$$IFetchDriverParamsImplCopyWith<_$IFetchDriverParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IUpdateDriverParams {
  String get id => throw _privateConstructorUsedError;
  String? get newTripStatus => throw _privateConstructorUsedError;
  double? get lat => throw _privateConstructorUsedError;
  double? get long => throw _privateConstructorUsedError;
  String? get deviceToken => throw _privateConstructorUsedError;
  String? get status => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IUpdateDriverParamsCopyWith<IUpdateDriverParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IUpdateDriverParamsCopyWith<$Res> {
  factory $IUpdateDriverParamsCopyWith(
          IUpdateDriverParams value, $Res Function(IUpdateDriverParams) then) =
      _$IUpdateDriverParamsCopyWithImpl<$Res, IUpdateDriverParams>;
  @useResult
  $Res call(
      {String id,
      String? newTripStatus,
      double? lat,
      double? long,
      String? deviceToken,
      String? status});
}

/// @nodoc
class _$IUpdateDriverParamsCopyWithImpl<$Res, $Val extends IUpdateDriverParams>
    implements $IUpdateDriverParamsCopyWith<$Res> {
  _$IUpdateDriverParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? newTripStatus = freezed,
    Object? lat = freezed,
    Object? long = freezed,
    Object? deviceToken = freezed,
    Object? status = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      newTripStatus: freezed == newTripStatus
          ? _value.newTripStatus
          : newTripStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double?,
      long: freezed == long
          ? _value.long
          : long // ignore: cast_nullable_to_non_nullable
              as double?,
      deviceToken: freezed == deviceToken
          ? _value.deviceToken
          : deviceToken // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IUpdateDriverParamsImplCopyWith<$Res>
    implements $IUpdateDriverParamsCopyWith<$Res> {
  factory _$$IUpdateDriverParamsImplCopyWith(_$IUpdateDriverParamsImpl value,
          $Res Function(_$IUpdateDriverParamsImpl) then) =
      __$$IUpdateDriverParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String? newTripStatus,
      double? lat,
      double? long,
      String? deviceToken,
      String? status});
}

/// @nodoc
class __$$IUpdateDriverParamsImplCopyWithImpl<$Res>
    extends _$IUpdateDriverParamsCopyWithImpl<$Res, _$IUpdateDriverParamsImpl>
    implements _$$IUpdateDriverParamsImplCopyWith<$Res> {
  __$$IUpdateDriverParamsImplCopyWithImpl(_$IUpdateDriverParamsImpl _value,
      $Res Function(_$IUpdateDriverParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? newTripStatus = freezed,
    Object? lat = freezed,
    Object? long = freezed,
    Object? deviceToken = freezed,
    Object? status = freezed,
  }) {
    return _then(_$IUpdateDriverParamsImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      newTripStatus: freezed == newTripStatus
          ? _value.newTripStatus
          : newTripStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double?,
      long: freezed == long
          ? _value.long
          : long // ignore: cast_nullable_to_non_nullable
              as double?,
      deviceToken: freezed == deviceToken
          ? _value.deviceToken
          : deviceToken // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$IUpdateDriverParamsImpl implements _IUpdateDriverParams {
  _$IUpdateDriverParamsImpl(
      {required this.id,
      this.newTripStatus,
      this.lat,
      this.long,
      this.deviceToken,
      this.status});

  @override
  final String id;
  @override
  final String? newTripStatus;
  @override
  final double? lat;
  @override
  final double? long;
  @override
  final String? deviceToken;
  @override
  final String? status;

  @override
  String toString() {
    return 'IUpdateDriverParams(id: $id, newTripStatus: $newTripStatus, lat: $lat, long: $long, deviceToken: $deviceToken, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IUpdateDriverParamsImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.newTripStatus, newTripStatus) ||
                other.newTripStatus == newTripStatus) &&
            (identical(other.lat, lat) || other.lat == lat) &&
            (identical(other.long, long) || other.long == long) &&
            (identical(other.deviceToken, deviceToken) ||
                other.deviceToken == deviceToken) &&
            (identical(other.status, status) || other.status == status));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, id, newTripStatus, lat, long, deviceToken, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IUpdateDriverParamsImplCopyWith<_$IUpdateDriverParamsImpl> get copyWith =>
      __$$IUpdateDriverParamsImplCopyWithImpl<_$IUpdateDriverParamsImpl>(
          this, _$identity);
}

abstract class _IUpdateDriverParams implements IUpdateDriverParams {
  factory _IUpdateDriverParams(
      {required final String id,
      final String? newTripStatus,
      final double? lat,
      final double? long,
      final String? deviceToken,
      final String? status}) = _$IUpdateDriverParamsImpl;

  @override
  String get id;
  @override
  String? get newTripStatus;
  @override
  double? get lat;
  @override
  double? get long;
  @override
  String? get deviceToken;
  @override
  String? get status;
  @override
  @JsonKey(ignore: true)
  _$$IUpdateDriverParamsImplCopyWith<_$IUpdateDriverParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IForgotPasswordParams {
  String get email => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IForgotPasswordParamsCopyWith<IForgotPasswordParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IForgotPasswordParamsCopyWith<$Res> {
  factory $IForgotPasswordParamsCopyWith(IForgotPasswordParams value,
          $Res Function(IForgotPasswordParams) then) =
      _$IForgotPasswordParamsCopyWithImpl<$Res, IForgotPasswordParams>;
  @useResult
  $Res call({String email});
}

/// @nodoc
class _$IForgotPasswordParamsCopyWithImpl<$Res,
        $Val extends IForgotPasswordParams>
    implements $IForgotPasswordParamsCopyWith<$Res> {
  _$IForgotPasswordParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
  }) {
    return _then(_value.copyWith(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IForgotPasswordParamsImplCopyWith<$Res>
    implements $IForgotPasswordParamsCopyWith<$Res> {
  factory _$$IForgotPasswordParamsImplCopyWith(
          _$IForgotPasswordParamsImpl value,
          $Res Function(_$IForgotPasswordParamsImpl) then) =
      __$$IForgotPasswordParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String email});
}

/// @nodoc
class __$$IForgotPasswordParamsImplCopyWithImpl<$Res>
    extends _$IForgotPasswordParamsCopyWithImpl<$Res,
        _$IForgotPasswordParamsImpl>
    implements _$$IForgotPasswordParamsImplCopyWith<$Res> {
  __$$IForgotPasswordParamsImplCopyWithImpl(_$IForgotPasswordParamsImpl _value,
      $Res Function(_$IForgotPasswordParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? email = null,
  }) {
    return _then(_$IForgotPasswordParamsImpl(
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IForgotPasswordParamsImpl implements _IForgotPasswordParams {
  _$IForgotPasswordParamsImpl({required this.email});

  @override
  final String email;

  @override
  String toString() {
    return 'IForgotPasswordParams(email: $email)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IForgotPasswordParamsImpl &&
            (identical(other.email, email) || other.email == email));
  }

  @override
  int get hashCode => Object.hash(runtimeType, email);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IForgotPasswordParamsImplCopyWith<_$IForgotPasswordParamsImpl>
      get copyWith => __$$IForgotPasswordParamsImplCopyWithImpl<
          _$IForgotPasswordParamsImpl>(this, _$identity);
}

abstract class _IForgotPasswordParams implements IForgotPasswordParams {
  factory _IForgotPasswordParams({required final String email}) =
      _$IForgotPasswordParamsImpl;

  @override
  String get email;
  @override
  @JsonKey(ignore: true)
  _$$IForgotPasswordParamsImplCopyWith<_$IForgotPasswordParamsImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IResetPasswordParams {
  String get resetToken => throw _privateConstructorUsedError;
  String get password => throw _privateConstructorUsedError;
  String get passwordConfirmation => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IResetPasswordParamsCopyWith<IResetPasswordParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IResetPasswordParamsCopyWith<$Res> {
  factory $IResetPasswordParamsCopyWith(IResetPasswordParams value,
          $Res Function(IResetPasswordParams) then) =
      _$IResetPasswordParamsCopyWithImpl<$Res, IResetPasswordParams>;
  @useResult
  $Res call({String resetToken, String password, String passwordConfirmation});
}

/// @nodoc
class _$IResetPasswordParamsCopyWithImpl<$Res,
        $Val extends IResetPasswordParams>
    implements $IResetPasswordParamsCopyWith<$Res> {
  _$IResetPasswordParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resetToken = null,
    Object? password = null,
    Object? passwordConfirmation = null,
  }) {
    return _then(_value.copyWith(
      resetToken: null == resetToken
          ? _value.resetToken
          : resetToken // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      passwordConfirmation: null == passwordConfirmation
          ? _value.passwordConfirmation
          : passwordConfirmation // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IResetPasswordParamsImplCopyWith<$Res>
    implements $IResetPasswordParamsCopyWith<$Res> {
  factory _$$IResetPasswordParamsImplCopyWith(_$IResetPasswordParamsImpl value,
          $Res Function(_$IResetPasswordParamsImpl) then) =
      __$$IResetPasswordParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String resetToken, String password, String passwordConfirmation});
}

/// @nodoc
class __$$IResetPasswordParamsImplCopyWithImpl<$Res>
    extends _$IResetPasswordParamsCopyWithImpl<$Res, _$IResetPasswordParamsImpl>
    implements _$$IResetPasswordParamsImplCopyWith<$Res> {
  __$$IResetPasswordParamsImplCopyWithImpl(_$IResetPasswordParamsImpl _value,
      $Res Function(_$IResetPasswordParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resetToken = null,
    Object? password = null,
    Object? passwordConfirmation = null,
  }) {
    return _then(_$IResetPasswordParamsImpl(
      resetToken: null == resetToken
          ? _value.resetToken
          : resetToken // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      passwordConfirmation: null == passwordConfirmation
          ? _value.passwordConfirmation
          : passwordConfirmation // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IResetPasswordParamsImpl implements _IResetPasswordParams {
  _$IResetPasswordParamsImpl(
      {required this.resetToken,
      required this.password,
      required this.passwordConfirmation});

  @override
  final String resetToken;
  @override
  final String password;
  @override
  final String passwordConfirmation;

  @override
  String toString() {
    return 'IResetPasswordParams(resetToken: $resetToken, password: $password, passwordConfirmation: $passwordConfirmation)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IResetPasswordParamsImpl &&
            (identical(other.resetToken, resetToken) ||
                other.resetToken == resetToken) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.passwordConfirmation, passwordConfirmation) ||
                other.passwordConfirmation == passwordConfirmation));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, resetToken, password, passwordConfirmation);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IResetPasswordParamsImplCopyWith<_$IResetPasswordParamsImpl>
      get copyWith =>
          __$$IResetPasswordParamsImplCopyWithImpl<_$IResetPasswordParamsImpl>(
              this, _$identity);
}

abstract class _IResetPasswordParams implements IResetPasswordParams {
  factory _IResetPasswordParams(
      {required final String resetToken,
      required final String password,
      required final String passwordConfirmation}) = _$IResetPasswordParamsImpl;

  @override
  String get resetToken;
  @override
  String get password;
  @override
  String get passwordConfirmation;
  @override
  @JsonKey(ignore: true)
  _$$IResetPasswordParamsImplCopyWith<_$IResetPasswordParamsImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IUpdatePasswordParams {
  String get currentPassword => throw _privateConstructorUsedError;
  String get password => throw _privateConstructorUsedError;
  String get passwordConfirmation => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IUpdatePasswordParamsCopyWith<IUpdatePasswordParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IUpdatePasswordParamsCopyWith<$Res> {
  factory $IUpdatePasswordParamsCopyWith(IUpdatePasswordParams value,
          $Res Function(IUpdatePasswordParams) then) =
      _$IUpdatePasswordParamsCopyWithImpl<$Res, IUpdatePasswordParams>;
  @useResult
  $Res call(
      {String currentPassword, String password, String passwordConfirmation});
}

/// @nodoc
class _$IUpdatePasswordParamsCopyWithImpl<$Res,
        $Val extends IUpdatePasswordParams>
    implements $IUpdatePasswordParamsCopyWith<$Res> {
  _$IUpdatePasswordParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPassword = null,
    Object? password = null,
    Object? passwordConfirmation = null,
  }) {
    return _then(_value.copyWith(
      currentPassword: null == currentPassword
          ? _value.currentPassword
          : currentPassword // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      passwordConfirmation: null == passwordConfirmation
          ? _value.passwordConfirmation
          : passwordConfirmation // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IUpdatePasswordParamsImplCopyWith<$Res>
    implements $IUpdatePasswordParamsCopyWith<$Res> {
  factory _$$IUpdatePasswordParamsImplCopyWith(
          _$IUpdatePasswordParamsImpl value,
          $Res Function(_$IUpdatePasswordParamsImpl) then) =
      __$$IUpdatePasswordParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String currentPassword, String password, String passwordConfirmation});
}

/// @nodoc
class __$$IUpdatePasswordParamsImplCopyWithImpl<$Res>
    extends _$IUpdatePasswordParamsCopyWithImpl<$Res,
        _$IUpdatePasswordParamsImpl>
    implements _$$IUpdatePasswordParamsImplCopyWith<$Res> {
  __$$IUpdatePasswordParamsImplCopyWithImpl(_$IUpdatePasswordParamsImpl _value,
      $Res Function(_$IUpdatePasswordParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentPassword = null,
    Object? password = null,
    Object? passwordConfirmation = null,
  }) {
    return _then(_$IUpdatePasswordParamsImpl(
      currentPassword: null == currentPassword
          ? _value.currentPassword
          : currentPassword // ignore: cast_nullable_to_non_nullable
              as String,
      password: null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
      passwordConfirmation: null == passwordConfirmation
          ? _value.passwordConfirmation
          : passwordConfirmation // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IUpdatePasswordParamsImpl implements _IUpdatePasswordParams {
  _$IUpdatePasswordParamsImpl(
      {required this.currentPassword,
      required this.password,
      required this.passwordConfirmation});

  @override
  final String currentPassword;
  @override
  final String password;
  @override
  final String passwordConfirmation;

  @override
  String toString() {
    return 'IUpdatePasswordParams(currentPassword: $currentPassword, password: $password, passwordConfirmation: $passwordConfirmation)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IUpdatePasswordParamsImpl &&
            (identical(other.currentPassword, currentPassword) ||
                other.currentPassword == currentPassword) &&
            (identical(other.password, password) ||
                other.password == password) &&
            (identical(other.passwordConfirmation, passwordConfirmation) ||
                other.passwordConfirmation == passwordConfirmation));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, currentPassword, password, passwordConfirmation);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IUpdatePasswordParamsImplCopyWith<_$IUpdatePasswordParamsImpl>
      get copyWith => __$$IUpdatePasswordParamsImplCopyWithImpl<
          _$IUpdatePasswordParamsImpl>(this, _$identity);
}

abstract class _IUpdatePasswordParams implements IUpdatePasswordParams {
  factory _IUpdatePasswordParams(
          {required final String currentPassword,
          required final String password,
          required final String passwordConfirmation}) =
      _$IUpdatePasswordParamsImpl;

  @override
  String get currentPassword;
  @override
  String get password;
  @override
  String get passwordConfirmation;
  @override
  @JsonKey(ignore: true)
  _$$IUpdatePasswordParamsImplCopyWith<_$IUpdatePasswordParamsImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IUpdateInfoParams {
  String get fullName => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IUpdateInfoParamsCopyWith<IUpdateInfoParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IUpdateInfoParamsCopyWith<$Res> {
  factory $IUpdateInfoParamsCopyWith(
          IUpdateInfoParams value, $Res Function(IUpdateInfoParams) then) =
      _$IUpdateInfoParamsCopyWithImpl<$Res, IUpdateInfoParams>;
  @useResult
  $Res call({String fullName});
}

/// @nodoc
class _$IUpdateInfoParamsCopyWithImpl<$Res, $Val extends IUpdateInfoParams>
    implements $IUpdateInfoParamsCopyWith<$Res> {
  _$IUpdateInfoParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fullName = null,
  }) {
    return _then(_value.copyWith(
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IUpdateInfoParamsImplCopyWith<$Res>
    implements $IUpdateInfoParamsCopyWith<$Res> {
  factory _$$IUpdateInfoParamsImplCopyWith(_$IUpdateInfoParamsImpl value,
          $Res Function(_$IUpdateInfoParamsImpl) then) =
      __$$IUpdateInfoParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String fullName});
}

/// @nodoc
class __$$IUpdateInfoParamsImplCopyWithImpl<$Res>
    extends _$IUpdateInfoParamsCopyWithImpl<$Res, _$IUpdateInfoParamsImpl>
    implements _$$IUpdateInfoParamsImplCopyWith<$Res> {
  __$$IUpdateInfoParamsImplCopyWithImpl(_$IUpdateInfoParamsImpl _value,
      $Res Function(_$IUpdateInfoParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fullName = null,
  }) {
    return _then(_$IUpdateInfoParamsImpl(
      fullName: null == fullName
          ? _value.fullName
          : fullName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IUpdateInfoParamsImpl implements _IUpdateInfoParams {
  _$IUpdateInfoParamsImpl({required this.fullName});

  @override
  final String fullName;

  @override
  String toString() {
    return 'IUpdateInfoParams(fullName: $fullName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IUpdateInfoParamsImpl &&
            (identical(other.fullName, fullName) ||
                other.fullName == fullName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, fullName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IUpdateInfoParamsImplCopyWith<_$IUpdateInfoParamsImpl> get copyWith =>
      __$$IUpdateInfoParamsImplCopyWithImpl<_$IUpdateInfoParamsImpl>(
          this, _$identity);
}

abstract class _IUpdateInfoParams implements IUpdateInfoParams {
  factory _IUpdateInfoParams({required final String fullName}) =
      _$IUpdateInfoParamsImpl;

  @override
  String get fullName;
  @override
  @JsonKey(ignore: true)
  _$$IUpdateInfoParamsImplCopyWith<_$IUpdateInfoParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IFetchUsersParams {
  String? get exceptWalletId => throw _privateConstructorUsedError;
  String? get keyword => throw _privateConstructorUsedError;
  int? get page => throw _privateConstructorUsedError;
  int? get perPage => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IFetchUsersParamsCopyWith<IFetchUsersParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IFetchUsersParamsCopyWith<$Res> {
  factory $IFetchUsersParamsCopyWith(
          IFetchUsersParams value, $Res Function(IFetchUsersParams) then) =
      _$IFetchUsersParamsCopyWithImpl<$Res, IFetchUsersParams>;
  @useResult
  $Res call({String? exceptWalletId, String? keyword, int? page, int? perPage});
}

/// @nodoc
class _$IFetchUsersParamsCopyWithImpl<$Res, $Val extends IFetchUsersParams>
    implements $IFetchUsersParamsCopyWith<$Res> {
  _$IFetchUsersParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exceptWalletId = freezed,
    Object? keyword = freezed,
    Object? page = freezed,
    Object? perPage = freezed,
  }) {
    return _then(_value.copyWith(
      exceptWalletId: freezed == exceptWalletId
          ? _value.exceptWalletId
          : exceptWalletId // ignore: cast_nullable_to_non_nullable
              as String?,
      keyword: freezed == keyword
          ? _value.keyword
          : keyword // ignore: cast_nullable_to_non_nullable
              as String?,
      page: freezed == page
          ? _value.page
          : page // ignore: cast_nullable_to_non_nullable
              as int?,
      perPage: freezed == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IFetchUsersParamsImplCopyWith<$Res>
    implements $IFetchUsersParamsCopyWith<$Res> {
  factory _$$IFetchUsersParamsImplCopyWith(_$IFetchUsersParamsImpl value,
          $Res Function(_$IFetchUsersParamsImpl) then) =
      __$$IFetchUsersParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String? exceptWalletId, String? keyword, int? page, int? perPage});
}

/// @nodoc
class __$$IFetchUsersParamsImplCopyWithImpl<$Res>
    extends _$IFetchUsersParamsCopyWithImpl<$Res, _$IFetchUsersParamsImpl>
    implements _$$IFetchUsersParamsImplCopyWith<$Res> {
  __$$IFetchUsersParamsImplCopyWithImpl(_$IFetchUsersParamsImpl _value,
      $Res Function(_$IFetchUsersParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? exceptWalletId = freezed,
    Object? keyword = freezed,
    Object? page = freezed,
    Object? perPage = freezed,
  }) {
    return _then(_$IFetchUsersParamsImpl(
      exceptWalletId: freezed == exceptWalletId
          ? _value.exceptWalletId
          : exceptWalletId // ignore: cast_nullable_to_non_nullable
              as String?,
      keyword: freezed == keyword
          ? _value.keyword
          : keyword // ignore: cast_nullable_to_non_nullable
              as String?,
      page: freezed == page
          ? _value.page
          : page // ignore: cast_nullable_to_non_nullable
              as int?,
      perPage: freezed == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc

class _$IFetchUsersParamsImpl implements _IFetchUsersParams {
  _$IFetchUsersParamsImpl(
      {this.exceptWalletId, this.keyword, this.page, this.perPage});

  @override
  final String? exceptWalletId;
  @override
  final String? keyword;
  @override
  final int? page;
  @override
  final int? perPage;

  @override
  String toString() {
    return 'IFetchUsersParams(exceptWalletId: $exceptWalletId, keyword: $keyword, page: $page, perPage: $perPage)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IFetchUsersParamsImpl &&
            (identical(other.exceptWalletId, exceptWalletId) ||
                other.exceptWalletId == exceptWalletId) &&
            (identical(other.keyword, keyword) || other.keyword == keyword) &&
            (identical(other.page, page) || other.page == page) &&
            (identical(other.perPage, perPage) || other.perPage == perPage));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, exceptWalletId, keyword, page, perPage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IFetchUsersParamsImplCopyWith<_$IFetchUsersParamsImpl> get copyWith =>
      __$$IFetchUsersParamsImplCopyWithImpl<_$IFetchUsersParamsImpl>(
          this, _$identity);
}

abstract class _IFetchUsersParams implements IFetchUsersParams {
  factory _IFetchUsersParams(
      {final String? exceptWalletId,
      final String? keyword,
      final int? page,
      final int? perPage}) = _$IFetchUsersParamsImpl;

  @override
  String? get exceptWalletId;
  @override
  String? get keyword;
  @override
  int? get page;
  @override
  int? get perPage;
  @override
  @JsonKey(ignore: true)
  _$$IFetchUsersParamsImplCopyWith<_$IFetchUsersParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
