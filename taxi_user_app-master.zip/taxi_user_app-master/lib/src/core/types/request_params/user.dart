import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.freezed.dart';

@freezed
class ICreateUserParams with _$ICreateUserParams {
  factory ICreateUserParams({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) = _ICreateUserParams;
}

@freezed
class IFetchUserParams with _$IFetchUserParams {
  factory IFetchUserParams({
    required String id,
  }) = _IFetchUserParams;
}

@freezed
class IFetchDriverParams with _$IFetchDriverParams {
  factory IFetchDriverParams({
    required String uid,
  }) = _IFetchDriverParams;
}

@freezed
class IUpdateDriverParams with _$IUpdateDriverParams {
  factory IUpdateDriverParams({
    required String id,
    String? newTripStatus,
    double? lat,
    double? long,
    String? deviceToken,
    String? status,
  }) = _IUpdateDriverParams;
}

@freezed
class IForgotPasswordParams with _$IForgotPasswordParams {
  factory IForgotPasswordParams({required String email}) =
      _IForgotPasswordParams;
}

@freezed
class IResetPasswordParams with _$IResetPasswordParams {
  factory IResetPasswordParams({
    required String resetToken,
    required String password,
    required String passwordConfirmation,
  }) = _IResetPasswordParams;
}

@freezed
class IUpdatePasswordParams with _$IUpdatePasswordParams {
  factory IUpdatePasswordParams({
    required String currentPassword,
    required String password,
    required String passwordConfirmation,
  }) = _IUpdatePasswordParams;
}

@freezed
class IUpdateInfoParams with _$IUpdateInfoParams {
  factory IUpdateInfoParams({required String fullName}) = _IUpdateInfoParams;
}

@freezed
class IFetchUsersParams with _$IFetchUsersParams {
  factory IFetchUsersParams({
    String? exceptWalletId,
    String? keyword,
    int? page,
    int? perPage,
  }) = _IFetchUsersParams;
}
