// ignore_for_file: unused_element

import 'package:intl/intl.dart';

extension ExtendedString on String {
  bool toBoolean() {
    return toLowerCase() == 'true' || toLowerCase() == '1';
  }

  String extractFromPrompt() {
    return (isEmpty || this == 'none') ? '' : this;
  }

  String truncate(int length) {
    if (this.length < length) {
      return this;
    }
    return '${substring(0, length - 4)}...';
  }

  num toDecimal({num? parsedErrorValue}) {
    try {
      return NumberFormat.decimalPattern().parse(this);
    } catch (e) {
      if (parsedErrorValue != null) return parsedErrorValue;

      rethrow;
    }
  }
}
