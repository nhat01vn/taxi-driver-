import 'package:flutter/material.dart';
import 'package:futter_user/src/core/constants/app_color.dart';

extension ExtendedTextStyle on TextStyle {
  static const double fontSizeBase = 16.0;

  static const double h1FontSize = fontSizeBase * 2.5; // 40
  static const double h2FontSize = fontSizeBase * 2; // 32
  static const double h3FontSize = fontSizeBase * 1.75; // 28
  static const double h4FontSize = fontSizeBase * 1.5; // 24
  static const double h5FontSize = fontSizeBase * 1.25; // 20
  static const double h6FontSize = fontSizeBase; // 16
  static const double h7FontSize = fontSizeBase * 0.875; // 14
  static const double h8FontSize = fontSizeBase * 0.75; // 12
  static const double h9FontSize = fontSizeBase * 0.625; // 10

  static const FontWeight fontWeightLighter = FontWeight.w100;
  static const FontWeight fontWeightLight = FontWeight.w300;
  static const FontWeight fontWeightNormal = FontWeight.w400;
  static const FontWeight fontWeightMedium = FontWeight.w600;
  static const FontWeight fontWeightBold = FontWeight.w700;
  static const FontWeight fontWeightBolder = FontWeight.w900;

  /// Font Size is 40
  TextStyle get h1 {
    return copyWith(
      fontSize: h1FontSize,
      height: h1FontSize / fontSizeBase,
    );
  }

  /// Font Size is 32
  TextStyle get h2 {
    return copyWith(
      fontSize: h2FontSize,
      height: h2FontSize / fontSizeBase,
    );
  }

  /// Font Size is 28
  TextStyle get h3 {
    return copyWith(
      fontSize: h3FontSize,
      height: h3FontSize / fontSizeBase,
    );
  }

  /// Font Size is 24
  TextStyle get h4 {
    return copyWith(
      fontSize: h4FontSize,
      height: h4FontSize / fontSizeBase,
    );
  }

  /// Font Size is 20
  TextStyle get h5 {
    return copyWith(
      fontSize: h5FontSize,
      height: h5FontSize / fontSizeBase,
    );
  }

  /// Font Size is 16
  TextStyle get h6 {
    return copyWith(
      fontSize: h6FontSize,
      height: h6FontSize / fontSizeBase,
    );
  }

  /// Font Size is 14
  TextStyle get h7 {
    return copyWith(
      fontSize: h7FontSize,
      height: h7FontSize / fontSizeBase,
    );
  }

  /// Font Size is 12
  TextStyle get h8 {
    return copyWith(
      fontSize: h8FontSize,
      height: h8FontSize / fontSizeBase,
    );
  }

  /// Font Size is 10
  TextStyle get h9 {
    return copyWith(
      fontSize: h9FontSize,
      height: h9FontSize / fontSizeBase,
    );
  }

  /// Font Weight is w100
  TextStyle get fWLighter {
    return copyWith(fontWeight: fontWeightLighter);
  }

  /// Font Weight is w300
  TextStyle get fWLight {
    return copyWith(fontWeight: fontWeightLight);
  }

  /// Font Weight is w400
  TextStyle get fWNormal {
    return copyWith(fontWeight: fontWeightNormal);
  }

  /// Font Weight is w600
  TextStyle get fWMedium {
    return copyWith(fontWeight: fontWeightMedium);
  }

  /// Font Weight is w700
  TextStyle get fWBold {
    return copyWith(fontWeight: fontWeightBold);
  }

  /// Font Weight is w900
  TextStyle get fWBolder {
    return copyWith(fontWeight: fontWeightBolder);
  }

  TextStyle get italic {
    return copyWith(
      fontWeight: FontWeight.normal,
      fontStyle: FontStyle.italic,
    );
  }

  TextStyle get title {
    return copyWith(
      color: AppColor.white,
      fontSize: 18,
    );
  }

  TextStyle get primaryColor {
    return copyWith(color: AppColor.primary);
  }

  TextStyle get secondaryColor {
    return copyWith(color: AppColor.secondary);
  }

  TextStyle get whiteColor {
    return copyWith(color: AppColor.white);
  }

  TextStyle get blackColor {
    return copyWith(color: AppColor.black);
  }

  TextStyle get blueColor {
    return copyWith(color: AppColor.blue);
  }

  TextStyle get defaultText {
    return copyWith(color: AppColor.gray600);
  }

  TextStyle tColor(Color color) {
    return copyWith(color: color);
  }

  TextStyle fSize(double size) {
    return copyWith(fontSize: size);
  }

  TextStyle fWeight(FontWeight fontWeight) {
    return copyWith(fontWeight: fontWeight);
  }

  TextStyle lineHeight(double lineHeight) {
    return copyWith(height: lineHeight);
  }

  TextStyle fShadows(List<Shadow> shadows) {
    return copyWith(shadows: shadows);
  }
}

class TextStyles {
  TextStyles(this.context);

  BuildContext? context;

  static const TextStyle defaultStyle = TextStyle(
    fontSize: ExtendedTextStyle.fontSizeBase,
    color: AppColor.defaultText,
    fontFamily: 'Roboto',
    fontWeight: ExtendedTextStyle.fontWeightNormal,
    height: 1,
  );

  static const TextStyle defaultAppBarTitle = TextStyle(
    fontFamily: 'Roboto',
    color: AppColor.white,
    fontSize: 22,
    fontWeight: FontWeight.w700,
  );
}
