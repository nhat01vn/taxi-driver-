import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:futter_user/src/application/auth_service.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_size.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/types/request_params/auth.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/rounded_button.dart';
import 'package:futter_user/src/presentation/widgets/form/form_text_field.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:go_router/go_router.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  bool _isPasswordVisible = false;
  CommonHelper cCommonHelperMethods = CommonHelper();

  void submitForm() async {
    try {
      cCommonHelperMethods.checkConnectivity(context);
      if (_form.currentState!.saveAndValidate()) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) =>
              const LoadingDialog(messageText: 'Allowing you to Login...'),
        );
        var value = _form.currentState!.value;
        final userToken = await ref.read(authServiceProvider).login(
              ILoginParams(
                email: value['email'],
                password: value['password'],
              ),
            );

        final currentUserResp = await ref.read(userServiceProvider).fetchUser(
              IFetchUserParams(id: userToken.id.toString()),
            );
        if (!context.mounted) return;
        Navigator.pop(context);
        if (currentUserResp.blockStatus == 'no') {
          context.goNamed('HomeScreen');
        } else {
          await localStorage.clearUserToken();
          if (!context.mounted) return;
          cCommonHelperMethods.displaySnackBar(
            'you are blocked. Contact admin: qthanh18tn@gmail.com',
            context,
          );
        }
      }
    } catch (err) {
      if (mounted) {
        Navigator.pop(context);
        cCommonHelperMethods.displaySnackBar(
          (err as Map)['error'].toString(),
          context,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      safeAreaColor: AppColor.white,
      child: Container(
        color: AppColor.white,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 140,
              height: 140,
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            Text(
              'Login',
              textAlign: TextAlign.center,
              style: TextStyles.defaultAppBarTitle.primaryColor,
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            FormBuilder(
              key: _form,
              child: Column(
                children: [
                  FormTextField(
                    name: 'email',
                    placeholder: 'login.emailPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'login.validationForEmail'.tr(),
                          },
                        ),
                      ),
                      FormBuilderValidators.email(
                        errorText: 'form.validation.email'.tr(),
                      ),
                    ]),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                  FormTextField(
                    name: 'password',
                    obscureText: !_isPasswordVisible,
                    suffixIcon: Align(
                      widthFactor: 1.0,
                      heightFactor: 1.0,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _isPasswordVisible = !_isPasswordVisible;
                          });
                        },
                        child: ImageHelper.loadFromAsset(
                          AppAsset.icoHintPassword,
                          tintColor: AppColor.defaultText,
                          height: 25,
                        ),
                      ),
                    ),
                    placeholder: 'login.passwordPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'login.validationForPassword'.tr(),
                          },
                        ),
                      ),
                      FormBuilderValidators.minLength(
                        4,
                        errorText: 'form.validation.min'.tr(
                          namedArgs: {
                            'fieldName': 'login.validationForPassword'.tr(),
                            'length': '4',
                          },
                        ),
                      ),
                      FormBuilderValidators.maxLength(
                        20,
                        errorText: 'form.validation.max'.tr(
                          namedArgs: {
                            'fieldName': 'login.validationForPassword'.tr(),
                            'length': '20',
                          },
                        ),
                      ),
                    ]),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'login.formOr'.tr(),
                  textAlign: TextAlign.center,
                  style: TextStyles.defaultStyle.h6,
                ),
                GestureDetector(
                  onTap: () => {
                    context.goNamed(
                      'RegisterScreen',
                    ),
                  },
                  child: Text(
                    'login.registerWitLink'.tr(),
                    textAlign: TextAlign.center,
                    style: TextStyles.defaultStyle.h6.primaryColor.fWBold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            RoundedButton(
              buttonText: 'login.buttonSubmit'.tr(),
              borderSize: const BorderSide(color: AppColor.success),
              onPressed: submitForm,
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            GestureDetector(
              onTap: () => {
                context.goNamed(
                  'ForgotPasswordScreen',
                ),
              },
              child: Text(
                'login.forgotPasswordWithLink'.tr(),
                textAlign: TextAlign.center,
                style: TextStyles.defaultStyle.h6.primaryColor.fWBold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
