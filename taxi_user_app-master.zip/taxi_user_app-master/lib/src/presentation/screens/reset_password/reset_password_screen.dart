import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_size.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/rounded_button.dart';
import 'package:futter_user/src/presentation/widgets/form/form_text_field.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:go_router/go_router.dart';

class ResetPasswordScreen extends ConsumerStatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  ConsumerState<ResetPasswordScreen> createState() =>
      _ResetPasswordScreenScreenState();
}

class _ResetPasswordScreenScreenState
    extends ConsumerState<ResetPasswordScreen> {
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  bool _isPasswordVisible = false;
  bool _isPasswordConfirmationVisible = false;
  CommonHelper cCommonHelperMethods = CommonHelper();

  void submitForm() async {
    try {
      cCommonHelperMethods.checkConnectivity(context);

      if (_form.currentState!.saveAndValidate()) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) =>
              const LoadingDialog(messageText: 'Resetting password...'),
        );
        var value = _form.currentState!.value;
        await ref.read(userServiceProvider).resetPassword(
              IResetPasswordParams(
                resetToken: value['resetToken'],
                password: value['password'],
                passwordConfirmation: value['passwordConfirmation'],
              ),
            );
        if (!context.mounted) return;
        Navigator.pop(context);
        context.goNamed('LoginScreen');
      }
    } catch (err) {
      if (mounted) {
        Navigator.pop(context);
        cCommonHelperMethods.displaySnackBar(
          (err as Map)['error'].toString(),
          context,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      appBar: AppBar(
        backgroundColor: AppColor.white,
        shadowColor: AppColor.transparent,
        title: Text('resetPassword.title'.tr()),
        titleTextStyle: TextStyles.defaultAppBarTitle.primaryColor,
        leading: Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => {
                  context.goNamed(
                    'ForgotPasswordScreen',
                  ),
                },
                child: ImageHelper.loadFromAsset(
                  AppAsset.icoArrowLeft,
                  tintColor: AppColor.primary,
                ),
              ),
            ],
          ),
        ),
      ),
      safeAreaColor: AppColor.white,
      child: Container(
        color: AppColor.white,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FormBuilder(
              key: _form,
              child: Column(
                children: [
                  FormTextField(
                    name: 'resetToken',
                    placeholder: 'resetPassword.resetTokenPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName':
                                'resetPassword.validationForResetToken'.tr(),
                          },
                        ),
                      ),
                    ]),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                  FormTextField(
                    name: 'password',
                    obscureText: !_isPasswordVisible,
                    suffixIcon: Align(
                      widthFactor: 1.0,
                      heightFactor: 1.0,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _isPasswordVisible = !_isPasswordVisible;
                          });
                        },
                        child: ImageHelper.loadFromAsset(
                          AppAsset.icoHintPassword,
                          tintColor: AppColor.defaultText,
                          height: 25,
                        ),
                      ),
                    ),
                    placeholder: 'resetPassword.passwordPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName':
                                'resetPassword.validationForPassword'.tr(),
                          },
                        ),
                      ),
                      FormBuilderValidators.minLength(
                        4,
                        errorText: 'form.validation.min'.tr(
                          namedArgs: {
                            'fieldName':
                                'resetPassword.validationForPassword'.tr(),
                            'length': '4',
                          },
                        ),
                      ),
                      FormBuilderValidators.maxLength(
                        20,
                        errorText: 'form.validation.max'.tr(
                          namedArgs: {
                            'fieldName':
                                'resetPassword.validationForPassword'.tr(),
                            'length': '20',
                          },
                        ),
                      ),
                    ]),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                  FormTextField(
                    name: 'passwordConfirmation',
                    obscureText: !_isPasswordConfirmationVisible,
                    suffixIcon: Align(
                      widthFactor: 1.0,
                      heightFactor: 1.0,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _isPasswordConfirmationVisible =
                                !_isPasswordConfirmationVisible;
                          });
                        },
                        child: ImageHelper.loadFromAsset(
                          AppAsset.icoHintPassword,
                          tintColor: AppColor.defaultText,
                          height: 25,
                        ),
                      ),
                    ),
                    placeholder:
                        'resetPassword.passwordConfirmationPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName':
                                'resetPassword.validationForPasswordConfirmation'
                                    .tr(),
                          },
                        ),
                      ),
                      (val) {
                        if (val !=
                            _form.currentState!.fields['password']?.value) {
                          return 'form.validation.verifyPassword'.tr();
                        }
                        return null;
                      },
                    ]),
                  ),
                  const SizedBox(height: 30.0),
                ],
              ),
            ),
            RoundedButton(
              buttonText: 'resetPassword.buttonSubmit'.tr(),
              borderSize: const BorderSide(color: AppColor.success),
              onPressed: submitForm,
            ),
          ],
        ),
      ),
    );
  }
}
