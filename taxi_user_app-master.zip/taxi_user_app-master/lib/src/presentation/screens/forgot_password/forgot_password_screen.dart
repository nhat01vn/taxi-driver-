import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_size.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/rounded_button.dart';
import 'package:futter_user/src/presentation/widgets/form/form_text_field.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:go_router/go_router.dart';
import 'package:styled_text/tags/styled_text_tag.dart';
import 'package:styled_text/widgets/styled_text.dart';

class ForgotPasswordScreen extends ConsumerStatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  ConsumerState<ForgotPasswordScreen> createState() =>
      _ForgotPasswordScreenScreenState();
}

class _ForgotPasswordScreenScreenState
    extends ConsumerState<ForgotPasswordScreen> {
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  CommonHelper cCommonHelperMethods = CommonHelper();

  void submitForm() async {
    try {
      cCommonHelperMethods.checkConnectivity(context);
      if (_form.currentState!.saveAndValidate()) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) =>
              const LoadingDialog(messageText: 'Send email...'),
        );
        var value = _form.currentState!.value;
        await ref.read(userServiceProvider).forgotPassword(
              IForgotPasswordParams(email: value['email']),
            );
        if (!context.mounted) return;
        Navigator.pop(context);
        context.goNamed('ResetPasswordScreen');
      }
    } catch (err) {
      if (mounted) {
        Navigator.pop(context);
        cCommonHelperMethods.displaySnackBar(
          (err as Map)['error'].toString(),
          context,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      appBar: AppBar(
        backgroundColor: AppColor.white,
        shadowColor: AppColor.transparent,
        title: Text('forgotPassword.title'.tr()),
        titleTextStyle: TextStyles.defaultAppBarTitle.primaryColor,
        leading: Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => {
                  context.goNamed(
                    'LoginScreen',
                  ),
                },
                child: ImageHelper.loadFromAsset(
                  AppAsset.icoArrowLeft,
                  tintColor: AppColor.primary,
                ),
              ),
            ],
          ),
        ),
      ),
      safeAreaColor: AppColor.white,
      child: Container(
        color: AppColor.white,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FormBuilder(
              key: _form,
              child: Column(
                children: [
                  FormTextField(
                    name: 'email',
                    placeholder: 'forgotPassword.emailPlaceholder'.tr(),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName':
                                'forgotPassword.validationForEmail'.tr(),
                          },
                        ),
                      ),
                      FormBuilderValidators.email(
                        errorText: 'form.validation.email'.tr(),
                      ),
                    ]),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                ],
              ),
            ),
            StyledText(
              textAlign: TextAlign.center,
              text: 'forgotPassword.textOtp'.tr(),
              style: TextStyles.defaultStyle.h6,
              tags: {
                'highlight': StyledTextTag(
                  style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                ),
              },
            ),
            const SizedBox(height: 30.0),
            RoundedButton(
              buttonText: 'forgotPassword.buttonSubmit'.tr(),
              borderSize: const BorderSide(color: AppColor.success),
              onPressed: submitForm,
            ),
          ],
        ),
      ),
    );
  }
}
