import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/auth_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:go_router/go_router.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  @override
  void initState() {
    super.initState();

    _nextScreen();
  }

  void _nextScreen() async {
    final userToken = await localStorage.loadUserToken();
    if (mounted) {
      if (userToken.token == '') {
        context.goNamed('RegisterScreen');
      } else {
        try {
          await ref.read(authServiceProvider).refreshToken();
          if (mounted) {
            context.goNamed('HomeScreen');
          }
        } catch (err) {
          if (mounted) {
            context.goNamed('RegisterScreen');
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: AppColor.primary,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ImageHelper.loadFromAsset(
              AppAsset.logo,
              height: 180,
            ),
          ],
        ),
      ),
    );
  }
}
