import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:futter_user/src/domain/user.dart';
import 'package:futter_user/src/presentation/widgets/common/user_avatar.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:go_router/go_router.dart';

class AccountBottomNav extends ConsumerStatefulWidget {
  const AccountBottomNav({Key? key}) : super(key: key);

  @override
  ConsumerState<AccountBottomNav> createState() => _AccountBottomNavState();
}

class _AccountBottomNavState extends ConsumerState<AccountBottomNav> {
  User userProfile = User.createEmpty();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchUserProfile();
  }

  void _fetchUserProfile() async {
    final userToken = await localStorage.loadUserToken();

    final currentUserResp = await ref.read(userServiceProvider).fetchUser(
          IFetchUserParams(id: userToken.id.toString()),
        );
    setState(() {
      userProfile = currentUserResp;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : AppContainer(
            appBar: AppBar(
              backgroundColor: AppColor.primary,
              shadowColor: AppColor.transparent,
              title: const Text('Account'),
              titleTextStyle: TextStyles.defaultAppBarTitle,
            ),
            child: Column(
              children: [
                Container(
                  color: AppColor.white,
                  padding: const EdgeInsets.only(left: 13, right: 13, top: 18),
                  margin: const EdgeInsets.only(bottom: 1),
                  child: Center(
                    child: Column(
                      children: [
                        Stack(
                          children: [
                            UserAvatar(
                              size: 60,
                              name: userProfile.name,
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: CircleAvatar(
                                radius: 14,
                                backgroundColor: AppColor.gray200,
                                child: ImageHelper.loadFromAsset(
                                  AppAsset.icoCamera,
                                  tintColor: AppColor.gray600,
                                  width: 30,
                                  height: 30,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 50),
                      ],
                    ),
                  ),
                ),
                Container(
                  color: AppColor.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
                  margin: const EdgeInsets.only(bottom: 1),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.person,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Name',
                            style: TextStyles.defaultStyle.h6,
                          ),
                        ],
                      ),
                      Text(
                        userProfile.name,
                        style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                      ),
                    ],
                  ),
                ),
                Container(
                  color: AppColor.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
                  margin: const EdgeInsets.only(bottom: 1),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.email,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Email',
                            style: TextStyles.defaultStyle.h6,
                          ),
                        ],
                      ),
                      Text(
                        userProfile.email!,
                        style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                      ),
                    ],
                  ),
                ),
                Container(
                  color: AppColor.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
                  margin: const EdgeInsets.only(bottom: 1),
                  child: GestureDetector(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.password_outlined,
                              color: Colors.grey,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Password',
                              style: TextStyles.defaultStyle.fWNormal.h6,
                            ),
                          ],
                        ),
                        Text(
                          '*********',
                          style: TextStyles.defaultStyle.fWBold.h6.primaryColor,
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  color: AppColor.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
                  margin: const EdgeInsets.only(bottom: 1),
                  child: GestureDetector(
                    onTap: _logout,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.logout,
                              color: Colors.grey,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Logout',
                              style: TextStyles.defaultStyle.fWNormal.h6,
                            ),
                          ],
                        ),
                        ImageHelper.loadFromAsset(
                          AppAsset.icoArrowRight,
                          tintColor: AppColor.primary,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
  }

  void _logout() async {
    await localStorage.clearUserToken();
    if (mounted) context.goNamed('LoginScreen');
  }
}
