import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/push_notification_service.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/constants/app_config.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:futter_user/src/domain/direction_details_model.dart';
import 'package:futter_user/src/domain/driver.dart';
import 'package:futter_user/src/domain/online_nearby_drivers.dart';
import 'package:futter_user/src/presentation/controllers/app_info.dart';
import 'package:futter_user/src/presentation/screens/search_destionation/search_destination_screen.dart';
import 'package:futter_user/src/presentation/widgets/common/info_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/payment_dialog.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:restart_app/restart_app.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeBottomNav extends ConsumerStatefulWidget {
  const HomeBottomNav({Key? key}) : super(key: key);

  @override
  ConsumerState<HomeBottomNav> createState() => _HomeBottomNavState();
}

class _HomeBottomNavState extends ConsumerState<HomeBottomNav> {
  final Completer<GoogleMapController> googleMapCompleterController =
      Completer<GoogleMapController>();
  bool isInitState = true;
  GoogleMapController? controllerGoogleMap;
  Position? currentPositionOfUser;
  CommonHelper cCommonHelperMethods = CommonHelper();
  double searchContainerHeight = 276;
  double bottomMapPadding = 0;
  double rideDetailsContainerHeight = 0;
  double requestContainerHeight = 0;
  double tripContainerHeight = 0;
  DirectionDetailsModel? tripDirectionDetailsInfo;
  List<LatLng> polylineCoOrdinates = [];
  Set<Polyline> polylineSet = {};
  Set<Marker> markerSet = {};
  Set<Circle> circleSet = {};
  bool isDrawerOpened = true;
  String stateOfApp = 'normal';
  bool nearbyOnlineDriversKeysLoaded = false;
  BitmapDescriptor? carIconNearbyDriver;
  DatabaseReference? tripRequestRef;
  List<OnlineNearbyDrivers>? availableNearbyOnlineDriversList;
  StreamSubscription<DatabaseEvent>? tripStreamSubscription;
  bool requestingDirectionDetailsInfo = false;

  @override
  void initState() {
    fetchCurrentUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    makeDriverNearbyCarIcon();

    return Scaffold(
      body: isInitState
          ? const SizedBox.shrink()
          : Stack(
              children: [
                GoogleMap(
                  padding: EdgeInsets.only(top: 26, bottom: bottomMapPadding),
                  mapType: MapType.normal,
                  myLocationEnabled: true,
                  polylines: polylineSet,
                  markers: markerSet,
                  circles: circleSet,
                  initialCameraPosition: googlePlexInitialPosition,
                  onMapCreated: (GoogleMapController mapController) {
                    controllerGoogleMap = mapController;
                    googleMapCompleterController.complete(controllerGoogleMap);
                    setState(() {
                      bottomMapPadding = 350;
                    });
                    getCurrentLiveLocationOfUser();
                  },
                ),

                ///drawer button
                Positioned(
                  top: 36,
                  left: 19,
                  child: GestureDetector(
                    onTap: () {
                      if (isDrawerOpened) resetAppNow();
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 5,
                            spreadRadius: 0.5,
                            offset: Offset(0.7, 0.7),
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        backgroundColor: Colors.grey,
                        radius: 20,
                        child: Icon(
                          isDrawerOpened == true ? Icons.menu : Icons.close,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ),
                ),

                ///search location icon button
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: -20,
                  child: SizedBox(
                    height: searchContainerHeight,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () async {
                            var responseFromSearchPage = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (c) => const SearchDestinationScreen(),
                              ),
                            );
                            if (responseFromSearchPage == 'placeSelected') {
                              displayUserRideDetailsContainer();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey,
                            shape: const CircleBorder(),
                            padding: const EdgeInsets.all(24),
                          ),
                          child: const Icon(
                            Icons.search,
                            color: Colors.white,
                            size: 25,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                ///ride details container
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 50,
                  child: Container(
                    height: rideDetailsContainerHeight,
                    decoration: const BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white12,
                          blurRadius: 15.0,
                          spreadRadius: 0.5,
                          offset: Offset(.7, .7),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 16, right: 16),
                            child: SizedBox(
                              height: 190,
                              child: Card(
                                elevation: 10,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.width * .70,
                                  color: Colors.black45,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                      top: 8,
                                      bottom: 8,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                            left: 8,
                                            right: 8,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                (tripDirectionDetailsInfo !=
                                                        null)
                                                    ? tripDirectionDetailsInfo!
                                                        .distanceTextString!
                                                    : '',
                                                style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.white70,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                (tripDirectionDetailsInfo !=
                                                        null)
                                                    ? tripDirectionDetailsInfo!
                                                        .durationTextString!
                                                    : '',
                                                style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.white70,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () async {
                                            setState(() {
                                              stateOfApp = 'requesting';
                                            });

                                            await displayRequestContainer();

                                            //get nearest available online drivers
                                            availableNearbyOnlineDriversList =
                                                CommonHelper
                                                    .nearbyOnlineDriversList;

                                            //search driver
                                            searchDriver();
                                          },
                                          child: Image.asset(
                                            'assets/images/uberexec.png',
                                            height: 122,
                                            width: 122,
                                          ),
                                        ),
                                        Text(
                                          (tripDirectionDetailsInfo != null)
                                              ? '\$ ${(cCommonHelperMethods.calculateFareAmount(tripDirectionDetailsInfo!)).toString()}'
                                              : '',
                                          style: const TextStyle(
                                            fontSize: 18,
                                            color: Colors.white70,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                ///request container
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 40,
                  child: Container(
                    height: requestContainerHeight,
                    decoration: const BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        topRight: Radius.circular(16),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 15.0,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 18,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(height: 12),
                          SizedBox(
                            width: 200,
                            child: LoadingAnimationWidget.flickr(
                              leftDotColor: Colors.greenAccent,
                              rightDotColor: Colors.pinkAccent,
                              size: 50,
                            ),
                          ),
                          const SizedBox(height: 20),
                          GestureDetector(
                            onTap: () {
                              resetAppNow();
                              cancelRideRequest();
                            },
                            child: Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                color: Colors.white70,
                                borderRadius: BorderRadius.circular(25),
                                border:
                                    Border.all(width: 1.5, color: Colors.grey),
                              ),
                              child: const Icon(
                                Icons.close,
                                color: Colors.black,
                                size: 25,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                ///trip details container
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: tripContainerHeight,
                    decoration: const BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(16),
                        topRight: Radius.circular(16),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white24,
                          blurRadius: 15.0,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 18,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 5),
                          //trip status display text
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                tripStatusDisplay,
                                style: const TextStyle(
                                  fontSize: 19,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 19),
                          const Divider(
                            height: 1,
                            color: Colors.white70,
                            thickness: 1,
                          ),
                          const SizedBox(height: 19),
                          //image - driver name and driver car details
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              ClipOval(
                                child: photoDriver == ''
                                    ? Image.asset(
                                        'assets/images/avatarwoman.png',
                                        width: 40,
                                        height: 40,
                                      )
                                    : Image.network(
                                        photoDriver,
                                        width: 60,
                                        height: 60,
                                        fit: BoxFit.cover,
                                      ),
                              ),
                              const SizedBox(width: 8),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    nameDriver,
                                    style: const TextStyle(
                                      fontSize: 20,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  Text(
                                    carDetailsDriver,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 19),
                          const Divider(
                            height: 1,
                            color: Colors.white70,
                            thickness: 1,
                          ),
                          const SizedBox(height: 19),
                          //call driver btn
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  launchUrl(
                                    Uri.parse('tel://$phoneNumberDriver'),
                                  );
                                },
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(25),
                                        ),
                                        border: Border.all(
                                          width: 1,
                                          color: Colors.white,
                                        ),
                                      ),
                                      child: const Icon(
                                        Icons.phone,
                                        color: Colors.white,
                                      ),
                                    ),
                                    const SizedBox(height: 11),
                                    const Text(
                                      'Call',
                                      style: TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  fetchCurrentUser() async {
    final userToken = await localStorage.loadUserToken();

    final currentUserResp = await ref.read(userServiceProvider).fetchUser(
          IFetchUserParams(id: userToken.id.toString()),
        );
    setState(() {
      currentUser = currentUserResp;
      isInitState = false;
    });
  }

  makeDriverNearbyCarIcon() {
    if (carIconNearbyDriver == null) {
      ImageConfiguration configuration =
          createLocalImageConfiguration(context, size: const Size(0.5, 0.5));
      BitmapDescriptor.fromAssetImage(
        configuration,
        'assets/images/tracking.png',
      ).then((iconImage) {
        carIconNearbyDriver = iconImage;
      });
    }
  }

  getCurrentLiveLocationOfUser() async {
    Position positionOfUser = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
    );
    currentPositionOfUser = positionOfUser;

    LatLng positionOfUserInLatLng = LatLng(
      currentPositionOfUser!.latitude,
      currentPositionOfUser!.longitude,
    );

    CameraPosition cameraPosition =
        CameraPosition(target: positionOfUserInLatLng, zoom: 15);
    controllerGoogleMap!
        .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

    if (!mounted) return;
    await CommonHelper.convertGeoGraphicCoOrdinatesIntoHumanReadableAddress(
      currentPositionOfUser!,
      context,
      ref,
    );
    await initializeGeoFireListener();
  }

  initializeGeoFireListener() {
    Geofire.initialize('onlineDrivers');
    Geofire.queryAtLocation(
      currentPositionOfUser!.latitude,
      currentPositionOfUser!.longitude,
      22,
    )!
        .listen((driverEvent) {
      if (driverEvent != null) {
        var onlineDriverChild = driverEvent['callBack'];
        switch (onlineDriverChild) {
          case Geofire.onKeyEntered:
            OnlineNearbyDrivers onlineNearbyDrivers = OnlineNearbyDrivers();
            onlineNearbyDrivers.uidDriver = driverEvent['key'];
            onlineNearbyDrivers.latDriver = driverEvent['latitude'];
            onlineNearbyDrivers.lngDriver = driverEvent['longitude'];
            CommonHelper.nearbyOnlineDriversList.add(onlineNearbyDrivers);

            if (nearbyOnlineDriversKeysLoaded == true) {
              //update drivers on google map
              updateAvailableNearbyOnlineDriversOnMap();
            }

            break;

          case Geofire.onKeyExited:
            CommonHelper.removeDriverFromList(driverEvent['key']);

            //update drivers on google map
            updateAvailableNearbyOnlineDriversOnMap();

            break;

          case Geofire.onKeyMoved:
            OnlineNearbyDrivers onlineNearbyDrivers = OnlineNearbyDrivers();
            onlineNearbyDrivers.uidDriver = driverEvent['key'];
            onlineNearbyDrivers.latDriver = driverEvent['latitude'];
            onlineNearbyDrivers.lngDriver = driverEvent['longitude'];
            CommonHelper.updateOnlineNearbyDriversLocation(onlineNearbyDrivers);

            //update drivers on google map
            updateAvailableNearbyOnlineDriversOnMap();

            break;

          case Geofire.onGeoQueryReady:
            nearbyOnlineDriversKeysLoaded = true;

            //update drivers on google map
            updateAvailableNearbyOnlineDriversOnMap();

            break;
        }
      }
    });
  }

  updateAvailableNearbyOnlineDriversOnMap() {
    Set<Marker> markersTempSet = <Marker>{};

    for (OnlineNearbyDrivers eachOnlineNearbyDriver
        in CommonHelper.nearbyOnlineDriversList) {
      LatLng driverCurrentPosition = LatLng(
        eachOnlineNearbyDriver.latDriver!,
        eachOnlineNearbyDriver.lngDriver!,
      );

      Marker driverMarker = Marker(
        markerId: MarkerId('driver ID = ${eachOnlineNearbyDriver.uidDriver}'),
        position: driverCurrentPosition,
        icon: carIconNearbyDriver!,
      );

      markersTempSet.add(driverMarker);
    }

    setState(() {
      markerSet.clear();
      markerSet = markersTempSet;
    });
  }

  void displayUserRideDetailsContainer() async {
    ///Directions API
    var pickUpLocation = ref.read(appInfoControllerProvider).pickUpLocation;
    var dropOffDestinationLocation =
        ref.read(appInfoControllerProvider).dropOffLocation;

    var pickupGeoGraphicCoOrdinates = LatLng(
      pickUpLocation!.latitudePosition!,
      pickUpLocation.longitudePosition!,
    );
    var dropOffDestinationGeoGraphicCoOrdinates = LatLng(
      dropOffDestinationLocation!.latitudePosition!,
      dropOffDestinationLocation.longitudePosition!,
    );

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) =>
          const LoadingDialog(messageText: 'Getting direction...'),
    );

    ///Directions API
    var detailsFromDirectionAPI = await CommonHelper.getDirectionDetailsFromAPI(
      pickupGeoGraphicCoOrdinates,
      dropOffDestinationGeoGraphicCoOrdinates,
    );

    tripDirectionDetailsInfo = detailsFromDirectionAPI;

    if (mounted) Navigator.pop(context);

    //draw route from pickup to dropOffDestination
    PolylinePoints pointsPolyline = PolylinePoints();
    List<PointLatLng> latLngPointsFromPickUpToDestination =
        pointsPolyline.decodePolyline(tripDirectionDetailsInfo!.encodedPoints!);

    polylineCoOrdinates.clear();
    if (latLngPointsFromPickUpToDestination.isNotEmpty) {
      for (var latLngPoint in latLngPointsFromPickUpToDestination) {
        polylineCoOrdinates
            .add(LatLng(latLngPoint.latitude, latLngPoint.longitude));
      }
    }

    polylineSet.clear();
    Polyline polyline = Polyline(
      polylineId: const PolylineId('polylineID'),
      color: Colors.lightBlue,
      points: polylineCoOrdinates,
      jointType: JointType.round,
      width: 4,
      startCap: Cap.roundCap,
      endCap: Cap.roundCap,
      geodesic: true,
    );

    polylineSet.add(polyline);

    //fit the polyline into the map
    LatLngBounds boundsLatLng;
    if (pickupGeoGraphicCoOrdinates.latitude >
            dropOffDestinationGeoGraphicCoOrdinates.latitude &&
        pickupGeoGraphicCoOrdinates.longitude >
            dropOffDestinationGeoGraphicCoOrdinates.longitude) {
      boundsLatLng = LatLngBounds(
        southwest: dropOffDestinationGeoGraphicCoOrdinates,
        northeast: pickupGeoGraphicCoOrdinates,
      );
    } else if (pickupGeoGraphicCoOrdinates.longitude >
        dropOffDestinationGeoGraphicCoOrdinates.longitude) {
      boundsLatLng = LatLngBounds(
        southwest: LatLng(
          pickupGeoGraphicCoOrdinates.latitude,
          dropOffDestinationGeoGraphicCoOrdinates.longitude,
        ),
        northeast: LatLng(
          dropOffDestinationGeoGraphicCoOrdinates.latitude,
          pickupGeoGraphicCoOrdinates.longitude,
        ),
      );
    } else if (pickupGeoGraphicCoOrdinates.latitude >
        dropOffDestinationGeoGraphicCoOrdinates.latitude) {
      boundsLatLng = LatLngBounds(
        southwest: LatLng(
          dropOffDestinationGeoGraphicCoOrdinates.latitude,
          pickupGeoGraphicCoOrdinates.longitude,
        ),
        northeast: LatLng(
          pickupGeoGraphicCoOrdinates.latitude,
          dropOffDestinationGeoGraphicCoOrdinates.longitude,
        ),
      );
    } else {
      boundsLatLng = LatLngBounds(
        southwest: pickupGeoGraphicCoOrdinates,
        northeast: dropOffDestinationGeoGraphicCoOrdinates,
      );
    }

    controllerGoogleMap!
        .animateCamera(CameraUpdate.newLatLngBounds(boundsLatLng, 72));

    //add markers to pickup and dropOffDestination points
    Marker pickUpPointMarker = Marker(
      markerId: const MarkerId('pickUpPointMarkerID'),
      position: pickupGeoGraphicCoOrdinates,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      infoWindow: InfoWindow(
        title: pickUpLocation.placeName,
        snippet: 'Pickup Location',
      ),
    );

    Marker dropOffDestinationPointMarker = Marker(
      markerId: const MarkerId('dropOffDestinationPointMarkerID'),
      position: dropOffDestinationGeoGraphicCoOrdinates,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      infoWindow: InfoWindow(
        title: dropOffDestinationLocation.placeName,
        snippet: 'Destination Location',
      ),
    );

    markerSet.add(pickUpPointMarker);
    markerSet.add(dropOffDestinationPointMarker);

    //add circles to pickup and dropOffDestination points
    Circle pickUpPointCircle = Circle(
      circleId: const CircleId('pickupCircleID'),
      strokeColor: Colors.blue,
      strokeWidth: 4,
      radius: 14,
      center: pickupGeoGraphicCoOrdinates,
      fillColor: Colors.pink,
    );

    Circle dropOffDestinationPointCircle = Circle(
      circleId: const CircleId('dropOffDestinationCircleID'),
      strokeColor: Colors.blue,
      strokeWidth: 4,
      radius: 14,
      center: dropOffDestinationGeoGraphicCoOrdinates,
      fillColor: Colors.pink,
    );

    setState(() {
      circleSet.add(pickUpPointCircle);
      circleSet.add(dropOffDestinationPointCircle);
      polylineSet;
      tripDirectionDetailsInfo;
      markerSet;
      searchContainerHeight = 0;
      bottomMapPadding = 280;
      rideDetailsContainerHeight = 242;
      isDrawerOpened = false;
    });
  }

  Future<void> displayRequestContainer() async {
    setState(() {
      rideDetailsContainerHeight = 0;
      requestContainerHeight = 220;
      bottomMapPadding = 250;
      isDrawerOpened = true;
    });

    //send ride request
    await makeTripRequest();
  }

  makeTripRequest() async {
    tripRequestRef =
        FirebaseDatabase.instance.ref().child('tripRequests').push();
    var pickUpLocation = ref.read(appInfoControllerProvider).pickUpLocation;
    var dropOffDestinationLocation =
        ref.read(appInfoControllerProvider).dropOffLocation;
    Map pickUpCoOrdinatesMap = {
      'latitude': pickUpLocation!.latitudePosition.toString(),
      'longitude': pickUpLocation.longitudePosition.toString(),
    };
    Map dropOffDestinationCoOrdinatesMap = {
      'latitude': dropOffDestinationLocation!.latitudePosition.toString(),
      'longitude': dropOffDestinationLocation.longitudePosition.toString(),
    };
    Map driverCoOrdinates = {
      'latitude': '',
      'longitude': '',
    };

    Map dataMap = {
      'tripID': tripRequestRef!.key,
      'publishDateTime': DateTime.now().toString(),
      'userName': userName,
      'userPhone': userPhone,
      'userID': currentUser?.uid,
      'pickUpLatLng': pickUpCoOrdinatesMap,
      'dropOffLatLng': dropOffDestinationCoOrdinatesMap,
      'pickUpAddress': pickUpLocation.placeName,
      'dropOffAddress': dropOffDestinationLocation.placeName,
      'driverID': 'waiting',
      'carDetails': '',
      'driverLocation': driverCoOrdinates,
      'driverName': '',
      'driverPhone': '',
      'driverPhoto': '',
      'fareAmount': '',
      'status': 'new',
    };

    await tripRequestRef!.set(dataMap);

    tripStreamSubscription =
        tripRequestRef!.onValue.listen((eventSnapshot) async {
      if (eventSnapshot.snapshot.value == null) {
        return;
      }

      if ((eventSnapshot.snapshot.value as Map)['driverName'] != null) {
        nameDriver = (eventSnapshot.snapshot.value as Map)['driverName'];
      }

      if ((eventSnapshot.snapshot.value as Map)['driverPhone'] != null) {
        phoneNumberDriver =
            (eventSnapshot.snapshot.value as Map)['driverPhone'];
      }

      if ((eventSnapshot.snapshot.value as Map)['driverPhoto'] != null) {
        photoDriver = (eventSnapshot.snapshot.value as Map)['driverPhoto'];
      }

      if ((eventSnapshot.snapshot.value as Map)['carDetails'] != null) {
        carDetailsDriver = (eventSnapshot.snapshot.value as Map)['carDetails'];
      }

      if ((eventSnapshot.snapshot.value as Map)['status'] != null) {
        status = (eventSnapshot.snapshot.value as Map)['status'];
      }

      if ((eventSnapshot.snapshot.value as Map)['driverLocation'] != null) {
        double driverLatitude = double.parse(
          (eventSnapshot.snapshot.value as Map)['driverLocation']['latitude']
              .toString(),
        );
        double driverLongitude = double.parse(
          (eventSnapshot.snapshot.value as Map)['driverLocation']['longitude']
              .toString(),
        );
        LatLng driverCurrentLocationLatLng =
            LatLng(driverLatitude, driverLongitude);

        if (status == 'accepted') {
          //update info for pickup to user on UI
          //info from driver current location to user pickup location
          updateFromDriverCurrentLocationToPickUp(driverCurrentLocationLatLng);
        } else if (status == 'arrived') {
          //update info for arrived - when driver reach at the pickup point of user
          setState(() {
            tripStatusDisplay = 'Driver has Arrived';
          });
        } else if (status == 'contrib') {
          //update info for drop-off to user on UI
          //info from driver current location to user drop-off location
          updateFromDriverCurrentLocationToDropOffDestination(
            driverCurrentLocationLatLng,
          );
        }
      }

      if (status == 'accepted') {
        Geofire.stopListener();

        //remove drivers markers
        setState(() {
          requestContainerHeight = 0;
          tripContainerHeight = 340;
          bottomMapPadding = 330;
          markerSet.removeWhere(
            (element) => element.markerId.value.contains('driver'),
          );
        });
      }

      if (status == 'ended') {
        if ((eventSnapshot.snapshot.value as Map)['fareAmount'] != null) {
          double fareAmount = double.parse(
            (eventSnapshot.snapshot.value as Map)['fareAmount'].toString(),
          );

          var responseFromPaymentDialog = await showDialog(
            context: context,
            builder: (BuildContext context) =>
                PaymentDialog(fareAmount: fareAmount.toString()),
          );

          if (responseFromPaymentDialog == 'paid') {
            tripRequestRef!.onDisconnect();
            tripRequestRef = null;

            tripStreamSubscription!.cancel();
            tripStreamSubscription = null;

            resetAppNow();
            Restart.restartApp(webOrigin: 'HomeScreen');
          }
        }
      }
    });
  }

  resetAppNow() {
    setState(() {
      polylineCoOrdinates.clear();
      polylineSet.clear();
      markerSet.clear();
      circleSet.clear();
      rideDetailsContainerHeight = 0;
      requestContainerHeight = 0;
      tripContainerHeight = 0;
      searchContainerHeight = 276;
      bottomMapPadding = 350;
      isDrawerOpened = true;

      status = '';
      nameDriver = '';
      photoDriver = '';
      phoneNumberDriver = '';
      carDetailsDriver = '';
      tripStatusDisplay = 'Driver is Arriving';
    });
  }

  updateFromDriverCurrentLocationToPickUp(driverCurrentLocationLatLng) async {
    if (!requestingDirectionDetailsInfo) {
      requestingDirectionDetailsInfo = true;

      var userPickUpLocationLatLng = LatLng(
        currentPositionOfUser!.latitude,
        currentPositionOfUser!.longitude,
      );

      var directionDetailsPickup =
          await CommonHelper.getDirectionDetailsFromAPI(
        driverCurrentLocationLatLng,
        userPickUpLocationLatLng,
        test: 2,
      );

      if (directionDetailsPickup == null) return;

      setState(() {
        tripStatusDisplay =
            'Driver is Coming - ${directionDetailsPickup.durationTextString}';
      });

      requestingDirectionDetailsInfo = false;
    }
  }

  updateFromDriverCurrentLocationToDropOffDestination(
    driverCurrentLocationLatLng,
  ) async {
    if (!requestingDirectionDetailsInfo) {
      requestingDirectionDetailsInfo = true;

      var dropOffLocation = ref.read(appInfoControllerProvider).dropOffLocation;
      var userDropOffLocationLatLng = LatLng(
        dropOffLocation!.latitudePosition!,
        dropOffLocation.longitudePosition!,
      );

      var directionDetailsPickup =
          await CommonHelper.getDirectionDetailsFromAPI(
        driverCurrentLocationLatLng,
        userDropOffLocationLatLng,
      );

      if (directionDetailsPickup == null) {
        return;
      }

      setState(() {
        tripStatusDisplay =
            'Driving to DropOff Location - ${directionDetailsPickup.durationTextString}';
      });

      requestingDirectionDetailsInfo = false;
    }
  }

  searchDriver() {
    if (availableNearbyOnlineDriversList!.isEmpty) {
      cancelRideRequest();
      resetAppNow();
      noDriverAvailable();
      return;
    }

    var currentDriver = availableNearbyOnlineDriversList![0];

    //send notification to this currentDriver - currentDriver means selected driver
    sendNotificationToDriver(currentDriver);

    // TODO because remove driver out of list so in google map you can not see driver point
    availableNearbyOnlineDriversList!.removeAt(0);
  }

  noDriverAvailable() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => const InfoDialog(
        title: 'No Driver Available',
        description:
            'No driver found in the nearby location. Please try again shortly.',
      ),
    );
  }

  sendNotificationToDriver(OnlineNearbyDrivers currentDriver) async {
    //update driver's newTripStatus - assign tripID to current driver
    Driver currentDriverResp = await ref.read(userServiceProvider).fetchDriver(
          IFetchDriverParams(uid: currentDriver.uidDriver.toString()),
        );

    await ref.read(userServiceProvider).updateDriver(
          IUpdateDriverParams(
            id: currentDriverResp.id.toString(),
            newTripStatus: tripRequestRef!.key,
          ),
        );

    if (currentDriverResp.deviceToken.length > 2) {
      ref
          .read(pushNotificationServiceProvider)
          .sendNotificationToSelectedDriver(
            currentDriverResp.deviceToken,
            tripRequestRef!.key.toString(),
          );
    } else {
      return;
    }

    const oneTickPerSec = Duration(seconds: 4);

    var timerCountDown = Timer.periodic(oneTickPerSec, (timer) async {
      requestTimeoutDriver = requestTimeoutDriver - 1;

      //when trip request is not requesting means trip request cancelled - stop timer
      if (stateOfApp != 'requesting') {
        timer.cancel();
        await ref.read(userServiceProvider).updateDriver(
              IUpdateDriverParams(
                id: currentDriverResp.id.toString(),
                newTripStatus: 'cancelled',
              ),
            );
        requestTimeoutDriver = 20;
      }

      currentDriverResp = await ref.read(userServiceProvider).fetchDriver(
            IFetchDriverParams(uid: currentDriver.uidDriver.toString()),
          );
      if (currentDriverResp.newTripStatus == 'accepted') {
        timer.cancel();
        requestTimeoutDriver = 20;
      }

      //if 20 seconds passed - send notification to next nearest online available driver
      if (requestTimeoutDriver == 0) {
        await ref.read(userServiceProvider).updateDriver(
              IUpdateDriverParams(
                id: currentDriverResp.id.toString(),
                newTripStatus: 'timeout',
              ),
            );
        timer.cancel();
        requestTimeoutDriver = 20;

        //send notification to next nearest online available driver
        searchDriver();
      }
    });
  }

  cancelRideRequest() {
    //remove ride request from database
    tripRequestRef!.remove();

    setState(() {
      stateOfApp = 'normal';
    });
  }
}
