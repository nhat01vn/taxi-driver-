import 'package:flutter/material.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/presentation/screens/home/bottom_nav/account/account_bottom_nav.dart';
import 'package:futter_user/src/presentation/screens/home/bottom_nav/home/home_bottom_nav.dart';
import 'package:futter_user/src/presentation/screens/home/bottom_nav/trips_history/trips_history_bottom_nav.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/bottom_app_bar_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    this.bottomNavSelected = 0,
  });

  final int bottomNavSelected;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  int _currentBottomNavSelected = 0;
  List<Widget> _bottomNavContents = [];

  @override
  void initState() {
    super.initState();

    _currentBottomNavSelected = widget.bottomNavSelected;
    _bottomNavContents = <Widget>[
      const HomeBottomNav(),
      const TripsHistoryBottomNav(),
      const AccountBottomNav(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      padding: const EdgeInsets.all(0),
      bottomNavigationBar: _bottomNavigationBar(),
      child: _bottomNavContents.elementAt(_currentBottomNavSelected),
    );
  }

  BottomAppBar _bottomNavigationBar() {
    return BottomAppBar(
      padding: const EdgeInsets.only(bottom: 10),
      color: AppColor.white,
      shape: const CircularNotchedRectangle(),
      notchMargin: 3,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          BottomAppBarItem(
            navKey: 0,
            asset: AppAsset.icoHome,
            assetHeight: 22,
            label: 'Home',
            currentBottomNavSelected: _currentBottomNavSelected,
            onBottomNavSelected: onBottomNavSelected,
          ),
          BottomAppBarItem(
            navKey: 1,
            asset: AppAsset.icoHistory,
            label: 'History',
            currentBottomNavSelected: _currentBottomNavSelected,
            onBottomNavSelected: onBottomNavSelected,
          ),
          BottomAppBarItem(
            navKey: 2,
            asset: AppAsset.icoAccount,
            label: 'Account',
            currentBottomNavSelected: _currentBottomNavSelected,
            onBottomNavSelected: onBottomNavSelected,
          ),
        ],
      ),
    );
  }

  onBottomNavSelected(int navKey) {
    setState(() {
      _currentBottomNavSelected = navKey;
    });
  }
}
