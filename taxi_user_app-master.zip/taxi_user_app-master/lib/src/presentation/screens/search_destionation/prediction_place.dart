import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/constants/app_config.dart';
import 'package:futter_user/src/data_sample/variable.dart';
import 'package:futter_user/src/domain/address_model.dart';
import 'package:futter_user/src/domain/prediction_model.dart';
import 'package:futter_user/src/presentation/controllers/app_info.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';

class PredictionPlace extends ConsumerStatefulWidget {
  final PredictionModel? predictedPlaceData;
  final bool isPickUpSearch;
  final VoidCallback onTap;

  const PredictionPlace({
    super.key,
    this.predictedPlaceData,
    required this.isPickUpSearch,
    required this.onTap,
  });

  @override
  ConsumerState<PredictionPlace> createState() => _PredictionPlaceState();
}

class _PredictionPlaceState extends ConsumerState<PredictionPlace> {
  ///Place Details - Places API
  fetchClickedPlaceDetails(String placeID) async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) =>
          const LoadingDialog(messageText: 'Getting details...'),
    );

    String urlPlaceDetailsAPI =
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeID&key=$googleMapKey';
// TODO for debug
    var responseFromPlaceDetailsAPI = fetchClickedPlaceDetailsData as Map;
    // var responseFromPlaceDetailsAPI =
    //     await CommonHelper.sendRequestToAPI(urlPlaceDetailsAPI);

    if (mounted) Navigator.pop(context);

    if (responseFromPlaceDetailsAPI == 'error') {
      return;
    }

    if (responseFromPlaceDetailsAPI['status'] == 'OK') {
      AddressModel location = AddressModel();

      location.humanReadableAddress =
          responseFromPlaceDetailsAPI['result']['formatted_address'];
      location.placeName = responseFromPlaceDetailsAPI['result']['name'];
      location.latitudePosition =
          responseFromPlaceDetailsAPI['result']['geometry']['location']['lat'];
      location.longitudePosition =
          responseFromPlaceDetailsAPI['result']['geometry']['location']['lng'];
      location.placeID = placeID;

      if (widget.isPickUpSearch) {
        ref
            .read(appInfoControllerProvider.notifier)
            .updatePickUpLocation(location);
      } else {
        ref
            .read(appInfoControllerProvider.notifier)
            .updateDropOffLocation(location);
      }
      widget.onTap();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        fetchClickedPlaceDetails(
          widget.predictedPlaceData!.placeId.toString(),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
      ),
      child: SizedBox(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                const Icon(
                  Icons.share_location,
                  color: Colors.grey,
                ),
                const SizedBox(
                  width: 13,
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        widget.predictedPlaceData!.mainText.toString(),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(
                        height: 3,
                      ),
                      Text(
                        widget.predictedPlaceData!.secondaryText.toString(),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
