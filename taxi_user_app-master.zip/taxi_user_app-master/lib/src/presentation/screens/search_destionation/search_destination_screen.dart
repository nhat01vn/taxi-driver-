import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_config.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/data_sample/variable.dart';
import 'package:futter_user/src/domain/prediction_model.dart';
import 'package:futter_user/src/presentation/controllers/app_info.dart';
import 'package:futter_user/src/presentation/screens/search_destionation/prediction_place.dart';

class SearchDestinationScreen extends ConsumerStatefulWidget {
  const SearchDestinationScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<SearchDestinationScreen> createState() =>
      _SearchDestinationScreenState();
}

class _SearchDestinationScreenState
    extends ConsumerState<SearchDestinationScreen> {
  TextEditingController pickUpTextEditingController = TextEditingController();
  TextEditingController destinationTextEditingController =
      TextEditingController();
  Timer? searchTimer;
  List<PredictionModel> predictionsPlacesList = [];
  bool isPickUpSearch = false;
  String userAddress = '';
  String userDestinationAddress = '';

  @override
  void initState() {
    _fetchUserAddress();
    super.initState();
  }

  void _fetchUserAddress() {
    setState(() {
      userAddress = ref
              .read(appInfoControllerProvider)
              .pickUpLocation
              ?.humanReadableAddress ??
          '';
      pickUpTextEditingController.text = userAddress;
    });
  }

  void _fetchUserDestinationAddress() {
    setState(() {
      userDestinationAddress = ref
              .read(appInfoControllerProvider)
              .dropOffLocation
              ?.humanReadableAddress ??
          '';
      destinationTextEditingController.text = userDestinationAddress;
    });
  }

  void searchLocation(String locationName, bool isSearch) {
    searchTimer?.cancel();

    searchTimer = Timer(const Duration(milliseconds: 800), () async {
      if (locationName.length > 1) {
        String apiPlacesUrl =
            'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$locationName&key=$googleMapKey&components=country:vn';
        // TODO for debug
        var responseFromPlacesAPI = searchLocationData as Map;
        // var responseFromPlacesAPI =
        //     await CommonHelper.sendRequestToAPI(apiPlacesUrl);
        if (responseFromPlacesAPI == 'error') return;

        if (responseFromPlacesAPI['status'] == 'OK') {
          var predictionResultInJson = responseFromPlacesAPI['predictions'];
          var predictionsList = (predictionResultInJson as List)
              .map(
                (eachPlacePrediction) =>
                    PredictionModel.fromJson(eachPlacePrediction),
              )
              .toList();

          setState(() {
            isPickUpSearch = isSearch;
            predictionsPlacesList = predictionsList;
          });
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Card(
              elevation: 10,
              child: Container(
                height: 250,
                decoration: const BoxDecoration(
                  color: AppColor.primary,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 5.0,
                      spreadRadius: 0.5,
                      offset: Offset(0.7, 0.7),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 24,
                    top: 48,
                    right: 24,
                    bottom: 20,
                  ),
                  child: Column(
                    children: [
                      const SizedBox(height: 6),
                      //icon button - title
                      Stack(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                          ),
                          const Center(
                            child: Text(
                              'Set Drop-off Location',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      //pickup text field
                      Row(
                        children: [
                          Image.asset(
                            'assets/images/initial.png',
                            height: 16,
                            width: 16,
                          ),
                          const SizedBox(width: 18),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white54,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(3),
                                child: TextField(
                                  controller: pickUpTextEditingController,
                                  onChanged: (inputText) {
                                    searchLocation(inputText, true);
                                  },
                                  decoration: const InputDecoration(
                                    hintText: 'Pickup Address',
                                    fillColor: Colors.white38,
                                    filled: true,
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(
                                      left: 11,
                                      top: 9,
                                      bottom: 9,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 11),
                      //destination text field
                      Row(
                        children: [
                          Image.asset(
                            'assets/images/final.png',
                            height: 16,
                            width: 16,
                          ),
                          const SizedBox(width: 18),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white54,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(3),
                                child: TextField(
                                  controller: destinationTextEditingController,
                                  onChanged: (inputText) {
                                    searchLocation(inputText, false);
                                  },
                                  decoration: const InputDecoration(
                                    hintText: 'Destination Address',
                                    fillColor: Colors.white38,
                                    filled: true,
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(
                                      left: 11,
                                      top: 9,
                                      bottom: 9,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      GestureDetector(
                        onTap: () => {
                          if (pickUpTextEditingController.text
                                  .trim()
                                  .isNotEmpty &&
                              destinationTextEditingController.text
                                  .trim()
                                  .isNotEmpty)
                            Navigator.pop(context, 'placeSelected'),
                        },
                        child: Text(
                          'Submit',
                          textAlign: TextAlign.center,
                          style: TextStyles.defaultStyle.h6.fWBold.blackColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // display prediction results for destination place
            (predictionsPlacesList.isNotEmpty)
                ? Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    child: ListView.separated(
                      padding: const EdgeInsets.all(0),
                      itemBuilder: (context, index) {
                        return Card(
                          elevation: 3,
                          child: PredictionPlace(
                            predictedPlaceData: predictionsPlacesList[index],
                            isPickUpSearch: isPickUpSearch,
                            onTap: isPickUpSearch
                                ? _fetchUserAddress
                                : _fetchUserDestinationAddress,
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) =>
                          const SizedBox(height: 2),
                      itemCount: predictionsPlacesList.length,
                      shrinkWrap: true,
                      physics: const ClampingScrollPhysics(),
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }
}
