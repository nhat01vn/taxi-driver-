import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/domain/address_model.dart';

class AppInfoState {
  final AddressModel? pickUpLocation;
  final AddressModel? dropOffLocation;

  AppInfoState({this.pickUpLocation, this.dropOffLocation});

  AppInfoState copyWith({
    AddressModel? pickUpLocation,
    AddressModel? dropOffLocation,
  }) {
    return AppInfoState(
      pickUpLocation: pickUpLocation ?? this.pickUpLocation,
      dropOffLocation: dropOffLocation ?? this.dropOffLocation,
    );
  }

  @override
  bool operator ==(covariant AppInfoState other) {
    if (identical(this, other)) return true;

    return other.pickUpLocation == pickUpLocation &&
        other.dropOffLocation == dropOffLocation;
  }

  @override
  int get hashCode {
    return pickUpLocation.hashCode ^ dropOffLocation.hashCode;
  }
}

class AppInfoController extends StateNotifier<AppInfoState> {
  AppInfoController() : super(AppInfoState());

  void updatePickUpLocation(AddressModel pickUpModel) {
    state = state.copyWith(pickUpLocation: pickUpModel);
  }

  void updateDropOffLocation(AddressModel dropOffModel) {
    state = state.copyWith(dropOffLocation: dropOffModel);
  }
}

final appInfoControllerProvider =
    StateNotifierProvider<AppInfoController, AppInfoState>((ref) {
  return AppInfoController();
});
