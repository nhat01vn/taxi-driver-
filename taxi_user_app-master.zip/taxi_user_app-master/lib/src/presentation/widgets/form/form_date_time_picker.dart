import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:intl/intl.dart';

class FormDateTimePicker extends StatelessWidget {
  const FormDateTimePicker({
    Key? key,
    required this.name,
    required this.format,
    this.initialEntryMode = DatePickerEntryMode.calendarOnly,
    required this.initialValue,
    this.inputType = InputType.date,
    this.contentPadding = const EdgeInsets.only(
      left: 0.0,
      right: 15.0,
      bottom: 15.0,
      top: 15.0,
    ),
    this.suffixIcon = const Icon(Icons.calendar_month),
    this.fillColor = AppColor.white,
    this.border = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide.none,
    ),
    this.enabledBorder = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide(width: 1, color: AppColor.gray200),
    ),
  }) : super(key: key);

  final String name;
  final DateFormat format;
  final DatePickerEntryMode initialEntryMode;
  final DateTime initialValue;
  final InputType inputType;
  final EdgeInsetsGeometry? contentPadding;
  final Widget? suffixIcon;
  final Color? fillColor;
  final InputBorder? border;
  final InputBorder? enabledBorder;

  @override
  Widget build(BuildContext context) {
    return FormBuilderDateTimePicker(
      name: name,
      format: format,
      initialEntryMode: initialEntryMode,
      initialValue: initialValue,
      inputType: inputType,
      decoration: InputDecoration(
        contentPadding: contentPadding,
        suffixIcon: suffixIcon,
        prefix: const Padding(padding: EdgeInsets.only(left: 15.0)),
        filled: true,
        fillColor: fillColor,
        border: border,
        enabledBorder: enabledBorder,
      ),
    );
  }
}
