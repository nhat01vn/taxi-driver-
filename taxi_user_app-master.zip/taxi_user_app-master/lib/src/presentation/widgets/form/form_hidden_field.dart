import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';

class FormHiddenField extends StatefulWidget {
  const FormHiddenField({super.key, required this.name, required this.value});

  final String name;
  final String value;

  @override
  State<FormHiddenField> createState() => _FormHiddenFieldState();
}

class _FormHiddenFieldState extends State<FormHiddenField> {
  final TextEditingController _textFieldController = TextEditingController();

  @override
  void initState() {
    super.initState();

    _textFieldController.text = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    _setValue();

    return Column(
      children: [
        Visibility(
          visible: false,
          maintainState: true,
          child: FormBuilderTextField(
            controller: _textFieldController,
            name: widget.name,
          ),
        ),
      ],
    );
  }

  _setValue() {
    Timer(const Duration(seconds: 0), () {
      _textFieldController.text = widget.value;
    });
  }
}
