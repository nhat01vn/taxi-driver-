import 'package:flutter/material.dart';

class CustomToolTip extends ShapeBorder {
  @override
  EdgeInsetsGeometry get dimensions => const EdgeInsets.only(bottom: 10);

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) => Path();

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    rect =
        Rect.fromPoints(rect.topLeft, rect.bottomRight - const Offset(0, 10));
    return Path()
      ..addRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(5)),
      )
      ..moveTo(rect.bottomCenter.dx, rect.bottomCenter.dy)
      ..relativeLineTo(0, 10)
      ..relativeLineTo(9, -10)
      ..close();
  }

  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {}

  @override
  ShapeBorder scale(double t) => this;
}
