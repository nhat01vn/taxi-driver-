import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:flutter/material.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/extensions/color_ext.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/presentation/widgets/common/custom_tooltip.dart';

const List<String> letterColors = [
  '#7AB5D3',
  '#8E908C',
  '#D6B34B',
  '#7F8C8D',
  '#C18C91',
  '#2ECC71',
  '#1ABC9C',
  '#70848C',
  '#F39C12',
  '#BF9929',
  '#EA7D61',
  '#6F8092',
  '#3498DB',
  '#27AE60',
  '#E67E22',
  '#16A085',
  '#F26363',
  '#A67951',
  '#2980B9',
  '#007ED2',
  '#C0614B',
  '#718C00',
  '#D94169',
  '#AD6704',
  '#4271AE',
  '#7A6D31',
  '#D35400',
  '#A45D33',
  '#9B59B6',
  '#5B6B3C',
  '#0A7373',
  '#2D6987',
  '#96505B',
  '#7A577A',
  '#1F6377',
  '#C0392B',
  '#8E44AD',
  '#155A95',
  '#8D414D',
  '#734E40',
  '#953B39',
  '#4D4D4C',
  '#8C355E',
  '#843A27',
  '#025259',
  '#733250',
  '#0045B7',
  '#34495E',
  '#8C1F28',
  '#8C2823',
  '#473710',
];

class UserAvatar extends StatefulWidget {
  const UserAvatar({
    super.key,
    required this.size,
    this.name = 'Kitty Money',
    this.imageUrl = '',
    this.margin = EdgeInsets.zero,
    this.padding = EdgeInsets.zero,
    this.onTap,
    this.selectable = false,
    this.selected = false,
    this.selectedIconSize = 20,
  });

  final bool selectable;
  final bool selected;
  final double selectedIconSize;
  final double size;
  final String name;
  final String imageUrl;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final Function(String value, bool isSelected)? onTap;

  @override
  State<UserAvatar> createState() => _UserAvatarState();
}

class _UserAvatarState extends State<UserAvatar> {
  bool _isSelected = false;

  @override
  void initState() {
    super.initState();

    _isSelected = widget.selected;
  }

  @override
  void didUpdateWidget(covariant UserAvatar oldWidget) {
    _isSelected = widget.selected;
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    final GlobalKey<TooltipState> tooltipKey = GlobalKey<TooltipState>();

    return Container(
      margin: widget.margin,
      padding: widget.padding,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Tooltip(
            message: widget.name,
            key: tooltipKey,
            triggerMode: TooltipTriggerMode.manual,
            decoration: ShapeDecoration(
              shape: CustomToolTip(),
              color: AppColor.green,
            ),
            padding: const EdgeInsets.all(12.0),
            preferBelow: false,
            textStyle: const TextStyle(
              color: AppColor.white,
              fontSize: 16,
            ),
            child: CircularProfileAvatar(
              widget.imageUrl,
              radius: widget.size,
              backgroundColor: AppColor.transparent,
              borderWidth: 0,
              initialsText: Text(
                _nameLetters(),
                style: TextStyles.defaultStyle.whiteColor.fWMedium
                    .fSize(widget.size - 2),
              ),
              borderColor: _avatarColor(),
              foregroundColor: _avatarColor(),
              cacheImage: true,
              onTap: () {
                tooltipKey.currentState?.ensureTooltipVisible();

                if (widget.selectable) {
                  setState(() {
                    _isSelected = !_isSelected;
                  });

                  if (widget.onTap != null) {
                    widget.onTap!(widget.name, _isSelected);
                  }
                }
              },
            ),
          ),
          Visibility(
            visible: _isSelected && widget.selectable,
            child: Positioned(
              top: -3,
              right: -1,
              child: Container(
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: AppColor.primary,
                ),
                child: Icon(
                  Icons.check,
                  color: AppColor.white,
                  size: widget.selectedIconSize,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _avatarColor() {
    final int colorIndex =
        (_nameLetters().codeUnitAt(0) + _nameLetters().codeUnitAt(1)) %
            letterColors.length;
    final String colorHex = letterColors[colorIndex];

    return HexColor(colorHex);
  }

  String _nameLetters() {
    final nameParts =
        widget.name.trim().toUpperCase().split(RegExp(r'\.|_|\s'));
    if (widget.name.isEmpty || nameParts.isEmpty) return 'KM';

    String firstLetter = nameParts[0][0];
    String secondLetter = '';

    if (nameParts.length == 1) {
      secondLetter = nameParts[0].length > 1
          ? nameParts[0][nameParts[0].length - 1]
          : firstLetter;
    } else {
      secondLetter = nameParts[nameParts.length - 1][0];
    }

    return '$firstLetter$secondLetter';
  }
}
