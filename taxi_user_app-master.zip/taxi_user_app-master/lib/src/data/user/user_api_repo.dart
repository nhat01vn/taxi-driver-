import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/core/utilities/backend_api.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:futter_user/src/domain/driver.dart';
import 'package:futter_user/src/domain/user.dart';

class UserApiRepository implements UserRepository {
  @override
  Future<User> createUser(ICreateUserParams params) async {
    final user = await BackendAPI.makeRequest(
      'POST',
      '/user',
      data: {
        'name': params.name,
        'email': params.email,
        'password': params.password,
        'phone': params.phone,
        'role': 'client',
      },
    );

    return User.fromMap(user);
  }

  @override
  Future<User> fetchUser(IFetchUserParams params) async {
    final user = await BackendAPI.makeRequest(
      'GET',
      '/client/${params.id}',
      data: {},
    );

    return User.fromMap(user);
  }

  @override
  Future<Driver> fetchDriver(IFetchDriverParams params) async {
    final user = await BackendAPI.makeRequest(
      'GET',
      '/driver/${params.uid}',
      data: {},
    );

    return Driver.fromMap(user);
  }

  @override
  Future<dynamic> updateDriver(
    IUpdateDriverParams params,
  ) async {
    return await BackendAPI.makeRequest(
      'PATCH',
      '/driver/update',
      data: {
        'id': params.id,
        if (params.newTripStatus != null) 'newTripStatus': params.newTripStatus,
        if (params.lat != null) 'lat': params.lat,
        if (params.long != null) 'long': params.long,
        if (params.deviceToken != null) 'deviceToken': params.deviceToken,
        if (params.status != null) 'status': params.status,
      },
    );
  }

  @override
  Future<dynamic> forgotPassword(IForgotPasswordParams params) async {
    return await BackendAPI.makeRequest(
      'POST',
      '/user/forgot-password',
      data: {
        'email': params.email,
        'role': 'client',
      },
    );
  }

  @override
  Future<dynamic> resetPassword(IResetPasswordParams params) async {
    return BackendAPI.makeRequest(
      'POST',
      '/user/reset-password',
      data: {
        'resetToken': params.resetToken,
        'role': 'client',
        'password': params.password,
        'confirmationPassword': params.passwordConfirmation,
      },
    );
  }
}
