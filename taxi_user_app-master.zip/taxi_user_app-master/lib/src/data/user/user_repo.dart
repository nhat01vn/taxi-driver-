import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/domain/driver.dart';
import 'package:futter_user/src/domain/user.dart';

abstract class UserRepository {
  Future<User> createUser(ICreateUserParams params);

  Future<dynamic> forgotPassword(IForgotPasswordParams params);

  Future<dynamic> resetPassword(IResetPasswordParams params);

  Future<User> fetchUser(IFetchUserParams params);

  Future<Driver> fetchDriver(IFetchDriverParams params);

  Future<dynamic> updateDriver(IUpdateDriverParams params);
}

final userRepositoryProvider = Provider<UserRepository>((ref) {
  throw UnimplementedError();
});
