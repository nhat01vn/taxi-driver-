class AddressModel {
  String? humanReadableAddress;
  double? latitudePosition;
  double? longitudePosition;
  String? placeID;
  String? placeName;

  AddressModel({
    this.humanReadableAddress,
    this.latitudePosition,
    this.longitudePosition,
    this.placeID,
    this.placeName,
  });

  @override
  String toString() {
    return 'AddressModel(humanReadableAddress: $humanReadableAddress, latitudePosition: $latitudePosition, longitudePosition: $longitudePosition, placeID: $placeID, placeName: $placeName)';
  }

  @override
  bool operator ==(covariant AddressModel other) {
    if (identical(this, other)) return true;

    return other.humanReadableAddress == humanReadableAddress &&
        other.latitudePosition == latitudePosition &&
        other.longitudePosition == longitudePosition &&
        other.placeID == placeID &&
        other.placeName == placeName;
  }

  @override
  int get hashCode {
    return humanReadableAddress.hashCode ^
        latitudePosition.hashCode ^
        longitudePosition.hashCode ^
        placeID.hashCode ^
        placeName.hashCode;
  }
}
