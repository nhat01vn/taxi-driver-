class OnlineNearbyDrivers {
  String? uidDriver;
  double? latDriver;
  double? lngDriver;

  OnlineNearbyDrivers({
    this.uidDriver,
    this.latDriver,
    this.lngDriver,
  });
}
