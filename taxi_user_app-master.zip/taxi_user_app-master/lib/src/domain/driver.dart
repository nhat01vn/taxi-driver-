import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first

class Driver {
  Driver({
    required this.id,
    required this.uid,
    required this.name,
    required this.phone,
    required this.email,
    required this.status,
    required this.blockStatus,
    required this.lat,
    required this.long,
    required this.carModel,
    required this.carNumber,
    required this.photo,
    required this.deviceToken,
    required this.newTripStatus,
  });

  final int id;
  final String uid;
  final String name;
  final String phone;
  final String email;
  final String status;
  final String blockStatus;
  final double lat;
  final double long;
  final String carModel;
  final String carNumber;
  final String photo;
  final String deviceToken;
  final String newTripStatus;

  static Driver createEmpty() {
    return Driver(
      id: 0,
      uid: '',
      name: '',
      phone: '',
      email: '',
      status: '',
      blockStatus: 'no',
      lat: 0,
      long: 0,
      carModel: '',
      carNumber: '',
      photo: '',
      deviceToken: '',
      newTripStatus: '',
    );
  }

  static List<Driver> fromListMap(List users) {
    if (users.isEmpty) return List<Driver>.from([]);

    return List<Driver>.from(
      users.map((user) => Driver.fromMap(Map<String, dynamic>.from(user!))),
    );
  }

  Driver copyWith({
    int? id,
    String? uid,
    String? name,
    String? phone,
    String? email,
    String? status,
    String? blockStatus,
    double? lat,
    double? long,
    String? carModel,
    String? carNumber,
    String? photo,
    String? deviceToken,
    String? newTripStatus,
  }) {
    return Driver(
      id: id ?? this.id,
      uid: uid ?? this.uid,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      status: status ?? this.status,
      lat: lat ?? this.lat,
      long: long ?? this.long,
      blockStatus: blockStatus ?? this.blockStatus,
      carModel: carModel ?? this.carModel,
      carNumber: carNumber ?? this.carNumber,
      photo: photo ?? this.photo,
      deviceToken: deviceToken ?? this.deviceToken,
      newTripStatus: newTripStatus ?? this.newTripStatus,
    );
  }

  @override
  String toString() {
    return 'Driver(id: $id, uid: $uid, name: $name, phone: $phone, email: $email, status: $status, blockStatus: $blockStatus, lat: $lat, long: $long, carModel: $carModel, carNumber: $carNumber, photo: $photo, deviceToken: $deviceToken, newTripStatus: $newTripStatus)';
  }

  @override
  bool operator ==(covariant Driver other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.uid == uid &&
        other.name == name &&
        other.phone == phone &&
        other.email == email &&
        other.status == status &&
        other.lat == lat &&
        other.long == long &&
        other.carModel == carModel &&
        other.carNumber == carNumber &&
        other.photo == photo &&
        other.deviceToken == deviceToken &&
        other.newTripStatus == newTripStatus &&
        other.blockStatus == blockStatus;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        uid.hashCode ^
        name.hashCode ^
        phone.hashCode ^
        email.hashCode ^
        status.hashCode ^
        lat.hashCode ^
        long.hashCode ^
        photo.hashCode ^
        newTripStatus.hashCode ^
        deviceToken.hashCode ^
        blockStatus.hashCode;
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'uid': uid,
      'name': name,
      'phone': phone,
      'email': email,
      'status': status,
      'blockStatus': blockStatus,
      'lat': lat,
      'long': long,
      'photo': photo,
      'carModel': carModel,
      'carNumber': carNumber,
      'deviceToken': deviceToken,
      'newTripStatus': newTripStatus,
    };
  }

  factory Driver.fromMap(Map<String, dynamic> map) {
    return Driver(
      id: map['id'] as int,
      uid: map['uid'] as String,
      name: map['name'] as String,
      phone: map['phone'] as String,
      email: map['email'] as String,
      status: (map['status'] as bool).toString(),
      blockStatus: map['blockStatus'] as String,
      lat: map['lat'] != null ? map['lat'] as double : 0,
      long: map['long'] != null ? map['long'] as double : 0,
      photo: map['photo'] != null ? map['photo'] as String : '',
      carNumber: map['carNumber'] != null ? map['carNumber'] as String : '',
      carModel: map['carModel'] != null ? map['carModel'] as String : '',
      newTripStatus:
          map['newTripStatus'] != null ? map['newTripStatus'] as String : '',
      deviceToken:
          map['deviceToken'] != null ? map['deviceToken'] as String : '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Driver.fromJson(String source) =>
      Driver.fromMap(json.decode(source) as Map<String, dynamic>);
}
