class PredictionModel {
  String? placeId;
  String? mainText;
  String? secondaryText;

  PredictionModel({
    this.placeId,
    this.mainText,
    this.secondaryText,
  });

  PredictionModel.fromJson(Map<String, dynamic> json) {
    placeId = json['place_id'];
    mainText = json['structured_formatting']['main_text'];
    secondaryText = json['structured_formatting']['secondary_text'];
  }

  @override
  String toString() {
    return 'PredictionModel(placeId: $placeId, mainText: $mainText, secondaryText: $secondaryText)';
  }

  @override
  bool operator ==(covariant PredictionModel other) {
    if (identical(this, other)) return true;

    return other.placeId == placeId &&
        other.mainText == mainText &&
        other.secondaryText == secondaryText;
  }

  @override
  int get hashCode {
    return placeId.hashCode ^ mainText.hashCode ^ secondaryText.hashCode;
  }
}
