var convertGeoGraphicCoOrdinatesIntoHumanReadableAddressData = {
  'plus_code': {
    'compound_code': 'QMC2+H5P Tân Bình, Ho Chi Minh City, Vietnam',
    'global_code': '7P28QMC2+H5P',
  },
  'results': [
    {
      'address_components': [
        {
          'long_name': '144',
          'short_name': '144',
          'types': ['street_number'],
        },
        {
          'long_name': 'Âu Cơ',
          'short_name': 'Âu Cơ',
          'types': ['route']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political'],
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political'],
        }
      ],
      'formatted_address':
          '144 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'location': {'lat': 10.7714524, 'lng': 106.6504417},
        'location_type': 'ROOFTOP',
        'viewport': {
          'northeast': {'lat': 10.7728013802915, 'lng': 106.6517906802915},
          'southwest': {'lat': 10.7701034197085, 'lng': 106.6490927197085},
        }
      },
      'place_id': 'ChIJFZr0L_MvdTERpete8YoRKFI',
      'plus_code': {
        'compound_code': 'QMC2+H5 Tân Bình, Ho Chi Minh City, Vietnam',
        'global_code': '7P28QMC2+H5',
      },
      'types': ['establishment', 'food', 'point_of_interest']
    },
    {
      'address_components': [
        {
          'long_name': '48/8',
          'short_name': '48/8',
          'types': ['street_number'],
        },
        {
          'long_name': 'Âu Cơ',
          'short_name': 'Âu Cơ',
          'types': ['route']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political'],
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political'],
        }
      ],
      'formatted_address':
          '48/8 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'location': {'lat': 10.771438, 'lng': 106.650448},
        'location_type': 'ROOFTOP',
        'viewport': {
          'northeast': {'lat': 10.7727869802915, 'lng': 106.6517969802915},
          'southwest': {'lat': 10.7700890197085, 'lng': 106.6490990197085}
        },
      },
      'place_id': 'ChIJV0IbyL8udTERA3te0RxzEe0',
      'plus_code': {
        'compound_code': 'QMC2+H5 Tân Bình, Ho Chi Minh City, Vietnam',
        'global_code': '7P28QMC2+H5'
      },
      'types': ['street_address']
    },
    {
      'address_components': [
        {
          'long_name': '144',
          'short_name': '144',
          'types': ['street_number']
        },
        {
          'long_name': 'Âu Cơ',
          'short_name': 'Âu Cơ',
          'types': ['route']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address':
          '144 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.7714764, 'lng': 106.6504678},
          'southwest': {'lat': 10.7713674, 'lng': 106.6503297}
        },
        'location': {'lat': 10.7714524, 'lng': 106.6504417},
        'location_type': 'ROOFTOP',
        'viewport': {
          'northeast': {'lat': 10.7727708802915, 'lng': 106.6517477302915},
          'southwest': {'lat': 10.7700729197085, 'lng': 106.6490497697085}
        }
      },
      'place_id': 'ChIJpTM9yL8udTERG6VDC3OhTa0',
      'types': ['premise']
    },
    {
      'address_components': [
        {
          'long_name': '115',
          'short_name': '115',
          'types': ['street_number']
        },
        {
          'long_name': 'Âu Cơ',
          'short_name': 'Âu Cơ',
          'types': ['route']
        },
        {
          'long_name': 'Quận 11',
          'short_name': 'Quận 11',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address':
          '115 Âu Cơ, Phường 9, Quận 11, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'location': {'lat': 10.77129, 'lng': 106.6503206},
        'location_type': 'RANGE_INTERPOLATED',
        'viewport': {
          'northeast': {'lat': 10.7726389802915, 'lng': 106.6516695802915},
          'southwest': {'lat': 10.7699410197085, 'lng': 106.6489716197085}
        }
      },
      'place_id':
          'EkkxMTUgw4J1IEPGoSwgUGjGsOG7nW5nIDksIFF14bqtbiAxMSwgVGjDoG5oIHBo4buRIEjhu5MgQ2jDrSBNaW5oLCBWaWV0bmFtIhoSGAoUChIJy87kyL8udTER1L8PXvAb3c0Qcw',
      'types': ['street_address']
    },
    {
      'address_components': [
        {
          'long_name': 'Hẻm 144 Âu Cơ',
          'short_name': 'Hẻm 144 Âu Cơ',
          'types': ['route']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address':
          'Hẻm 144 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.7720672, 'lng': 106.6513267},
          'southwest': {'lat': 10.7713612, 'lng': 106.650272}
        },
        'location': {'lat': 10.7717313, 'lng': 106.6507896},
        'location_type': 'GEOMETRIC_CENTER',
        'viewport': {
          'northeast': {'lat': 10.7730631802915, 'lng': 106.6521483302915},
          'southwest': {'lat': 10.7703652197085, 'lng': 106.6494503697085}
        }
      },
      'place_id': 'ChIJLRvzl78udTERxixMgyMs2bA',
      'types': ['route']
    },
    {
      'address_components': [
        {
          'long_name': 'QMC2+H5',
          'short_name': 'QMC2+H5',
          'types': ['plus_code']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Ho Chi Minh City',
          'short_name': 'Ho Chi Minh City',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'QMC2+H5 Tân Bình, Ho Chi Minh City, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.7715, 'lng': 106.6505},
          'southwest': {'lat': 10.771375, 'lng': 106.650375}
        },
        'location': {'lat': 10.7714517, 'lng': 106.6504417},
        'location_type': 'GEOMETRIC_CENTER',
        'viewport': {
          'northeast': {'lat': 10.7727864802915, 'lng': 106.6517864802915},
          'southwest': {'lat': 10.7700885197085, 'lng': 106.6490885197085}
        }
      },
      'place_id': 'GhIJIOObt_uKJUARGV051qCpWkA',
      'plus_code': {
        'compound_code': 'QMC2+H5 Tân Bình, Ho Chi Minh City, Vietnam',
        'global_code': '7P28QMC2+H5'
      },
      'types': ['plus_code']
    },
    {
      'address_components': [
        {
          'long_name': 'Phường 9',
          'short_name': 'Phường 9',
          'types': ['administrative_area_level_3', 'political']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.780661, 'lng': 106.6558949},
          'southwest': {'lat': 10.768911, 'lng': 106.648017}
        },
        'location': {'lat': 10.7761442, 'lng': 106.651973},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 10.780661, 'lng': 106.6558949},
          'southwest': {'lat': 10.768911, 'lng': 106.648017}
        }
      },
      'place_id': 'ChIJ7Wf_T78udTERnt31SYktaQ4',
      'types': ['administrative_area_level_3', 'political']
    },
    {
      'address_components': [
        {
          'long_name': 'phường 9',
          'short_name': 'phường 9',
          'types': ['political', 'sublocality', 'sublocality_level_1']
        },
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Thành phố Hồ Chí Minh',
          'short_name': 'Thành phố Hồ Chí Minh',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.7805235, 'lng': 106.6558946},
          'southwest': {'lat': 10.7689133, 'lng': 106.6480368}
        },
        'location': {'lat': 10.7741424, 'lng': 106.6512361},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 10.7805235, 'lng': 106.6558946},
          'southwest': {'lat': 10.7689133, 'lng': 106.6480368}
        }
      },
      'place_id': 'ChIJ1S1LRb8udTERHD6S0Pn0aic',
      'types': ['political', 'sublocality', 'sublocality_level_1']
    },
    {
      'address_components': [
        {
          'long_name': 'Tân Bình',
          'short_name': 'Tân Bình',
          'types': ['administrative_area_level_2', 'political']
        },
        {
          'long_name': 'Ho Chi Minh City',
          'short_name': 'Ho Chi Minh City',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'Tân Bình, Ho Chi Minh City, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 10.838184, 'lng': 106.678676},
          'southwest': {'lat': 10.768911, 'lng': 106.62787}
        },
        'location': {'lat': 10.8014659, 'lng': 106.6525974},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 10.838184, 'lng': 106.678676},
          'southwest': {'lat': 10.768911, 'lng': 106.62787}
        }
      },
      'place_id': 'ChIJczqvGDgpdTERi8wKGNEWjc0',
      'types': ['administrative_area_level_2', 'political']
    },
    {
      'address_components': [
        {
          'long_name': 'Ho Chi Minh City',
          'short_name': 'Ho Chi Minh City',
          'types': ['administrative_area_level_1', 'political']
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'Ho Chi Minh City, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 11.160486, 'lng': 107.0115271},
          'southwest': {'lat': 10.3702489, 'lng': 106.355765}
        },
        'location': {'lat': 10.746903, 'lng': 106.676292},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 11.160486, 'lng': 107.0115271},
          'southwest': {'lat': 10.3702489, 'lng': 106.355765}
        }
      },
      'place_id': 'ChIJI9kl2-8udTERFHIryt1Uz0s',
      'types': ['administrative_area_level_1', 'political']
    },
    {
      'address_components': [
        {
          'long_name': 'Ho Chi Minh City',
          'short_name': 'Ho Chi Minh City',
          'types': ['locality', 'political'],
        },
        {
          'long_name': 'Ho Chi Minh City',
          'short_name': 'Ho Chi Minh City',
          'types': ['administrative_area_level_1', 'political'],
        },
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political'],
        }
      ],
      'formatted_address': 'Ho Chi Minh City, Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 11.1602136, 'lng': 107.0265769},
          'southwest': {'lat': 10.3493704, 'lng': 106.3638784}
        },
        'location': {'lat': 10.8230989, 'lng': 106.6296638},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 11.1602136, 'lng': 107.0265769},
          'southwest': {'lat': 10.3493704, 'lng': 106.3638784}
        }
      },
      'place_id': 'ChIJ0T2NLikpdTERKxE8d61aX_E',
      'types': ['locality', 'political']
    },
    {
      'address_components': [
        {
          'long_name': 'Vietnam',
          'short_name': 'VN',
          'types': ['country', 'political']
        }
      ],
      'formatted_address': 'Vietnam',
      'geometry': {
        'bounds': {
          'northeast': {'lat': 23.3926504, 'lng': 109.6765},
          'southwest': {'lat': 8.195200099999999, 'lng': 102.1440178}
        },
        'location': {'lat': 14.058324, 'lng': 108.277199},
        'location_type': 'APPROXIMATE',
        'viewport': {
          'northeast': {'lat': 23.3926504, 'lng': 109.6765},
          'southwest': {'lat': 8.195200099999999, 'lng': 102.1440178}
        }
      },
      'place_id': 'ChIJXx5qc016FTERvmL-4smwO7A',
      'types': ['country', 'political']
    }
  ],
  'status': 'OK',
};

var searchLocationData = {
  'predictions': [
    {
      'description':
          'Phu Tho Stadium, Lý Thường Kiệt, Phường 15, District 11, Ho Chi Minh City, Vietnam',
      'matched_substrings': [
        {'length': 15, 'offset': 0}
      ],
      'place_id': 'ChIJga4frscudTERc_-J6yvvUP8',
      'reference': 'ChIJga4frscudTERc_-J6yvvUP8',
      'structured_formatting': {
        'main_text': 'Phu Tho Stadium',
        'main_text_matched_substrings': [
          {'length': 15, 'offset': 0}
        ],
        'secondary_text':
            'Lý Thường Kiệt, Phường 15, District 11, Ho Chi Minh City, Vietnam'
      },
      'terms': [
        {'offset': 0, 'value': 'Phu Tho Stadium'},
        {'offset': 17, 'value': 'Lý Thường Kiệt'},
        {'offset': 33, 'value': 'Phường 15'},
        {'offset': 44, 'value': 'District 11'},
        {'offset': 57, 'value': 'Ho Chi Minh City'},
        {'offset': 75, 'value': 'Vietnam'}
      ],
      'types': ['stadium', 'point_of_interest', 'establishment']
    },
    {
      'description':
          'Nhà Thi Đấu Phú Thọ, Đường Lê Đại Hành, Phường 15, District 11, Ho Chi Minh City, Vietnam',
      'matched_substrings': [
        {'length': 19, 'offset': 0}
      ],
      'place_id': 'ChIJJVE5_eoudTERUQ9ZzGRnjS0',
      'reference': 'ChIJJVE5_eoudTERUQ9ZzGRnjS0',
      'structured_formatting': {
        'main_text': 'Nhà Thi Đấu Phú Thọ',
        'main_text_matched_substrings': [
          {'length': 19, 'offset': 0}
        ],
        'secondary_text':
            'Đường Lê Đại Hành, Phường 15, District 11, Ho Chi Minh City, Vietnam'
      },
      'terms': [
        {'offset': 0, 'value': 'Nhà Thi Đấu Phú Thọ'},
        {'offset': 21, 'value': 'Đường Lê Đại Hành'},
        {'offset': 40, 'value': 'Phường 15'},
        {'offset': 51, 'value': 'District 11'},
        {'offset': 64, 'value': 'Ho Chi Minh City'},
        {'offset': 82, 'value': 'Vietnam'}
      ],
      'types': ['gym', 'health', 'point_of_interest', 'establishment']
    },
    {
      'description':
          'Stadium, Phu Tho Town, Hùng Vương, Phú Thọ, Phu Tho Province, Vietnam',
      'matched_substrings': [
        {'length': 7, 'offset': 0}
      ],
      'place_id': 'ChIJa980MXiaNDERPLPa970gaeM',
      'reference': 'ChIJa980MXiaNDERPLPa970gaeM',
      'structured_formatting': {
        'main_text': 'Stadium, Phu Tho Town',
        'main_text_matched_substrings': [
          {'length': 7, 'offset': 0}
        ],
        'secondary_text': 'Hùng Vương, Phú Thọ, Phu Tho Province, Vietnam',
      },
      'terms': [
        {'offset': 0, 'value': 'Stadium, Phu Tho Town'},
        {'offset': 23, 'value': 'Hùng Vương'},
        {'offset': 35, 'value': 'Phú Thọ'},
        {'offset': 44, 'value': 'Phu Tho Province'},
        {'offset': 62, 'value': 'Vietnam'},
      ],
      'types': ['stadium', 'point_of_interest', 'establishment'],
    },
    {
      'description':
          'Go Dau Stadium, Phú Thọ, Thủ Dầu Một, Binh Duong, Vietnam',
      'matched_substrings': [
        {'length': 7, 'offset': 7},
        {'length': 7, 'offset': 16},
      ],
      'place_id': 'ChIJ6xq76l7RdDERw759fz8w_cc',
      'reference': 'ChIJ6xq76l7RdDERw759fz8w_cc',
      'structured_formatting': {
        'main_text': 'Go Dau Stadium',
        'main_text_matched_substrings': [
          {'length': 7, 'offset': 7},
        ],
        'secondary_text': 'Phú Thọ, Thủ Dầu Một, Binh Duong, Vietnam',
        'secondary_text_matched_substrings': [
          {'length': 7, 'offset': 0},
        ],
      },
      'terms': [
        {'offset': 0, 'value': 'Go Dau Stadium'},
        {'offset': 16, 'value': 'Phú Thọ'},
        {'offset': 25, 'value': 'Thủ Dầu Một'},
        {'offset': 38, 'value': 'Binh Duong'},
        {'offset': 50, 'value': 'Vietnam'},
      ],
      'types': ['point_of_interest', 'establishment'],
    },
    {
      'description':
          'Phu Tho provincial stadium, Đường Hùng Vương, Thọ Sơn, Thành phố Việt Trì, Phú Thọ, Vietnam',
      'matched_substrings': [
        {'length': 7, 'offset': 19},
        {'length': 7, 'offset': 75},
      ],
      'place_id': 'ChIJQzQ_crbyNDER3EDmXdwIPEc',
      'reference': 'ChIJQzQ_crbyNDER3EDmXdwIPEc',
      'structured_formatting': {
        'main_text': 'Phu Tho provincial stadium',
        'main_text_matched_substrings': [
          {'length': 7, 'offset': 19},
        ],
        'secondary_text':
            'Đường Hùng Vương, Thọ Sơn, Thành phố Việt Trì, Phú Thọ, Vietnam',
        'secondary_text_matched_substrings': [
          {'length': 7, 'offset': 47},
        ],
      },
      'terms': [
        {'offset': 0, 'value': 'Phu Tho provincial stadium'},
        {'offset': 28, 'value': 'Đường Hùng Vương'},
        {'offset': 46, 'value': 'Thọ Sơn'},
        {'offset': 55, 'value': 'Thành phố Việt Trì'},
        {'offset': 75, 'value': 'Phú Thọ'},
        {'offset': 84, 'value': 'Vietnam'},
      ],
      'types': ['stadium', 'point_of_interest', 'establishment'],
    }
  ],
  'status': 'OK',
};

var fetchClickedPlaceDetailsData = {
  "html_attributions": [],
  "result": {
    "address_components": [
      {
        "long_name": "221",
        "short_name": "221",
        "types": ["street_number"]
      },
      {
        "long_name": "Lý Thường Kiệt",
        "short_name": "Lý Thường Kiệt",
        "types": ["route"]
      },
      {
        "long_name": "Quận 11",
        "short_name": "Quận 11",
        "types": ["administrative_area_level_2", "political"]
      },
      {
        "long_name": "Thành phố Hồ Chí Minh",
        "short_name": "Thành phố Hồ Chí Minh",
        "types": ["administrative_area_level_1", "political"]
      },
      {
        "long_name": "Vietnam",
        "short_name": "VN",
        "types": ["country", "political"]
      }
    ],
    "adr_address":
        "\u003cspan class=\"street-address\"\u003e221 Lý Thường Kiệt\u003c/span\u003e, \u003cspan class=\"extended-address\"\u003ePhường 9\u003c/span\u003e, \u003cspan class=\"locality\"\u003eQuận 11\u003c/span\u003e, \u003cspan class=\"region\"\u003eThành phố Hồ Chí Minh\u003c/span\u003e, \u003cspan class=\"country-name\"\u003eVietnam\u003c/span\u003e",
    "business_status": "OPERATIONAL",
    "current_opening_hours": {
      "open_now": true,
      "periods": [
        {
          "close": {
            "date": "2023-11-28",
            "day": 2,
            "time": "2359",
            "truncated": true
          },
          "open": {
            "date": "2023-11-22",
            "day": 3,
            "time": "0000",
            "truncated": true
          }
        }
      ],
      "weekday_text": [
        "Monday: Open 24 hours",
        "Tuesday: Open 24 hours",
        "Wednesday: Open 24 hours",
        "Thursday: Open 24 hours",
        "Friday: Open 24 hours",
        "Saturday: Open 24 hours",
        "Sunday: Open 24 hours"
      ]
    },
    "formatted_address":
        "221 Lý Thường Kiệt, Phường 9, Quận 11, Thành phố Hồ Chí Minh, Vietnam",
    "formatted_phone_number": "028 7305 4088",
    "geometry": {
      "location": {"lat": 10.7676438, "lng": 106.6559222},
      "viewport": {
        "northeast": {"lat": 10.7692542802915, "lng": 106.6573099802915},
        "southwest": {"lat": 10.7665563197085, "lng": 106.6546120197085}
      }
    },
    "icon":
        "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/stadium-71.png",
    "icon_background_color": "#4DB546",
    "icon_mask_base_uri":
        "https://maps.gstatic.com/mapfiles/place_api/icons/v2/stadium_pinlet",
    "international_phone_number": "+84 28 7305 4088",
    "name": "Phu Tho Stadium",
    "opening_hours": {
      "open_now": true,
      "periods": [
        {
          "open": {"day": 0, "time": "0000"}
        }
      ],
      "weekday_text": [
        "Monday: Open 24 hours",
        "Tuesday: Open 24 hours",
        "Wednesday: Open 24 hours",
        "Thursday: Open 24 hours",
        "Friday: Open 24 hours",
        "Saturday: Open 24 hours",
        "Sunday: Open 24 hours"
      ]
    },
    "photos": [
      {
        "height": 3792,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/109345602557534181978\"\u003eThái Trọng Tín\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFiZKoxDkx7rOShIR80lcNdIW5SKIKDoUwxJR_Uk2-DnVUtWiF8gFPZpZZ0lVLO-8l99PpyVCA11pdYQfeEMEc-JXN6ormpUGs8Ny2BzQx1CNnPq3Z2i0JLglUnX7TfBiXFek5_qhTDOwaR4tdpCaVHDW5xYUhF1T7FZyeqqzrJhC0JR",
        "width": 5056
      },
      {
        "height": 3024,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/112857632478729452024\"\u003eTung Ngo\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFhOA4yruRLyVMipU25E_qSBzk0Lf_zu_yM8Ex4q5dm3EhLCvM8IGGV4s1qmBgFogMWR53ZjFuSkK-fOHPSrmEa7PdVJ-dTuPy1262_VqT1vooj-gh7xzUsAuH4T3oxrIp9JQTGyqP_cl0IDKve1YTMYTW7ronChC6FgwRVstIimmkYO",
        "width": 4032
      },
      {
        "height": 4032,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/109025016741608418439\"\u003eBS Cường\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFhEcR862JYS37G0WrTmU9eBBDvqu71L_QEUTaILfhUaM9Z86oOmjsJ4tG4WtwjT7jbMG-DP-W4PNa_kP_0C1xt6pDICvYHcsPi2b6A6AmALQiNYXPXO-wWkpkrD6nckszbp5Dc_Gha0l9egL-SSUz43T3RmzbdR0bxL5me2idNK7QQe",
        "width": 3024
      },
      {
        "height": 1080,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/105916476205071619776\"\u003eTiền Trần Thanh\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFgPEQO869b4m34sGIYq4UyeO5tWlKnzVTMnMPjJLTVb2o6Oqw3NzUj1DCpg2hhPzjfdOfeE8ZSD-PLArjw-mH6dtPytpu-S4uUPCTAD4JiHDOXz524mIutJbezJlGP_GHHLgFzDGgxO6QVDT0xhxHzWjkPyRqNCUmXbHr4m7jeSlU2F",
        "width": 1920
      },
      {
        "height": 3024,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/118172687913956753883\"\u003eLugon Dev\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFglgLn_QqaMf1DP_YgQlrVZObwaqEYV27wTb2T_A0xT2Gt0RQgaVbpm8zKXFSst07cWXJae5r4VUcosS2r3uyS4Lgwfnuye_iUGo7kV7hOcBBXlOEWEiL61V4hTqxwMicLNn3JQxCkdc1lRQnoJKL6drbiB8NsSibPPL7QpnolaekEL",
        "width": 4032
      },
      {
        "height": 629,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/109725974855687339274\"\u003eDeborah Hassan\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFgkERyLtAcLuDoQ3JXgPd1lSprbubKSFK1nVoBRXglMoYe9RIXn7C8tfyHg08iytLBMfhlmj7E_YK0ud9qcJi21ioJR-FN_SsyZhvHpKOLlEqSGzP9kOIU9aTtUsCP835SZuKUsEkvnjwR5WnQoRmtwmJEgRvvjMUCntR6wwiAwnYiY",
        "width": 1000
      },
      {
        "height": 3120,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/107826098187031183073\"\u003eThiên Phúc\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFhP78ZnASAYpehq-_5x41XmvaVyKMVJbLoK16Cl6f50uYXMXPDjxjsMjpdG7LzGs2Y27m0KJGRC-pNdk5kR1MaVH4doEFDiFosZ3IL0zjND0O41RTAzEmYG1EqQAqqZ5O-UUgXKTS320dtOxJL2jsWLLyoLRXJljLWErL6FCg0Pcxk4",
        "width": 4160
      },
      {
        "height": 3024,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/101612335323694538049\"\u003eBình Cao\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFiPTeCTLzOmG3o0VutDvuirv5y8-EcX68dVRc1BB0NNn5JjPKQeOPHkOqsf70H1Xn1qGOTrvspJqCgMo9jWGLI-8mP6983t623p4aD6B0SMJNDw1BygTj07J7kfcqt0mOXPCYKmVRQ8uBmmGr-BCi4RqdrlwppMvq7sNaqh0sSNMu1U",
        "width": 4032
      },
      {
        "height": 2322,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/106204909209495734670\"\u003eFORD BÌNH TRIỆU (City Ford Bình Triệu)\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFjPclzo726K-0yPZRVTaXwCId7RnSTUowSPLFXo1AodD54xb7KbPYA97SMAPBRzR3mlttyQbDsAF0AjUMUAH1vOKeisqfacUIbJrrIxmeXgI7bn4u-ChVHuQG3KacNl_PpJ9bSzVtXndbveLbEzbF4nE-H4-HIhhfpx-LG16Pcgtxar",
        "width": 4128
      },
      {
        "height": 3024,
        "html_attributions": [
          "\u003ca href=\"https://maps.google.com/maps/contrib/116145203936948297860\"\u003eMinhQuân\u003c/a\u003e"
        ],
        "photo_reference":
            "AWU5eFj2v2gtYBtx88XS51CfsWz2SXu4j9Q3QIPfQJ5uZUjb6Aw78ICjLDvLntP-naoDG1KaT4Ip_NFGqDvCnkLS7dO6mQEtrKZ9lWVYQYVHvVqVGsIqRH9EvH8RJiuZzZg0L8RA5IomVeP6S988DBPo6fSk04HkJ9pfsUo7WdeKyN1FvfT9",
        "width": 4032
      }
    ],
    "place_id": "ChIJga4frscudTERc_-J6yvvUP8",
    "plus_code": {
      "compound_code": "QM94+39 District 11, Ho Chi Minh City, Vietnam",
      "global_code": "7P28QM94+39"
    },
    "rating": 4.3,
    "reference": "ChIJga4frscudTERc_-J6yvvUP8",
    "reviews": [
      {
        "author_name": "Quân Minh",
        "author_url":
            "https://www.google.com/maps/contrib/100496959549449267790/reviews",
        "language": "en",
        "original_language": "en",
        "profile_photo_url":
            "https://lh3.googleusercontent.com/a-/ALV-UjUaEZbecXBwBscQscZ5sXLHShD0eKNI_DIQJbrLuasn4w=s128-c0x00000000-cc-rp-mo",
        "rating": 5,
        "relative_time_description": "2 months ago",
        "text":
            "Phu Tho Stadium is an exceptional sporting arena that exceeds all expectations, earning a remarkable five-star rating. With its state-of-the-art facilities, impeccable maintenance, world-class amenities, passionate crowd, and outstanding organization, it sets the benchmark for excellence in sports stadiums. From the moment you step inside, you are greeted with a sense of grandeur and sophistication. The stadium's modern design ensures optimum comfort for spectators, while the pitch provides a perfect playing surface for athletes. The meticulous attention to detail, top-notch security measures, and exceptional customer service make Phu Tho Stadium a truly unforgettable sporting experience.",
        "time": 1694686229,
        "translated": false
      },
      {
        "author_name": "Viet Quoc Nguyen",
        "author_url":
            "https://www.google.com/maps/contrib/101164175820434279790/reviews",
        "language": "en",
        "original_language": "en",
        "profile_photo_url":
            "https://lh3.googleusercontent.com/a/ACg8ocIu4TxpBCyA_3gFQpVMUSkqVK35JV5Y7zZRwIJkzLBV=s128-c0x00000000-cc-rp-mo-ba4",
        "rating": 4,
        "relative_time_description": "a month ago",
        "text":
            "The stadium is quite old. Some organizations built it but not got it maintained well. You can play so many kinds of sports here. But be careful the security guards are gods here, their behaviors are beyond your imagination you can compare to gangsters. I have been shocked.",
        "time": 1696220529,
        "translated": false
      },
      {
        "author_name": "Thai Truong",
        "author_url":
            "https://www.google.com/maps/contrib/110910628392264514988/reviews",
        "language": "en",
        "original_language": "en",
        "profile_photo_url":
            "https://lh3.googleusercontent.com/a-/ALV-UjV-dT0oFYPZ0G24v1bfKWXJo7GpPkwPqDZZwkHUDm8WdovX=s128-c0x00000000-cc-rp-mo-ba6",
        "rating": 5,
        "relative_time_description": "5 years ago",
        "text":
            "The race track for horse racing is open to public when there's no event happening which is pretty much all the time now. The loop around the outside is 1600 meters (oval circle) dirt track. This place is commonly used by locals for exercising (walk, run, tai chi, stretching). Best times to come is before sunrise and after sunset as it's much cooler. There's also the 400 meter oval gravel track which hasn't been maintained at all, so the ground is uneven and not ideal for running. There dirt track is pretty good for running.\n\nIt's decent for star gazing in the middle of the night in the middle of the grass field.",
        "time": 1526182160,
        "translated": false
      },
      {
        "author_name": "Quang bao Truong",
        "author_url":
            "https://www.google.com/maps/contrib/107457954531045370001/reviews",
        "language": "en",
        "original_language": "en",
        "profile_photo_url":
            "https://lh3.googleusercontent.com/a/ACg8ocIpXlKV_gUjIf9leRleuz-wuNBydxsbkB7ook3DbxPQ=s128-c0x00000000-cc-rp-mo",
        "rating": 4,
        "relative_time_description": "2 weeks ago",
        "text": "Ok",
        "time": 1698927886,
        "translated": false
      },
      {
        "author_name": "Trieu Nguyen",
        "author_url":
            "https://www.google.com/maps/contrib/103464715625001813816/reviews",
        "language": "en",
        "original_language": "en",
        "profile_photo_url":
            "https://lh3.googleusercontent.com/a-/ALV-UjVQLo1Zu0saolR7wN_WTVtkxGurnIHTfxfKcBXK5pxzhnAR=s128-c0x00000000-cc-rp-mo-ba5",
        "rating": 5,
        "relative_time_description": "6 months ago",
        "text": "Coi the masked singer",
        "time": 1684805887,
        "translated": false
      }
    ],
    "types": ["stadium", "point_of_interest", "establishment"],
    "url": "https://maps.google.com/?cid=18397467449722797939",
    "user_ratings_total": 1516,
    "utc_offset": 420,
    "vicinity": "221 Lý Thường Kiệt, Phường 9"
  },
  "status": "OK"
};

var getDirectionDetailsFromAPIDataFromUserToDes = {
  "geocoded_waypoints": [
    {
      "geocoder_status": "OK",
      "place_id": "ChIJFZr0L_MvdTERpete8YoRKFI",
      "types": ["establishment", "food", "point_of_interest"]
    },
    {
      "geocoder_status": "OK",
      "place_id": "ChIJM3smUuoudTERsV5DEqWSAJM",
      "types": ["establishment", "point_of_interest"]
    }
  ],
  "routes": [
    {
      "bounds": {
        "northeast": {"lat": 10.7714696, "lng": 106.6592721},
        "southwest": {"lat": 10.7661156, "lng": 106.650272}
      },
      "copyrights": "Map data ©2023",
      "legs": [
        {
          "distance": {"text": "2.4 km", "value": 2376},
          "duration": {"text": "8 mins", "value": 493},
          "end_address":
              "2-4 Đ. Lê Đại Hành, Phường 15, Quận 11, Thành phố Hồ Chí Minh, Vietnam",
          "end_location": {"lat": 10.7681661, "lng": 106.6559466},
          "start_address":
              "144 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam",
          "start_location": {"lat": 10.7714696, "lng": 106.6504289},
          "steps": [
            {
              "distance": {"text": "21 m", "value": 21},
              "duration": {"text": "1 min", "value": 8},
              "end_location": {"lat": 10.7713612, "lng": 106.650272},
              "html_instructions":
                  "Head \u003cb\u003esouthwest\u003c/b\u003e on \u003cb\u003eHẻm 144 Âu Cơ\u003c/b\u003e toward \u003cb\u003eÂu Cơ\u003c/b\u003e",
              "polyline": {"points": "uxv`Aed}iST^"},
              "start_location": {"lat": 10.7714696, "lng": 106.6504289},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.3 km", "value": 311},
              "duration": {"text": "1 min", "value": 64},
              "end_location": {"lat": 10.7690366, "lng": 106.6518372},
              "html_instructions":
                  "Turn \u003cb\u003eleft\u003c/b\u003e onto \u003cb\u003eÂu Cơ\u003c/b\u003e",
              "maneuver": "turn-left",
              "polyline": {
                "points": "_xv`Aec}iSh@]TM\\SXOnAy@PMdAu@b@YJGZSREPKRKh@W"
              },
              "start_location": {"lat": 10.7713612, "lng": 106.650272},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.3 km", "value": 328},
              "duration": {"text": "1 min", "value": 59},
              "end_location": {"lat": 10.7709062, "lng": 106.6526785},
              "html_instructions":
                  "At the roundabout, take the \u003cb\u003e5th\u003c/b\u003e exit onto \u003cb\u003eNguyễn Thị Nhỏ\u003c/b\u003e",
              "maneuver": "roundabout-right",
              "polyline": {
                "points":
                    "oiv`A_m}iSB@D@B?DADEBEBG@A@C?EBMBIDI@EBEBM@M?A?CACGGGEGCMAG@A@kAE]@OAc@CYEy@EiBKg@C"
              },
              "start_location": {"lat": 10.7690366, "lng": 106.6518372},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.6 km", "value": 582},
              "duration": {"text": "2 mins", "value": 98},
              "end_location": {"lat": 10.7703983, "lng": 106.6578432},
              "html_instructions":
                  "Turn \u003cb\u003eright\u003c/b\u003e onto \u003cb\u003eĐ. Lữ Gia\u003c/b\u003e",
              "maneuver": "turn-right",
              "polyline": {
                "points":
                    "euv`Agr}iSOKWWIQDe@Hs@HgABMDo@Hs@@WJmA@OFq@F_AH}@HcAFq@B[JkAJmAFq@Hy@"
              },
              "start_location": {"lat": 10.7709062, "lng": 106.6526785},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.5 km", "value": 486},
              "duration": {"text": "1 min", "value": 68},
              "end_location": {"lat": 10.7663475, "lng": 106.6592721},
              "html_instructions":
                  "Turn \u003cb\u003eright\u003c/b\u003e onto \u003cb\u003eLý Thường Kiệt\u003c/b\u003e\u003cdiv style=\"font-size:0.9em\"\u003ePass by Công ty IMEX (on the left)\u003c/div\u003e",
              "maneuver": "turn-right",
              "polyline": {
                "points":
                    "_rv`Aor~iSDIFMHQLMJM`@InAUVExAYLCtBa@TEJC^Gb@KVE|@SlDo@d@I"
              },
              "start_location": {"lat": 10.7703983, "lng": 106.6578432},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "78 m", "value": 78},
              "duration": {"text": "1 min", "value": 32},
              "end_location": {"lat": 10.7661395, "lng": 106.6585982},
              "html_instructions":
                  "Turn \u003cb\u003eright\u003c/b\u003e onto \u003cb\u003eHẻm 219E\u003c/b\u003e",
              "maneuver": "turn-right",
              "polyline": {"points": "uxu`Am{~iSRfAH`@@FDL@B?@@?"},
              "start_location": {"lat": 10.7663475, "lng": 106.6592721},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "19 m", "value": 19},
              "duration": {"text": "1 min", "value": 7},
              "end_location": {"lat": 10.7661416, "lng": 106.6584395},
              "html_instructions": "Keep \u003cb\u003eright\u003c/b\u003e",
              "maneuver": "keep-right",
              "polyline": {"points": "kwu`Agw~iSBH?F?D?@CB?@"},
              "start_location": {"lat": 10.7661395, "lng": 106.6585982},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.4 km", "value": 413},
              "duration": {"text": "2 mins", "value": 124},
              "end_location": {"lat": 10.7692306, "lng": 106.6563608},
              "html_instructions": "Turn \u003cb\u003eright\u003c/b\u003e",
              "maneuver": "turn-right",
              "polyline": {
                "points":
                    "kwu`Agv~iSA@MFOHaAf@yAz@gDnBKFUNa@TqAv@mAt@OFGFEBCB?@?@"
              },
              "start_location": {"lat": 10.7661416, "lng": 106.6584395},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.1 km", "value": 138},
              "duration": {"text": "1 min", "value": 33},
              "end_location": {"lat": 10.7681661, "lng": 106.6559466},
              "html_instructions": "Turn \u003cb\u003eleft\u003c/b\u003e",
              "maneuver": "turn-left",
              "polyline": {
                "points":
                    "ujv`Agi~iS?@@@B@D?F?P?F?H@H?N@LAPEF?JDJHFJFJHJJHHFJDDB"
              },
              "start_location": {"lat": 10.7692306, "lng": 106.6563608},
              "travel_mode": "DRIVING"
            }
          ],
          "traffic_speed_entry": [],
          "via_waypoint": []
        }
      ],
      "overview_polyline": {
        "points":
            "uxv`Aed}iST^h@]r@a@hBiAvAcAn@a@ZSREd@Wh@WB@H@JGJSBSHSDKD[?EIKOIMAG@mACm@?aF[g@COKa@i@\\oDx@iK`@}ER_CNcAP_@X[bF_A~H}ArEy@\\hBHZDPCLaBz@cHbEqEjCQP?BRBl@@\\?XEVNNVTTTLDB"
      },
      "summary": "Đ. Lữ Gia",
      "warnings": [],
      "waypoint_order": []
    }
  ],
  "status": "OK"
};

var getDirectionDetailsFromAPIDataFromDriverToUser = {
  "geocoded_waypoints": [
    {
      "geocoder_status": "OK",
      "place_id": "ChIJ-6NhwcMudTERHmnMoUfNd-8",
      "types": ["establishment", "point_of_interest", "university"]
    },
    {
      "geocoder_status": "OK",
      "place_id": "ChIJFZr0L_MvdTERpete8YoRKFI",
      "types": ["establishment", "food", "point_of_interest"]
    }
  ],
  "routes": [
    {
      "bounds": {
        "northeast": {"lat": 10.7721059, "lng": 106.6580453},
        "southwest": {"lat": 10.769074, "lng": 106.650272}
      },
      "copyrights": "Map data ©2023 Google",
      "legs": [
        {
          "distance": {"text": "1.4 km", "value": 1405},
          "duration": {"text": "5 mins", "value": 277},
          "end_address":
              "144 Âu Cơ, Phường 9, Tân Bình, Thành phố Hồ Chí Minh, Vietnam",
          "end_location": {"lat": 10.7714696, "lng": 106.6504289},
          "start_address":
              "268 Lý Thường Kiệt, Phường 14, Quận 10, Thành phố Hồ Chí Minh, Vietnam",
          "start_location": {"lat": 10.7721059, "lng": 106.657881},
          "steps": [
            {
              "distance": {"text": "18 m", "value": 18},
              "duration": {"text": "1 min", "value": 6},
              "end_location": {"lat": 10.7720617, "lng": 106.6577234},
              "html_instructions":
                  "Head \u003cb\u003ewest\u003c/b\u003e toward \u003cb\u003eLý Thường Kiệt\u003c/b\u003e",
              "polyline": {"points": "u|v`Awr~iSH^"},
              "start_location": {"lat": 10.7721059, "lng": 106.657881},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.2 km", "value": 173},
              "duration": {"text": "1 min", "value": 40},
              "end_location": {"lat": 10.7706778, "lng": 106.6580453},
              "html_instructions":
                  "Turn \u003cb\u003eleft\u003c/b\u003e at the 1st cross street onto \u003cb\u003eLý Thường Kiệt\u003c/b\u003e",
              "maneuver": "turn-left",
              "polyline": {"points": "k|v`Awq~iSCPv@Q\\IHAvDu@"},
              "start_location": {"lat": 10.7720617, "lng": 106.6577234},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "40 m", "value": 40},
              "duration": {"text": "1 min", "value": 12},
              "end_location": {"lat": 10.7703983, "lng": 106.6578432},
              "html_instructions":
                  "Slight \u003cb\u003eright\u003c/b\u003e toward \u003cb\u003eĐ. Lữ Gia\u003c/b\u003e",
              "maneuver": "turn-slight-right",
              "polyline": {"points": "wsv`Ays~iSLBF@D@DBDDDFHN"},
              "start_location": {"lat": 10.7706778, "lng": 106.6580453},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.6 km", "value": 566},
              "duration": {"text": "2 mins", "value": 100},
              "end_location": {"lat": 10.7711723, "lng": 106.652724},
              "html_instructions":
                  "Turn \u003cb\u003eright\u003c/b\u003e onto \u003cb\u003eĐ. Lữ Gia\u003c/b\u003e\u003cdiv style=\"font-size:0.9em\"\u003ePass by Công Ty TNHH Thương Mại và Dịch Vụ Phát Tiến (on the right)\u003c/div\u003e",
              "maneuver": "turn-right",
              "polyline": {
                "points":
                    "_rv`Aor~iSIx@Gp@KlAKjACZGp@IbAI|@G~@Gp@ANKlAAVIr@En@CLIfAIr@Ed@Ad@?F"
              },
              "start_location": {"lat": 10.7703983, "lng": 106.6578432},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.2 km", "value": 244},
              "duration": {"text": "1 min", "value": 45},
              "end_location": {"lat": 10.7690711, "lng": 106.6522692},
              "html_instructions":
                  "Turn \u003cb\u003eleft\u003c/b\u003e onto \u003cb\u003eNguyễn Thị Nhỏ\u003c/b\u003e",
              "maneuver": "turn-left",
              "polyline": {
                "points": "yvv`Aor}iSr@Ff@BhBJx@DXDb@BN@PFRDNDNFHHDH"
              },
              "start_location": {"lat": 10.7711723, "lng": 106.652724},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "0.3 km", "value": 343},
              "duration": {"text": "1 min", "value": 60},
              "end_location": {"lat": 10.7713612, "lng": 106.650272},
              "html_instructions":
                  "At the roundabout, take the \u003cb\u003e1st\u003c/b\u003e exit onto \u003cb\u003eÂu Cơ\u003c/b\u003e\u003cdiv style=\"font-size:0.9em\"\u003ePass by Nhà thuốc Pharmacity (on the left)\u003c/div\u003e",
              "maneuver": "roundabout-right",
              "polyline": {
                "points":
                    "uiv`Auo}iS?@?D?B?FABGFCDADAB?B?B[^OPSNKP[RKFc@XeAt@QLoAx@YN]RULi@\\"
              },
              "start_location": {"lat": 10.7690711, "lng": 106.6522692},
              "travel_mode": "DRIVING"
            },
            {
              "distance": {"text": "21 m", "value": 21},
              "duration": {"text": "1 min", "value": 14},
              "end_location": {"lat": 10.7714696, "lng": 106.6504289},
              "html_instructions":
                  "Turn \u003cb\u003eright\u003c/b\u003e onto \u003cb\u003eHẻm 144 Âu Cơ\u003c/b\u003e\u003cdiv style=\"font-size:0.9em\"\u003eDestination will be on the right\u003c/div\u003e",
              "maneuver": "turn-right",
              "polyline": {"points": "_xv`Aec}iSU_@"},
              "start_location": {"lat": 10.7713612, "lng": 106.650272},
              "travel_mode": "DRIVING"
            }
          ],
          "traffic_speed_entry": [],
          "via_waypoint": []
        }
      ],
      "overview_polyline": {
        "points":
            "u|v`Awr~iSH^CPtA[`Ew@TDJDJLHNIx@S~Ba@|E[~D{@xJAl@zAJ`FZdATXPDJATOV?Fk@p@SNKPg@ZkEvCwBnAU_@"
      },
      "summary": "Đ. Lữ Gia",
      "warnings": [],
      "waypoint_order": []
    }
  ],
  "status": "OK"
};
