import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/constants/app_config.dart';
import 'package:futter_user/src/presentation/controllers/app_info.dart';
import 'package:http/http.dart' as http;

class PushNotificationService {
  PushNotificationService(this.ref);

  final Ref ref;

  sendNotificationToSelectedDriver(String deviceToken, String tripID) async {
    String dropOffDestinationAddress = ref
        .read(appInfoControllerProvider)
        .dropOffLocation!
        .placeName
        .toString();
    String pickUpAddress = ref
        .read(appInfoControllerProvider)
        .pickUpLocation!
        .placeName
        .toString();

    Map<String, String> headerNotificationMap = {
      'Content-Type': 'application/json',
      'Authorization': serverKeyFCM,
    };

    Map titleBodyNotificationMap = {
      'title': 'NEW TRIP REQUEST from $userName',
      'body':
          'PickUp Location: $pickUpAddress \nDropOff Location: $dropOffDestinationAddress',
    };

    Map dataMapNotification = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'tripID': tripID,
    };

    Map bodyNotificationMap = {
      'notification': titleBodyNotificationMap,
      'data': dataMapNotification,
      'priority': 'high',
      'to': deviceToken,
    };

    await http.post(
      Uri.parse('https://fcm.googleapis.com/fcm/send'),
      headers: headerNotificationMap,
      body: jsonEncode(bodyNotificationMap),
    );
  }
}

final pushNotificationServiceProvider =
    Provider<PushNotificationService>((ref) {
  return PushNotificationService(ref);
});
