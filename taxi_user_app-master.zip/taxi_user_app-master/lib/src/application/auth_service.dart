import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/types/request_params/auth.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:futter_user/src/data/auth/auth_repo.dart';
import 'package:futter_user/src/domain/user_token.dart';

class AuthService {
  AuthService(this.ref);

  final Ref ref;
  Future<UserToken> login(ILoginParams params) async {
    try {
      final userToken = await ref.read(authRepositoryProvider).login(params);
      localStorage.storeUserToken(userToken);
      return userToken;
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<UserToken> refreshToken() async {
    try {
      final userToken = await ref.read(authRepositoryProvider).refreshToken();
      localStorage.storeUserToken(userToken);
      return userToken;
    } catch (error) {
      return Future.error(error);
    }
  }
}

final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(ref);
});
