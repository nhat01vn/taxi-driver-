import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:easy_localization_loader/easy_localization_loader.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/routes.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_config_localization.dart';
import 'package:futter_user/src/core/utilities/app_config.dart';
import 'package:futter_user/src/core/utilities/local_storage.dart';
import 'package:futter_user/src/data/auth/auth_api_repo.dart';
import 'package:futter_user/src/data/auth/auth_repo.dart';
import 'package:futter_user/src/data/user/user_api_repo.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await EasyLocalization.ensureInitialized();
  EasyLocalization.logger.enableBuildModes = []; // Disable logging
  await Hive.initFlutter();
  await Permission.locationWhenInUse.isDenied.then((valueOfPermission) {
    if (valueOfPermission) {
      Permission.locationWhenInUse.request();
    }
  });
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  final container = ProviderContainer(
    overrides: [
      authRepositoryProvider.overrideWithValue(AuthApiRepository()),
      userRepositoryProvider.overrideWithValue(UserApiRepository()),
    ],
  );

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: EasyLocalization(
        supportedLocales: AppConfigLocalization.supportedLocales,
        path: 'assets/l10n',
        fallbackLocale: AppConfigLocalization.supportedLocales.first,
        assetLoader: YamlAssetLoader(),
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    _fetchDefaultConfig();
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    AppConfig.hideStatusBar();

    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.robotoTextTheme(
          Theme.of(context).textTheme,
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primary),
        useMaterial3: false,
        appBarTheme: Theme.of(context)
            .appBarTheme
            .copyWith(systemOverlayStyle: SystemUiOverlayStyle.light),
      ),
      routerConfig: Routes.router,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
          child: child!,
        );
      },
    );
  }

  void _fetchDefaultConfig() {
    localStorage
        .loadSettings('localeLanguage', defaultValue: Platform.localeName)
        .then((locale) async {
      locale = locale.split('_')[0];
      Locale selectedLocale = const Locale('en');
      if (AppConfigLocalization.supportedLocales.contains(Locale(locale))) {
        await context.setLocale(Locale(locale));
        selectedLocale = Locale(locale);
      }

      localStorage.storeSettings('localeLanguage', selectedLocale.toString());
    });
  }
}
