yarn db:drop
yarn db:create
yarn db:migrate
yarn db:seed:all
