# taxi_dispatcher_backend

## Project setup

### Setup ENV Variables

```bash
cp .env.template .env
```

### Install the project dependencies

```bash
yarn install
```

### Run project

```
yarn install
./resetdb.sh
yarn serve
```
