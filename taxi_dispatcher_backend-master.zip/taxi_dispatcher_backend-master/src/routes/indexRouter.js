'use strict';
const express = require('express');
const router = express.Router();

const auth = require('../controllers/auth');
router.use('/auth', auth);

const user = require('../controllers/user');
router.use('/user', user);

const driver = require('./driver');
router.use('/driver', driver);

const client = require('./client');
router.use('/client', client);

const typecar = require('./typecar');
router.use('/typecar', typecar);

const trip = require('./trip');
router.use('/trip', trip);

const cachedgps = require('./cachedgps');
router.use('/cachedgps', cachedgps);

module.exports = router;
