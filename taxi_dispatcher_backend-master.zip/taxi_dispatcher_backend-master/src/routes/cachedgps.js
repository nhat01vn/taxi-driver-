'use strict';
const express = require('express');
const router = express.Router();
const gpsController = require('../controllers/gpsController');
const exceptionHandler = require('../helpers/exception_handler');

/* Update cachedgps: '/cachedgps/update' */
router.patch('/update', async (req, res) => {
  try {
    let result = await gpsController.update(req.body);
    if (result[0]) {
      res.json({ message: 'Cached GPS information updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, `CachedGps Id=${req.body.id}`);
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Delete cachedgps by Id: '/cachedgps/delete/:id' */
router.delete('/delete/:id', async (req, res) => {
  try {
    let result = await gpsController.delete(req.params.id);
    if (result) {
      res.json({ message: 'Cached GPS deleted successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, `CachedGps Id=${req.params.id}`);
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Add new cachedgps: '/cachedgps/add' */
router.put('/add', async (req, res) => {
  try {
    let result = await gpsController.add(req.body);
    if (result) {
      res.json({ message: 'Cached GPS added successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'CachedGps');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

module.exports = router;
