'use strict';
const express = require('express');
const router = express.Router();
const exceptionHandler = require('../helpers/exception_handler');
const finders = require('../finders');

/* Get All Type of Car : '/typecar' */
router.get('/', async (req, res) => {
  try {
    let result = await finders.car.TypeCar.find(scope(req, 'TypeCar'), req.query);
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'TypeCar');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = router;
