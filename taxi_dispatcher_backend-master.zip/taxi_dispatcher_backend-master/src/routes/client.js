'use strict';
const express = require('express');
const router = express.Router();
const exceptionHandler = require('../helpers/exception_handler');
const finders = require('../finders');
const clientController = require('../controllers/clientController');

/* Get All clients info  :  '/client'
   Get client by phone   :  '/client?phone=...'
   Get client by name    :  '/client?name=...'
*/
router.get('/', async (req, res) => {
  try {
    let result = await finders.client.ClientInfo.find(scope(req, 'client'), req.query);
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Client');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Get info client by Id: '/client/:id' */
router.get('/:id', async (req, res) => {
  try {
    let result = await finders.client.ClientInfo.find(scope(req, 'client'), req.params);
    let client;
    if (result) {
      client = {
        id: result.id,
        uid: result.uid,
        name: result.name,
        phone: result.phone,
        email: result.email,
        blockStatus: result.blockStatus,
        createdAt: result.createdAt,
      };

      let clienttrips = await finders.client.ClientTrips.find(scope(req, 'trip'), client);
      if (clienttrips) {
        client.HistoryTrips = clienttrips;
      }
      res.status(201).json(client);
    } else {
      exceptionHandler.resourceNotFound(client, 'Client');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Update info: '/client/update' */
router.patch('/update', async (req, res) => {
  try {
    let result = await clientController.update(req.body);
    if (result[0]) {
      res.json({ message: 'Client information updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Client');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Delete client by Id: '/client/delete/:id' */
router.delete('/delete/:id', async (req, res) => {
  try {
    let result = await clientController.delete(req.params.id);
    if (result) {
      res.json({ message: 'Client deleted successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Client');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Add new client: '/client/add' */
router.put('/add', async (req, res) => {
  try {
    let result = await clientController.add(req.body);
    if (result) {
      res.json({ message: 'Client added successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Client');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = router;
