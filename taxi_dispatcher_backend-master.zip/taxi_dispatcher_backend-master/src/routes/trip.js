'use strict';
const express = require('express');
const router = express.Router();
const exceptionHandler = require('../helpers/exception_handler');
const finders = require('../finders');
const tripController = require('../controllers/tripController');

/* Get All trips       :  '/trip'
   Get trips by status :  '/trip?status=...' 
*/
router.get('/', async (req, res) => {
  try {
    let result = await finders.trip.TripInfo.find(scope(req, 'trip'), req.query);
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Trip');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Get info trip by Id: '/trip/:id' */
router.get('/:id', async (req, res) => {
  try {
    let result = await finders.trip.TripInfo.find(scope(req, 'trip'), req.params);
    let trip;
    if (result) {
      trip = {
        id: result.id,
        lat: result.lat,
        long: result.long,
        rate: result.rate,
        status: result.status,
        client: result.Client,
        driver: result.Driver,
      };
      res.status(201).json(trip);
    } else {
      exceptionHandler.resourceNotFound(trip, 'Trip');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Update info: '/trip/update' */
router.patch('/update', async (req, res) => {
  try {
    let result = await tripController.update(req.body);
    if (result[0]) {
      res.json({ message: 'Trip information updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Trip');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Delete trip by Id: '/trip/delete/:id' */
router.delete('/delete/:id', async (req, res) => {
  try {
    let result = await tripController.delete(req.params.id);
    if (result) {
      res.json({ message: 'Trip deleted successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Trip');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Add new trip: '/trip/add' */
router.put('/add', async (req, res) => {
  try {
    let result = await tripController.add(req.body);
    if (result) {
      res.json({ message: 'Trip added successfully' });
    } else {
      exceptionHandler.resourceNotFound(result, 'Trip');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = router;
