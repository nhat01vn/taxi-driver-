'use strict';
const express = require('express');
const router = express.Router();
const exceptionHandler = require('../helpers/exception_handler');
const finders = require('../finders');
const driverController = require('../controllers/driverController');
const services = require('../services');

/* Get All drivers       :  '/driver'
   Get driver by phone   :  '/driver?phone=...'
*/
router.get('/', async (req, res) => {
  try {
    let result = await finders.driver.DriverInfo.find(scope(req, 'driver'), req.query);
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Get ONLINE drivers :  '/driver/onlineDrivers'   */
router.get('/onlineDrivers', async (req, res) => {
  try {
    req.query['status'] = true;
    let result = await finders.driver.DriverInfo.find(scope(req, 'driver'), req.query);
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Online Drivers');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Get Nearby ONLINE drivers :  '/driver/nearbyOnlineDrivers'   */
router.post('/nearbyOnlineDrivers', async (req, res) => {
  try {
    let result = await services.driver.ManageDrivers.getNearbyOnlineDrivers(req.body, 2);
    if (result[0]) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Nearby Online Drivers');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Update Gps location : '/driver/setLocation' */
router.patch('/setLocation', async (req, res) => {
  try {
    let result = await driverController.updateGps(req.body);
    if (result[0]) {
      res.json({ message: 'Location updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Update status: true=online; false=offline --> '/driver/update-status' */
router.patch('/update-status', async (req, res) => {
  try {
    let result = await driverController.updateStatus(req.body.id, req.body.status);
    if (result[0]) {
      res.json({ message: 'Status updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Set new trip status: '/driver/setNewTripStatus' */
router.patch('/setNewTripStatus', async (req, res) => {
  try {
    let result = await driverController.setNewTripStatus(req.body.id, req.body.newTripStatus);
    if (result[0]) {
      res.json({ message: 'New Trip Status set successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Get info driver by Uid: '/driver/:uid' */
router.get('/:uid', async (req, res) => {
  try {
    let driver;
    let result = await finders.driver.DriverInfo.find(scope(req, 'driver'), req.params);
    if (result) {
      driver = {
        id: result.id,
        uid: result.uid,
        name: result.name,
        phone: result.phone,
        email: result.email,
        status: result.status,
        blockStatus: result.blockStatus,
        earnings: result.earnings,
        lat: result.lat,
        long: result.long,
        carModel: result.carModel,
        carNumber: result.carNumber,
        photo: result.photo,
        newTripStatus: result.newTripStatus,
        deviceToken: result.deviceToken,
        typeCar: result.TypeCar?.name,
      };

      let drivertrips = await finders.driver.DriverTrips.find(scope(req, 'trip'), driver);
      if (drivertrips) {
        driver.HistoryTrips = drivertrips;
      }
      res.status(201).json(driver);
    } else {
      exceptionHandler.resourceNotFound(driver, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Update info: '/driver/update' */
router.patch('/update', async (req, res) => {
  try {
    let result = await driverController.update(req.body);
    if (result[0]) {
      res.json({ message: 'Driver information updated successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Delete driver by Id: '/driver/delete/:id' */
router.delete('/delete/:id', async (req, res) => {
  try {
    let result = await driverController.delete(req.params.id);
    if (result) {
      res.json({ message: 'Driver deleted successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

/* Add new driver: '/driver/add' */
router.put('/add', async (req, res) => {
  try {
    let result = await driverController.add(req.body);
    if (result) {
      res.json({ message: 'Driver added successfully' });
    } else {
      exceptionHandler.resourceNotFound(null, 'Driver');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = router;
