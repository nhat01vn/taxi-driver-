'use strict';
const models = require('../../models');
const { BaseFinder } = require('../base');

module.exports = () => {
  class DriverNewTripStatus extends BaseFinder {
    model() {
      return models.Driver;
    }

    isFetchAll() {
      return false;
    }

    conditionBuilder() {
      let options = {
        attributes: ['newTripStatus'],
        where: { id: this.params.id },
      };

      return options;
    }
  }

  return DriverNewTripStatus;
};
