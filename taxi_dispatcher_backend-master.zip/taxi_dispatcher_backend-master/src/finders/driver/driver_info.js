'use strict';
const { Op } = require('sequelize');
const models = require('../../models');
const { BaseFinder } = require('../base');

module.exports = () => {
  class DriverInfo extends BaseFinder {
    model() {
      return models.Driver;
    }

    isFetchAll() {
      if (this.params.uid == null) {
        return true;
      }
      return false;
    }

    conditionBuilder() {
      let options = {
        include: {
          model: models.TypeCar,
        },
        attributes: { exclude: ['password', 'resetToken', 'typecarId'] },
        where: {},
        order: [['uid', 'ASC']],
      };
      if (this.params.uid != null) {
        options.where.uid = this.params.uid;
      }
      if (this.params.status != null) {
        options.where.status = this.params.status;
      }
      if (this.params.newTripStatus != null) {
        options.where.newTripStatus = this.params.newTripStatus;
      }
      if (this.params.phone != null && this.params.phone != '') {
        options.where.phone = {
          [Op.iLike]: `%${this.params.phone}%`,
        };
      }

      return options;
    }
  }

  return DriverInfo;
};
