'use strict';
const models = require('../../models');
const { isBlank } = require('../../utils/lang');
const { BaseFinder } = require('../base');

module.exports = () => {
  class DriverTrips extends BaseFinder {
    model() {
      return models.Trip;
    }

    validate() {
      if (isBlank(this.params.id)) {
        this.addErrors('Driver ID invalid');
      }
    }

    isFetchAll() {
      return true;
    }

    conditionBuilder() {
      return {
        where: { driverId: this.params.id },
        attributes: [
          'id',
          'uid',
          'pickUpLat',
          'pickUpAddress',
          'dropOffLat',
          'dropOffLong',
          'dropOffAddress',
          'status',
          'fareAmount',
          'createdAt',
        ],
        include: {
          model: models.Client,
          attributes: ['id', 'uid', 'name', 'phone'],
        },
        order: [['id', 'DESC']],
      };
    }
  }

  return DriverTrips;
};
