'use strict';
const { isNil } = require('lodash');
const models = require('../../models');
const { BaseFinder } = require('../base');

module.exports = () => {
  class TripInfo extends BaseFinder {
    model() {
      return models.Trip;
    }

    isFetchAll() {
      if (this.params.id == null) {
        return true;
      }
      return false;
    }

    conditionBuilder() {
      let options = {
        include: [
          {
            model: models.Client,
            attributes: ['id', 'uid', 'name', 'phone'],
          },
          {
            model: models.Driver,
            attributes: ['id', 'name', 'phone', 'lat', 'long', 'carModel', 'carNumber', 'photo', 'typecarId'],
          },
        ],
        where: {},
        order: [['id', 'ASC']],
      };
      if (!isNil(this.params.id)) {
        options.where.id = this.params.id;
      }
      if (!isNil(this.params.status)) {
        options.where.status = this.params.status;
      }
      if (!isNil(this.params.pickUpLat)) {
        options.where.pickUpLat = this.params.pickUpLat;
      }
      if (!isNil(this.params.pickUpLong)) {
        options.where.pickUpLong = this.params.pickUpLong;
      }
      return options;
    }
  }

  return TripInfo;
};
