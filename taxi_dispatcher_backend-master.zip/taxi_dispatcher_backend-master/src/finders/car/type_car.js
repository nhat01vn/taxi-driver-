'use strict';
const models = require('../../models');
const { BaseFinder } = require('../base');

module.exports = () => {
  class TypeCar extends BaseFinder {
    model() {
      return models.TypeCar;
    }

    isFetchAll() {
      if (this.params.id == null) {
        return true;
      }
      return false;
    }

    conditionBuilder() {
      let options = {
        attributes: ['id', 'name'],
        where: {},
        order: [['id', 'ASC']],
      };
      if (this.params.id > 0) {
        options.where.id = this.params.id;
      }
      return options;
    }
  }

  return TypeCar;
};
