'use strict';
const { Op } = require('sequelize');
const models = require('../../models');
const { BaseFinder } = require('../base');

module.exports = () => {
  class ClientInfo extends BaseFinder {
    model() {
      return models.Client;
    }

    isFetchAll() {
      if (this.params.id == null) {
        return true;
      }
      return false;
    }

    conditionBuilder() {
      let options = {
        attributes: { exclude: ['password'] },
        where: {},
        order: [['id', 'ASC']],
      };
      if (this.params.id > 0) {
        options.where.id = this.params.id;
      }
      if ((this.params.name != null) & (this.params.name != '')) {
        options.where.name = {
          [Op.iLike]: `%${this.params.name}%`,
        };
      }
      if ((this.params.phone != null) & (this.params.phone != '')) {
        options.where.phone = {
          [Op.iLike]: `%${this.params.phone}%`,
        };
      }

      return options;
    }
  }

  return ClientInfo;
};
