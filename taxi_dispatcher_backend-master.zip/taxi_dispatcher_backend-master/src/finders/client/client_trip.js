'use strict';
const models = require('../../models');
const { isBlank } = require('../../utils/lang');
const { BaseFinder } = require('../base');

module.exports = () => {
  class ClientTrips extends BaseFinder {
    model() {
      return models.Trip;
    }

    validate() {
      if (isBlank(this.params.id)) {
        this.addErrors('Client ID invalid');
      }
    }

    isFetchAll() {
      return true;
    }

    conditionBuilder() {
      return {
        where: { clientId: this.params.id },
        attributes: [
          'id',
          'uid',
          'pickUpLat',
          'pickUpAddress',
          'dropOffLat',
          'dropOffLong',
          'dropOffAddress',
          'status',
          'fareAmount',
          'createdAt',
        ],
        include: {
          model: models.Driver,
          attributes: ['id', 'uid', 'name', 'phone', 'carModel', 'carNumber'],
          include: {
            model: models.TypeCar,
            attributes: ['id', 'name'],
          },
        },
        order: [['id', 'DESC']],
      };
    }
  }

  return ClientTrips;
};
