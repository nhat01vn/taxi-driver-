const { BaseSerializer } = require('../base');

module.exports = () => {
  class Employee extends BaseSerializer {
    attributes() {
      return {
        attributes: ['uid', 'id', 'email'],
      };
    }

    beforeSerialize() {
      return [this.attachUserRole()];
    }

    async attachUserRole() {
      this.resource.role = this.userRole();
    }

    userRole() {
      switch (this.constructorName) {
        case 'Client':
          return 'client';
        case 'Driver':
          return 'driver';
        case 'Employee':
          return 'employee';
        default:
          return '';
      }
    }
  }

  return Employee;
};
