const { BaseSerializer } = require('../base');

module.exports = () => {
  class Driver extends BaseSerializer {
    attributes() {
      return {
        attributes: ['uid', 'id', 'email', 'name', 'phone', 'blockStatus', 'carModel', 'carNumber', 'photo'],
      };
    }

    beforeSerialize() {
      return [this.attachUserRole()];
    }

    async attachUserRole() {
      this.resource.role = this.userRole();
    }

    userRole() {
      switch (this.constructorName) {
        case 'Client':
          return 'client';
        case 'Driver':
          return 'driver';
        case 'Employee':
          return 'employee';
        default:
          return '';
      }
    }
  }

  return Driver;
};
