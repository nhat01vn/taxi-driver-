const models = require('../../models');
const { BaseBuilder } = require('../base');
const uuid = require('uuid');

function generateUID() {
  return uuid.v4(); // Generates a new UUID (version 4)
}

module.exports = () => {
  class Creator extends BaseBuilder {
    model() {
      return models.Trip;
    }

    prepareData() {
      return [this.validate()];
    }

    async prepareInstance() {
      this.instance = this.instance || this.models.build(this.permittedParams());
    }

    permittedParams() {
      return {
        uid: generateUID(),
        pickUpLat: this.params.pickUpLat,
        pickUpLong: this.params.pickUpLong,
        pickUpAddress: this.params.pickUpAddress,
        dropOffLat: this.params.dropOffLat,
        dropOffLong: this.params.dropOffLong,
        dropOffAddress: this.params.dropOffAddress,
        status: this.params.status,
        clientId: this.params.clientId,
        driverId: this.params.driverId,
        driverUid: this.params.driverUid,
        fareAmount: this.params.fareAmount,
      };
    }
  }

  return Creator;
};
