'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('CachedGps', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      street_number: {
        // số nhà
        type: Sequelize.STRING,
      },
      route: {
        // đường
        type: Sequelize.STRING,
      },
      administrative_area_level_2: {
        // quận - huyện
        type: Sequelize.STRING,
      },
      administrative_area_level_1: {
        // thành phố - tỉnh
        type: Sequelize.STRING,
      },
      gps_lat: {
        type: Sequelize.FLOAT,
      },
      gps_long: {
        type: Sequelize.FLOAT,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('CachedGps');
  },
};
