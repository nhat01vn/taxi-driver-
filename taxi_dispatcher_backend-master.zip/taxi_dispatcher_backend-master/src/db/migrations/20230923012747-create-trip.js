'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Trips', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      uid: {
        unique: true,
        type: Sequelize.STRING,
      },
      pickUpLat: {
        // pick up lat
        type: Sequelize.FLOAT,
      },
      pickUpLong: {
        // pick up long
        type: Sequelize.FLOAT,
      },
      pickUpAddress: {
        type: Sequelize.STRING,
      },
      dropOffLat: {
        // drop Off lat
        type: Sequelize.FLOAT,
      },
      dropOffLong: {
        // drop Off long
        type: Sequelize.FLOAT,
      },
      dropOffAddress: {
        type: Sequelize.STRING,
      },
      status: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'new',
      },
      clientId: {
        type: Sequelize.INTEGER,
        onDelete: 'CASCADE',
        references: {
          model: 'Clients',
          key: 'id',
          as: 'clientId',
        },
      },
      driverId: {
        type: Sequelize.INTEGER,
        onDelete: 'CASCADE',
        references: {
          model: 'Drivers',
          key: 'id',
          as: 'driverId',
        },
      },
      fareAmount: {
        type: Sequelize.FLOAT,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface) {
    await queryInterface.dropTable('Trips');
  },
};
