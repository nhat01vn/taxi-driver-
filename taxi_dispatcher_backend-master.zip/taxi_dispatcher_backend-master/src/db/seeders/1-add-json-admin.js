'use strict';

module.exports = {
  up: async () => {
    const models = require('../../models');
    const map = require('lodash/map');
    const fs = require('fs');
    const seederHandler = require('../../helpers/seeder_handler');
    const { hashPassword } = require('../../utils/bcrypt');

    // File path
    const adminFilePath = 'src/db/initial_materials/admin.json';

    /****************************
     for Admin
     ****************************/

    /* Convert data */
    let adminParsedData = JSON.parse(fs.readFileSync(adminFilePath));
    const hashedAdminPassword = map(adminParsedData, async (item) => {
      return {
        tempId: item.id,
        uid: item.uid,
        isAdmin: item.isAdmin,
        email: item.email,
        password: await hashPassword(item.password),
        resetToken: item.resetToken,
      };
    });
    const adminData = await Promise.all(hashedAdminPassword);

    /* Insert to table */
    let adminFields = ['uid', 'isAdmin', 'email', 'password', 'resetToken'];
    await seederHandler.insertAndMap(adminData, models.Employee, adminFields);
  },
};
