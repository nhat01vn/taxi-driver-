'use strict';
let controller = {};
const models = require('../models');
const Trip = models.Trip;

controller.add = (trip) => {
  return new Promise((resolve, reject) => {
    Trip.create(trip)
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.update = (trip) => {
  return new Promise((resolve, reject) => {
    Trip.update(trip, { where: { id: trip.id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.delete = (id) => {
  return new Promise((resolve, reject) => {
    Trip.destroy({ where: { id: id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

module.exports = controller;
