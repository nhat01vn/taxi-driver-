'use strict';
const express = require('express');
const router = express.Router();

const exceptionHandler = require('../helpers/exception_handler');
const builders = require('../builders');
const services = require('../services');
const serializers = require('../serializers');

/* Add a new employee */
router.post('/employee', (req, res) => {
  builders.employee.Creator.execute(req, req.body)
    .then((data) => exceptionHandler.blankResource(data, 400, 'Create failed. Please try again'))
    .then((data) => {
      serializers.Employee.serialize(data).then((resp) => {
        res.status(201).json(resp);
      });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Add a new user */
router.post('/', (req, res) => {
  builders.client.Creator.execute(req, req.body)
    .then((data) => exceptionHandler.blankResource(data, 400, 'Create failed. Please try again'))
    .then((data) => {
      serializers.Client.serialize(data).then((resp) => {
        res.status(201).json(resp);
      });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Add a new driver */
router.post('/driver', (req, res) => {
  builders.driver.Creator.execute(req, req.body)
    .then((data) => exceptionHandler.blankResource(data, 400, 'Create failed. Please try again'))
    .then((data) => {
      serializers.Driver.serialize(data).then((resp) => {
        res.status(201).json(resp);
      });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Forgot password */
router.post('/forgot-password', async (req, res) => {
  services.user.ForgotPassword.call(req.body)
    .then(() => {
      res.json({ message: 'success' });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Reset password */
router.post('/reset-password', async (req, res) => {
  services.user.ResetPassword.call(req.body)
    .then(() => {
      res.json({ message: 'success' });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Register a new trip */
router.post('/register-trip', (req, res) => {
  console.log('### data: ', req.body);
  let simulate = true;
  if (simulate) {
    services.user.RegisterTrip.call(req.body)
      .then((data) => {
        res.json({
          message: 'success',
          data: data,
        });
      })
      .catch((error) => exceptionHandler.error(req, res, error));
  } else {
    // when something fails
    res.status(404).send('Not found');
  }
});

/* Send a SMS message */
router.post('/sendsms', async (req, res) => {
  console.log('### data: ', req.body);
  services.user.SendSMS.call(req.body.toPhone, req.body.data)
    .then(() => {
      res.json({ message: 'success' });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Get location GPS */
router.post('/findgps', async (req, res) => {
  console.log('### data: ', req.body);
  services.gps.GPSGetter.call(req.body)
    .then((data) => {
      res.json({
        message: 'success',
        data: data,
      });
    })
    .catch((error) => exceptionHandler.error(req, res, error));
});

/* Get all cached GPS */
router.get('/cachedgps', async (req, res) => {
  try {
    let result = await services.gps.GPSGetter.call({});
    if (result) {
      res.status(201).json(result);
    } else {
      exceptionHandler.resourceNotFound(result, 'Cached GPS');
    }
  } catch (error) {
    exceptionHandler.error(req, res, error);
  }
});

module.exports = router;
