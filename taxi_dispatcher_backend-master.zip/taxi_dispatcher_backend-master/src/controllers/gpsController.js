'use strict';
let controller = {};
const models = require('../models');
const CachedGps = models.CachedGps;
const { Op } = require('sequelize');

controller.find = (params) => {
  return new Promise((resolve, reject) => {
    CachedGps.findOne({
      where: {
        street_number: { [Op.iLike]: `${params.street_number}` },
        route: { [Op.iLike]: `${params.route}` },
        administrative_area_level_2: { [Op.like]: `${params.administrative_area_level_2}` },
        administrative_area_level_1: { [Op.iLike]: `${params.administrative_area_level_1}` },
      },
    })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.getAll = () => {
  return new Promise((resolve, reject) => {
    CachedGps.findAll()
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.add = (address) => {
  return new Promise((resolve, reject) => {
    CachedGps.create(address)
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.update = (address) => {
  return new Promise((resolve, reject) => {
    CachedGps.update(address, { where: { id: address.id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.delete = (id) => {
  return new Promise((resolve, reject) => {
    CachedGps.destroy({ where: { id: id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

module.exports = controller;
