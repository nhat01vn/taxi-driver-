'use strict';
let controller = {};
const models = require('../models');
const Client = models.Client;
const uuid = require('uuid');

function generateUID() {
  return uuid.v4(); // Generates a new UUID (version 4)
}

controller.add = (client) => {
  return new Promise((resolve, reject) => {
    client.id = client.id || null;
    Client.findOne({ where: { id: client.id } })
      .then((data) => {
        if (data) {
          return Client.update(client, {
            where: { id: client.id },
          });
        } else {
          if (!client.uid) {
            client.uid = generateUID();
          }
          client.blockStatus = 'no';

          return Client.create(client);
        }
      })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.update = (client) => {
  return new Promise((resolve, reject) => {
    Client.update(client, { where: { id: client.id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.delete = (id) => {
  return new Promise((resolve, reject) => {
    Client.destroy({ where: { id: id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

module.exports = controller;
