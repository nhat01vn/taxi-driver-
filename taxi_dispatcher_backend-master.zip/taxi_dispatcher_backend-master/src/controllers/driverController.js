'use strict';
let controller = {};
const models = require('../models');
const Driver = models.Driver;
const uuid = require('uuid');

function generateUID() {
  return uuid.v4(); // Generates a new UUID (version 4)
}

controller.add = (driver) => {
  return new Promise((resolve, reject) => {
    driver.id = driver.id || null;
    Driver.findOne({ where: { id: driver.id } })
      .then((data) => {
        if (data) {
          return Driver.update(driver, {
            where: { id: driver.id },
          });
        } else {
          driver.uid = generateUID();
          return Driver.create(driver);
        }
      })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.updateStatus = (driverId, newStatus) => {
  return new Promise((resolve, reject) => {
    Driver.update({ status: newStatus }, { where: { id: driverId } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.setNewTripStatus = (driverId, newTripStatus) => {
  return new Promise((resolve, reject) => {
    Driver.update({ newTripStatus: newTripStatus }, { where: { id: driverId } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.updateGps = (driver) => {
  return new Promise((resolve, reject) => {
    Driver.update(
      {
        lat: driver.lat,
        long: driver.long,
      },
      {
        where: { id: driver.id },
      }
    )
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.update = (driver) => {
  return new Promise((resolve, reject) => {
    Driver.update(driver, { where: { id: driver.id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

controller.delete = (id) => {
  return new Promise((resolve, reject) => {
    Driver.destroy({ where: { id: id } })
      .then((data) => resolve(data))
      .catch((error) => reject(new Error(error)));
  });
};

module.exports = controller;
