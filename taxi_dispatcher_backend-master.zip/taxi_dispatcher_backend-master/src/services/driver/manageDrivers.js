const PushNotificationService = require('../pushNotification/pushNotificationService');
const driverController = require('../../controllers/driverController');
const finders = require('../../finders');
const exceptionHandler = require('../../helpers/exception_handler');
const { calDistanceFromLatLongInKm } = require('../../utils/cal_distance');
const firebase = require('firebase-admin');

class ManageDrivers {
  constructor(params, radius, requestTimeout) {
    (this.tripRequest = params || {}),
      (this.radius = radius || 2), // radius in km
      (this.requestTimeoutTime = requestTimeout || 20000),
      (this.nearbyOnlineDrivers = []),
      this.currentDriverRef;
  }

  static getDriver(params, radius, requestTimeout) {
    const instance = new this(params, radius, requestTimeout);

    return instance.getDriver();
  }

  static getNearbyOnlineDrivers(params, radius, requestTimeout) {
    const instance = new this(params, radius, requestTimeout);

    return instance.getNearbyOnlineDrivers();
  }

  async getDriver() {
    // Lấy danh sách drivers trong bán kính radius
    await this.getNearbyOnlineDrivers();

    // Gửi notification đến lần lượt driver trong list -> return acceptedDriver / null
    return await this.searchDriver();
  }

  async getNearbyOnlineDrivers() {
    let result = await finders.driver.DriverInfo.find(scope(this.tripRequest, 'driver'), { newTripStatus: 'waiting' });
    if (result) {
      result.forEach((onlineDriver) => {
        let distance = calDistanceFromLatLongInKm(
          this.tripRequest.pickUpLatLng.latitude,
          this.tripRequest.pickUpLatLng.longitude,
          onlineDriver.lat,
          onlineDriver.long
        );
        if (distance <= this.radius) {
          this.nearbyOnlineDrivers.push(onlineDriver);
        }
      });
      return this.nearbyOnlineDrivers;
    } else {
      exceptionHandler.resourceNotFound(result, 'Drivers');
    }
  }

  async searchDriver() {
    // Nếu danh sách drivers rỗng -> không có driver nhận chuyến xe
    if (this.nearbyOnlineDrivers.length == 0) {
      return null;
    }

    // gửi notification cho driver đầu tiên trong list
    let currentDriver = this.nearbyOnlineDrivers[0];
    this.sendNotificationToDriver(currentDriver);

    // xóa driver đầu tiên ra khỏi list
    this.nearbyOnlineDrivers.splice(0, 1);

    // set timer
    await this.sleep(this.requestTimeoutTime);

    // Kiểm tra driver có nhận chuyến xe không
    let newTripStatus = await this.getNewTripstatus(currentDriver.id);
    if (newTripStatus == 'accepted') {
      return currentDriver;
    } else {
      await driverController.setNewTripStatus(currentDriver.id, 'timeout');
      this.currentDriverRef.set('timeout');
      this.currentDriverRef.onDisconnect();
      // gửi notification đến driver tiếp theo
      return this.searchDriver();
    }
  }

  async sendNotificationToDriver(currentDriver) {
    this.currentDriverRef = firebase.database().ref().child('drivers').child(currentDriver.uid).child('newTripStatus');

    // update newTripStatus = tripID
    this.currentDriverRef.set(this.tripRequest.tripID);
    await driverController.setNewTripStatus(currentDriver.id, this.tripRequest.tripID);

    // gửi notification
    await PushNotificationService().sendNotificationToSelectedDriver(currentDriver, this.tripRequest);
  }

  async getNewTripstatus(driverId) {
    let driverInfo = await finders.driver.DriverNewTripStatus.find(scope(driverId, 'driver'), { id: driverId });
    return driverInfo.newTripStatus;
  }

  sleep(millis) {
    return new Promise((resolve) => setTimeout(resolve, millis));
  }

  removeDriverFromList(driverId) {
    let index = this.nearbyOnlineDrivers.indexOf((driver) => driver.id == driverId);
    if (index !== -1) {
      this.nearbyOnlineDrivers.splice(index, 1);
    }
  }

  async updateDriverLocation(newDriverInformation) {
    let index = this.nearbyOnlineDrivers.indexOf((driver) => driver.id == newDriverInformation.id);
    if (index !== -1) {
      this.nearbyOnlineDrivers[index].lat = newDriverInformation.lat;
      this.nearbyOnlineDrivers[index].long = newDriverInformation.long;
    }
  }

  validate() {
    if (this.params == null) {
      return false;
    }
    return true;
  }
}

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = () => {
  return ManageDrivers;
};
