'use strict';
const { isBlank } = require('../../utils/lang');
const responder = require('../../helpers/responder');
const finders = require('../../finders');
const GPSGetter = require('../gps/getter_gps');
const ManageDrivers = require('../driver/manageDrivers');
const PushNotificationService = require('../pushNotification/pushNotificationService');
const tripController = require('../../controllers/tripController');
const clientController = require('../../controllers/clientController');
const firebase = require('firebase-admin');

class RegisterTrip {
  static call(params, config = {}) {
    const instance = new this(params, config);

    return instance.call();
  }

  constructor(params, config) {
    this.params = params;
    this.config = config || {};
    this.radius = config.radius || 2; // radius in km
    this.tripRequest = {};
    this.client = {};
    this.driver = {};
    this.tripRequestRef = {};
    this.pickUpCoOrdinatesMap = {};
    this.dropOffCoOrdinatesMap = {};
  }

  async call() {
    this.validate();

    // Lấy info client từ số điện thoại
    this.client = await this.getClientInformation();

    // Tìm GPS từ địa chỉ
    await this.getGPSFromAddress();

    // Lưu vào Firebase databse -> listen response từ tripRequests
    await this.makeTripRequest();

    // Tìm và gửi notification cho lần lượt từng driver trong bán kính radius
    this.driver = await ManageDrivers().getDriver(this.tripRequest, this.radius);
    if (!this.driver) {
      this.cancelTripRequest();
      throw responder.resourceNotFound('Please try again later! Nearby Drivers');
    } else {
      PushNotificationService().sendsms(this.client, this.driver);
      return this.driver;
    }
  }

  validate() {
    if (!isBlank(this.params)) return;

    throw responder.unprocessableEntity('Trip Request Info is required.');
  }

  async getGPSFromAddress() {
    let gpsLatLng = await GPSGetter().call({ addressString: this.params.pickUpAddress });
    this.pickUpCoOrdinatesMap = {
      latitude: gpsLatLng.gps_lat.toString(),
      longitude: gpsLatLng.gps_long.toString(),
    };

    gpsLatLng = await GPSGetter().call({ addressString: this.params.dropOffAddress });
    this.dropOffCoOrdinatesMap = {
      latitude: gpsLatLng.gps_lat.toString(),
      longitude: gpsLatLng.gps_long.toString(),
    };
  }

  async getClientInformation() {
    let client = await finders.client.ClientInfo.find(scope(this.params.phone, 'client'), { phone: this.params.phone });
    if (client[0]) {
      return client[0];
    } else {
      let newClient = {
        name: this.params.name,
        phone: this.params.phone,
      };
      return clientController.add(newClient);
    }
  }

  async makeTripRequest() {
    // Tạo tripRequestRef trong Firebase databse
    this.tripRequestRef = firebase.database().ref().child('tripRequests').push();

    // Tạo object tripRequest
    this.tripRequest = {
      tripID: this.tripRequestRef.key,
      publishDateTime: new Date().toString(),

      userName: this.client.name,
      userPhone: this.client.phone,
      userID: this.client.id,

      pickUpLatLng: this.pickUpCoOrdinatesMap,
      dropOffLatLng: this.dropOffCoOrdinatesMap,

      pickUpAddress: this.params.pickUpAddress,
      dropOffAddress: this.params.dropOffAddress,

      driverID: 'waiting',
      driverName: '',
      driverPhone: '',
      driverPhoto: '',
      driverLocation: {},
      carDetails: '',
      fareAmount: '',
      status: 'new',
    };

    // Lưu tripRequest vào Firebase databse
    this.tripRequestRef.set(this.tripRequest);

    // Listen response từ tripRequestRef
    var tripStreamSubscription = this.tripRequestRef.on('value', (snap) => {
      if (snap.val() == null) {
        return;
      }
      if (snap.val()['driverName'] != '') {
        this.tripRequest.driverName = snap.val().driverName;
      }
      if (snap.val()['driverPhone'] != '') {
        this.tripRequest.driverPhone = snap.val().driverPhone;
      }
      if (snap.val()['driverPhoto'] != '') {
        this.tripRequest.driverPhoto = snap.val().driverPhoto;
      }
      if (snap.val()['carDetails'] != '') {
        this.tripRequest.carDetails = snap.val().carDetails;
      }
      if (snap.val()['fareAmount'] != '') {
        this.tripRequest.fareAmount = parseFloat(snap.val().fareAmount);
      }
      if (snap.val()['status'] != '') {
        this.tripRequest.status = snap.val().status;
      }
      if (this.tripRequest.status == 'accepted') {
        // send sms to client phone
        // PushNotificationService().sendsms(this.client, this.tripRequest);
      }
      if (this.tripRequest.status == 'ended') {
        if (snap.val()['fareAmount'] != '') {
          this.tripRequest.fareAmount = parseFloat(snap.val().fareAmount);
        }

        // disconnect firebase database
        this.tripRequestRef.off('value', tripStreamSubscription);
        this.tripRequestRef = {};

        // lưu tripRequest vào local database
        return this.addTripRequestToDatabase();
      }
    });
  }

  cancelTripRequest() {
    //remove tripRequest from firebase database
    this.tripRequestRef.remove();
  }

  async addTripRequestToDatabase() {
    let newTrip = {
      uid: this.tripRequest.tripID,
      pickUpLat: this.pickUpCoOrdinatesMap.latitude,
      pickUpLong: this.pickUpCoOrdinatesMap.longitude,
      pickUpAddress: this.tripRequest.pickUpAddress,
      dropOffLat: this.dropOffCoOrdinatesMap.latitude,
      dropOffLong: this.dropOffCoOrdinatesMap.longitude,
      dropOffAddress: this.tripRequest.dropOffAddress,
      status: this.tripRequest.status,
      fareAmount: parseFloat(this.tripRequest.fareAmount) || 0,
      clientId: this.client.id,
      driverId: this.driver.id,
    };

    try {
      let result = await tripController.add(newTrip);
      if (result) {
        console.log('Add new trip success: ', JSON.stringify(result));
      }
    } catch (error) {
      console.log(error);
    }
  }
}

// PRIVATE

const scope = (_req, _action) => {
  return [];
};

module.exports = () => {
  return RegisterTrip;
};
