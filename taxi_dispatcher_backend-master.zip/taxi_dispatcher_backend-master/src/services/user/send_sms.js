const { isBlank } = require('../../utils/lang');
const responder = require('../../helpers/responder');

const { Vonage } = require('@vonage/server-sdk');
const vonage = new Vonage({
  apiKey: process.env.VONAGE_API_KEY,
  apiSecret: process.env.VONAGE_API_SECRET,
});

class SendSMS {
  static call(toPhone, data) {
    const instance = new this(toPhone, data);

    return instance.call();
  }

  constructor(toPhone, data) {
    this.toPhone = toPhone;
    this.driver = data;
    this.content = '';
  }

  async call() {
    this.validate();
    this.makeContent();

    await vonage.sms
      .send({
        message_type: 'text',
        to: this.toPhone,
        from: 'CallCenter',
        text: this.content,
        channel: 'sms',
      })
      .then((resp) => {
        console.log(this.content);
        console.log(resp);
      })
      .catch((err) => {
        console.log('There was an error sending the messages.');
        console.error(err);
      });
  }

  validate() {
    if (isBlank(this.toPhone)) {
      throw responder.unprocessableEntity(`Phone Nummber is required.`);
    }
  }

  makeContent() {
    this.content = `Tai Xe ${this.driver.name}, SDT ${this.driver.phone}, Bien So Xe: ${this.driver.carNumber}, se den don ban trong vong vai phut!`;
  }
}

module.exports = () => {
  return SendSMS;
};
