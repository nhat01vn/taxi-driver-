'use strict';
const SendSMS = require('../user/send_sms');
const exceptionHandler = require('../../helpers/exception_handler');
const serverKeyFCM = `key=${process.env.FCM_API_KEY}`;
const fetch = require('node-fetch');

class PushNotificationService {
  constructor(currentDriver, tripRequest) {
    (this.currentDriver = currentDriver), (this.tripRequest = tripRequest), (this.message = {});
  }

  static sendNotificationToSelectedDriver(currentDriver, tripRequest) {
    const instance = new this(currentDriver, tripRequest);

    return instance.sendNotificationToSelectedDriver();
  }

  static sendsms(currentDriver, tripRequest) {
    const instance = new this(currentDriver, tripRequest);

    return instance.sendsms();
  }

  async sendNotificationToSelectedDriver() {
    try {
      if (this.currentDriver.deviceToken != null && this.currentDriver.deviceToken != '') {
        let deviceToken = this.currentDriver.deviceToken;

        let headerNotification = {
          'Content-Type': 'application/json',
          Authorization: serverKeyFCM,
        };

        let titleBodyNotification = {
          title: 'NEW TRIP REQUEST from CALL CENTER',
          body: `PickUp Address: ${this.tripRequest.pickUpAddress} - GPS location: (${this.tripRequest.pickUpLatLng.latitude}, ${this.tripRequest.pickUpLatLng.longitude}) - Customer's phone: ${this.tripRequest.userPhone}`,
        };

        let dataNotification = {
          click_action: 'FLUTTER_NOTIFICATION_CLICK',
          id: '1',
          status: 'done',
          tripID: this.tripRequest.tripID,
        };

        const message = {
          notification: titleBodyNotification,
          data: dataNotification,
          priority: 'high',
          to: deviceToken,
        };

        const response = await fetch('https://fcm.googleapis.com/fcm/send', {
          method: 'POST',
          headers: headerNotification,
          body: JSON.stringify(message),
        });
        const result = await response.json();
        console.log('Success:', result);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }

  async sendsms() {
    let driverInformation = {
      name: this.tripRequest.name,
      phone: this.tripRequest.phone,
      carNumber: this.tripRequest.carNumber,
    };

    SendSMS()
      .call(this.currentDriver.phone, driverInformation)
      .then(() => {
        console.log('Sent sms message success');
      })
      .catch((error) => exceptionHandler.error(null, null, error));
  }
}

module.exports = () => {
  return PushNotificationService;
};
