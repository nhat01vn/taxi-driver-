const gpsController = require('../../controllers/gpsController');
const fetch = require('node-fetch');

class GPSGetter {
  static call(params) {
    const instance = new this(params);

    return instance.call();
  }

  constructor(params) {
    (this.addressString = params.addressString || ''),
      (this.address = {
        street_number: '',
        route: '',
        administrative_area_level_2: '',
        administrative_area_level_1: '',
        gps_lat: null,
        gps_long: null,
      });
  }

  async call() {
    this.splitAddressPart();

    // Get all cachedGps
    if (!this.validate()) {
      return await gpsController.getAll();
    } else {
      // Tìm GPS trong CachedGps
      let location = await gpsController.find(this.address);
      if (location) {
        console.log('Get GPS from cachedGPS');
        return location;
      } else {
        // Gọi api google map
        console.log('Call google map API');
        let gps = await this.getGpsByMapAPI();

        // Lưu vào CachedGps
        this.address.gps_lat = gps.lat;
        this.address.gps_long = gps.lng;
        return await gpsController.add(this.address);
      }
    }
  }

  validate() {
    if (
      this.addressString == '' ||
      (this.address.street_number == '' &&
        this.address.route == '' &&
        this.address.administrative_area_level_1 == '' &&
        this.address.administrative_area_level_2 == '')
    ) {
      return false;
    }
    return true;
  }

  splitAddressPart() {
    let addressPart = this.addressString.split(', ');
    this.address = {
      street_number: addressPart[0],
      route: addressPart[1],
      administrative_area_level_2: addressPart[2],
      administrative_area_level_1: addressPart[3],
    };
  }

  toString(address) {
    return `${address.street_number}, ${address.route}, ${address.administrative_area_level_2}, ${address.administrative_area_level_1}`;
  }

  async getGpsByMapAPI() {
    let api_key = process.env.GOOGLE_API_KEY;

    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${this.addressString}&key=${api_key}`
    );
    const data = await response.json();
    console.log(data);
    return data.results[0].geometry.location;
  }
}

module.exports = () => {
  return GPSGetter;
};
