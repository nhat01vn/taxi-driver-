const pick = require('lodash/pick');

/**
 * Insert to DB
 * @param {*} parsedData
 * @param {*} modelName
 * @param {*} modelFields
 * @returns {} or 例 {1:15, 2:16} 仮のIDとDBのIDのマッピング
 */
const insert = async (parsedData, modelName, modelFields) => {
  for (const item of parsedData) {
    const itemInserted = await modelName.create(pick(item, modelFields));
    item.id = itemInserted.id;
  }
};

/**
 * Insert to DB and also return the ID mapping
 * この関数はitem.tempId がある時に使える (jsonファイルファイルにIDがある時だけのことです)
 * @param {*} parsedData
 * @param {*} modelName
 * @param {*} modelFields
 * @returns {} or 例 {1:15, 2:16} 仮のIDとDBのIDのマッピング
 */
const insertAndMap = async (parsedData, modelName, modelFields) => {
  let tempIdToMap = {};
  for (const item of parsedData) {
    const itemInserted = await modelName.create(pick(item, modelFields));
    item.id = itemInserted.id;
    tempIdToMap[item.tempId] = item.id;
  }
  return tempIdToMap;
};

module.exports = {
  insert,
  insertAndMap,
};
