'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class CachedGps extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
  }
  CachedGps.init(
    {
      street_number: DataTypes.STRING,
      route: DataTypes.STRING,
      administrative_area_level_2: DataTypes.STRING,
      administrative_area_level_1: DataTypes.STRING,
      gps_lat: DataTypes.FLOAT,
      gps_long: DataTypes.FLOAT,
    },
    {
      sequelize,
      modelName: 'CachedGps',
    }
  );
  return CachedGps;
};
