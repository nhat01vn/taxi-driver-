<template>
  <div id="app">
    <div class="loadingBackground" v-if="isShowLoading">
      <div class="loadingDialog">
        <half-circle-spinner :animation-duration="1000" :size="60" :color="'#ffffff'" />
      </div>
    </div>
    <router-view :key="$route.fullPath" v-slot="{ Component }" class="content-wrapper">
      <transition enter-active-class="animated fadeIn">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>

<script>
import { computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useStore } from 'vuex';
import { HalfCircleSpinner } from 'epic-spinners';

export default {
  name: 'App',
  components: {
    HalfCircleSpinner,
  },
  setup() {
    const store = useStore();
    const router = useRouter();
    const route = useRoute();

    const isSignedIn = computed(() => {
      return store.getters['auth/isSignedIn'];
    });
    const isShowLoading = computed(() => {
      return store.getters['loading/isShowLoading'];
    });

    const listRoutes = ['/login', '/register', '/forgot-password', '/reset-password'];
    store
      .dispatch('auth/restoreSession')
      .then(() => {
        store.dispatch('auth/verifySession').then(() => {
          if (!listRoutes.includes(router.currentRoute.value.path) && !isSignedIn.value)
            return router.push({ name: 'Login' });

          if (listRoutes.includes(router.currentRoute.value.path)) {
            router.push({ name: 'Home' });
          }
        });
      })
      .catch(() => {
        setTimeout(() => {
          if (!listRoutes.includes(router.currentRoute.value.path)) {
            router.push({ name: 'Login' });
          }
        }, 100);
      })
      .finally(() => {
        store.dispatch('loading/hideLoading');
      });

    return {
      //Variables

      //Computed
      isSignedIn,
      isShowLoading,
    };
  },
};
</script>

<style lang="scss" scoped>
.content-wrapper {
  overflow-x: auto;
  width: 100%;
  height: 100vh;
}

/* Hide scrollbar for Chrome, Safari and Opera */
.loadingDialog::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.loadingDialog {
  -ms-overflow-style: none; /* IE and Edge */
  scrollbar-width: none; /* Firefox */
}
</style>
