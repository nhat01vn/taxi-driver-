export const namespaced = true;

import { useToast } from 'vue-toastification';

export const state = {
  isLoading: true,
};

export const mutations = {
  SHOW_LOADING(state) {
    state.isLoading = true;
  },
  HIDE_LOADING(state) {
    state.isLoading = false;
  },
};

export const actions = {
  showLoading({ commit }) {
    commit('SHOW_LOADING');
  },
  hideLoading({ commit }) {
    commit('HIDE_LOADING');
  },
  showToastedTodo(_, apiName) {
    const toast = useToast();

    toast.warning(`Waiting for Backend API ${apiName} is ready ...`);
  },
};

export const getters = {
  isShowLoading: (state) => {
    return state.isLoading;
  },
};
