export const namespaced = true;

import * as AuthService from '@/services/auth';
import { isPresent } from '@/utils/lang.js';
import { loadLocalUser, storeLocalUser, clearLocalUser } from '@/services/localStorage';

export const state = {
  localSessionRestored: false,
  currentUser: {},
};

export const mutations = {
  SET_CURRENT_USER(state, userData) {
    state.currentUser = userData;
    storeLocalUser(userData);
  },
  CLEAR_CURRENT_USER(state) {
    state.currentUser = {};
    clearLocalUser();
  },
};

export const actions = {
  login({ commit }, formData) {
    return new Promise((resolve, reject) => {
      return AuthService.login(formData)
        .then((userData) => {
          if (!userData || !userData.token) throw userData;

          // Update user data to vuex state
          commit('SET_CURRENT_USER', userData);
          resolve(userData);
        })
        .catch((error) => {
          reject(error);
        });
    });
  },
  restoreSession({ commit, state }) {
    if (state.localSessionRestored) return;

    return new Promise((resolve, reject) => {
      let userData = loadLocalUser();
      if (userData && userData.token) {
        commit('SET_CURRENT_USER', userData);

        // Mark flag user data restored from local storage to state
        state.localSessionRestored = true;

        resolve(userData);
      } else {
        commit('CLEAR_CURRENT_USER');
        reject({});
      }
    });
  },
  verifySession({ commit }) {
    // Double check user token still valid
    return AuthService.auth()
      .then((userData) => {
        if (!userData || !userData.token) throw userData;

        commit('SET_CURRENT_USER', userData);
      })
      .catch(() => {
        commit('CLEAR_CURRENT_USER');
      });
  },
  logout({ commit }) {
    commit('CLEAR_CURRENT_USER');
  },
};

export const getters = {
  isSignedIn(state) {
    return isPresent(state.currentUser) && isPresent(state.currentUser.token);
  },
  currentUser(state) {
    return state.currentUser;
  },
};
