export const namespaced = true;

import * as UserService from '@/services/user';
import { isPresent } from '@/utils/lang.js';
import { loadLocalUser, storeLocalUser, clearLocalUser } from '@/services/localStorage';

export const actions = {
  registerTrip(_, formData) {
    return new Promise((resolve, reject) => {
      UserService.registerTrip(formData)
        .then((resp) => {
          const data = resp.status == 200 ? resp.data : {};
          resolve(data);
        })
        .catch((error) => {
          reject(error);
        });
    });
  },
  register(_, formData) {
    return UserService.register(formData);
  },
  forgotPassword(_, formData) {
    return new Promise((resolve, reject) => {
      UserService.forgotPassword(formData)
        .then((resp) => {
          resolve(resp);
        })
        .catch((error) => {
          reject(error);
        });
    });
  },
  resetPassword(_, formData) {
    return new Promise((resolve, reject) => {
      UserService.resetPassword(formData)
        .then((resp) => {
          resolve(resp);
        })
        .catch((error) => {
          reject(error);
        });
    });
  },
};
