import { createStore } from 'vuex';
import * as auth from '@/store/modules/auth.js';
import * as user from '@/store/modules/user.js';
import * as loading from '@/store/modules/loading.js';

export default createStore({
  state: {},
  mutations: {},
  actions: {},
  modules: {
    auth,
    user,
    loading,
  },
});
