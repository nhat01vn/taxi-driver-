import isEmpty from 'lodash/isEmpty';
import isNumber from 'lodash/isNumber';

export const presence = (value) => {
  if (isBlank(value)) return null;

  return value;
};

export const isPresent = (value) => {
  return !isBlank(value);
};

export const isBlank = (value) => {
  if (isNumber(value) || value == true) {
    return false;
  }
  if (Object.prototype.toString.call(value) === '[object Date]') {
    return false;
  }
  return isEmpty(value);
};
