import { createApp } from 'vue';
import Toast from 'vue-toastification';
import App from './App.vue';
import router from './router';
import store from './store';

// Style Sheets
import 'nprogress/nprogress.css';
import 'bootstrap/dist/css/bootstrap.css';
import '@/assets/stylesheets/common.css';
import '@/assets/stylesheets/animate.css';
import 'vue-toastification/dist/index.css';
import '@/assets/font-icons/css/fontello.css';
import '@/assets/stylesheets/app.scss';

// Mixins
import object from '@/mixins/object';

// Boostrap
import 'bootstrap';

import NProgress from 'nprogress';
NProgress.configure({ showSpinner: false });

export const app = createApp(App).use(store).use(router).use(Toast, {});

app.mixin(object);
app.mount('#app');
