<template>
  <div class="dropdown" :class="{ disabled: disabled, 'read-only': readOnly }">
    <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
      <span class="text">{{ selectedOption.name }}</span>
    </button>
    <ul class="dropdown-menu">
      <li v-for="(option, index) in options" :key="index" @click="select(option)">
        <a class="dropdown-item" :class="{ active: selectedOption.name === option.name }">{{ option.name }}</a>
      </li>
    </ul>
  </div>
</template>

<script>
import { computed } from 'vue';

export default {
  name: 'ButtonDropdown',
  props: {
    selected: {
      type: Object,
      required: true,
    },
    options: {
      type: Array,
      default: () => {
        return [];
      },
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    readOnly: {
      type: Boolean,
      default: false,
    },
  },
  emits: ['select'],
  setup(props, { emit }) {
    const selectedOption = computed(() => {
      return props.selected;
    });

    const select = (option) => {
      emit('select', option);
    };

    return {
      // Variables
      selectedOption,

      // Methods
      select,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.dropdown {
  background-color: white;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  text-align: left;
  width: 100%;
  .dropdown-menu {
    overflow: auto;
    max-height: 300px;
    &.show {
      min-width: 100%;
      width: auto;
    }
    .dropdown-item {
      color: #172a6e;
    }
    .active {
      color: white;
      background-color: #172a6e;
    }
  }
  .dropdown-toggle {
    color: #172a6e;
    font-size: 1rem;
    &::after {
      transform: rotate(45deg);
      padding: 4px;
      border: solid #f2c100;
      border-width: 0 2px 2px 0;
      margin-top: -4px;
    }
  }
  .btn {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 45px;
    .text {
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 1; /* number of lines to show */
      -webkit-box-orient: vertical;
    }
  }
  &.disabled {
    .dropdown-toggle {
      pointer-events: none;
      color: #172a6e;
      opacity: 0.5;
      font-size: 1rem;
      &::after {
        transform: rotate(45deg);
        padding: 4px;
        border: solid #e5e5e5;
        border-width: 0 2px 2px 0;
        margin-top: -4px;
      }
    }
  }
  &.read-only {
    border: none;
    background: #fafafa;
    .dropdown-toggle {
      pointer-events: none;
      color: #172a6e;
      font-size: 1rem;
      &::after {
        display: none;
      }
    }
  }
}
</style>
