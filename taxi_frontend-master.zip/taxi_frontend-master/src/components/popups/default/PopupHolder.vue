<template>
  <!-- Modal -->
  <div class="modal fade" :id="generateUniqueKey" :key="generateUniqueKey">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <slot name="header">
            <!-- default value where no content is provided  -->
            <div v-if="type === 'success'">
              <img class="logo" src="@/assets/images/default/popups/icon_success.svg" />
            </div>
            <div v-if="type === 'warning'">
              <img class="logo" src="@/assets/images/default/popups/icon_warning.svg" />
            </div>
            <div v-if="type === 'delete'">
              <img class="logo" src="@/assets/images/default/popups/icon_delete.svg" />
            </div>
            <div v-if="type === 'error'">
              <img class="logo" src="@/assets/images/default/popups/icon_error.svg" />
            </div>
          </slot>
        </div>
        <div class="modal-body">
          <slot name="body">
            <!-- default value where no content is provided  -->
            <div v-if="type === 'success'">
              <p class="text">保存しました</p>
            </div>
            <div v-if="type === 'warning'">
              <p class="text">編集内容を破棄しますか？</p>
            </div>
            <div v-if="type === 'delete'">
              <p class="text">この情報を削除しますか？</p>
            </div>
            <div v-if="type === 'error'">
              <p class="text">Something wrong</p>
            </div>
          </slot>
        </div>
        <div class="modal-footer">
          <slot name="footer">
            <!-- default value where no content is provided  -->
            <div v-if="type === 'success'">
              <button type="button" class="button-success" data-bs-dismiss="modal" @click="submit">OK</button>
            </div>
            <div v-if="type === 'warning'">
              <button type="button" class="btn-cancel" data-bs-dismiss="modal" @click="cancel">キャンセル</button>
              <button type="button" class="btn-delete" data-bs-dismiss="modal" @click="submit">破棄</button>
            </div>
            <div v-if="type === 'delete'">
              <button type="button" class="btn-cancel" data-bs-dismiss="modal" @click="cancel">キャンセル</button>
              <button type="button" class="btn-delete" data-bs-dismiss="modal" @click="submit">削除</button>
            </div>
            <div v-if="type === 'error'">
              <button type="button" class="btn-delete" data-bs-dismiss="modal" @click="cancel">破棄</button>
            </div>
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';
import { onMounted, ref } from 'vue';
import { randomId } from '@/utils/number.js';

export default {
  name: 'PopupHolder',

  props: {
    type: {
      type: String,
      default: 'success',
    },
  },
  emits: ['submit', 'cancel'],
  setup(_, { emit }) {
    let myModal;
    let payload;
    let submitCallback;
    let cancelCallback;
    const generateUniqueKey = ref('');
    generateUniqueKey.value = randomId();

    const show = (data = {}) => {
      payload = data;
      submitCallback = data.submitCallback || (() => {});
      cancelCallback = data.cancelCallback || (() => {});

      myModal.show();
    };
    const hide = () => {
      myModal.hide();
    };
    const submit = () => {
      setTimeout(submitCallback, 300);
      emit('submit', payload);
    };
    const cancel = () => {
      setTimeout(cancelCallback, 300);
      emit('cancel', payload);
    };
    onMounted(() => {
      myModal = new Modal(document.getElementById(generateUniqueKey.value), {
        keyboard: false,
      });
    });

    return {
      //Methods
      hide,
      show,
      submit,
      cancel,
      generateUniqueKey,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.modal {
  .modal-dialog {
    max-width: 450px;
    .modal-content {
      border-radius: 1rem;
      padding: 2rem 2rem;
      .modal-header {
        display: flex;
        justify-content: center;
        align-items: center;
        border-bottom: none;
        .logo {
          width: 70px;
          height: 70px;
        }
      }
      .modal-body {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        border-bottom: none;
        p {
          margin: 0;
        }
        .text {
          text-align: center;
          font-weight: 400;
          font-size: 1rem;
          color: #172a6e;
        }
      }
      .modal-footer {
        border-top: none;
        display: flex;
        justify-content: center;
        align-items: center;
        .btn-cancel,
        .btn-delete {
          height: 40px;
          width: 140px;
          border: 1px solid #e5e5e5;
          border-radius: 8px;
          padding: 0.5rem;
          color: #172a6e;
          background-color: #fff;
          cursor: pointer;
          font-size: 1rem;
          font-weight: 500;
        }
        .btn-delete {
          margin-left: 1rem;
          color: #ec6868;
        }
        .button-success {
          width: 200px;
          padding: 0.5rem 0;
          border: none;
          background: #fff100;
          box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.16);
          border-radius: 8px;
          font-weight: 700;
          font-size: 1rem;
          text-align: center;
          color: #172a6e;
        }
      }
    }
  }
}
</style>
