<template>
  <!-- The Modal -->
  <div class="modal" id="forgot-password" ref="popupModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <!-- Modal body -->
        <div class="modal-body">We have sent you an email to reset your password.</div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" @click="hide">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap';
import { onMounted } from 'vue';
import { useRouter } from 'vue-router';

export default {
  setup() {
    const router = useRouter();
    let routerPath;
    let forgotPassword;

    const show = (path) => {
      routerPath = path;
      forgotPassword.show();
    };
    const hide = () => {
      forgotPassword.hide();
      router.push(routerPath);
    };

    onMounted(() => {
      forgotPassword = new Modal(document.getElementById('forgot-password'), {
        keyboard: false,
      });
    });

    return {
      //Methods
      show,
      hide,
    };
  },
};
</script>

<style lang="scss" scoped></style>
