import isEmpty from 'lodash/isEmpty';
import { isPresent, isBlank } from '@/utils/lang.js';

// Global
export default {
  name: 'object',
  methods: {
    isEmpty(obj) {
      return isEmpty(obj);
    },
    isPresent(obj) {
      return isPresent(obj);
    },
    isBlank(obj) {
      return isBlank(obj);
    },
  },
};
