import { createRouter, createWebHistory } from 'vue-router';
import isEmpty from 'lodash/isEmpty';
import store from '@/store';
import Home from '@/views/home/Home.vue';
import Login from '@/views/login/Login.vue';
import Register from '@/views/register/Register.vue';
import ForgotPassword from '@/views/forgot_password/ForgotPassword.vue';
import ResetPassword from '@/views/reset_password/ResetPassword.vue';

const routes = [
  {
    path: '/',
    redirect: { name: 'Home' },
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
  },
  {
    path: '/register',
    name: 'Register',
    component: Register,
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
  },
  {
    path: '/forgot-password',
    name: 'ForgotPassword',
    component: ForgotPassword,
  },
  {
    path: '/reset-password',
    name: 'ResetPassword',
    component: ResetPassword,
  },
  {
    path: '/:catchAll(.*)',
    redirect: { name: 'Home' },
  },
];

const router = createRouter({
  history: createWebHistory(import.meta.BASE_URL),
  routes,
});

router.beforeEach((to, from, next) => {
  const isAuthenticated = store.getters['auth/isSignedIn'] || null;
  const listRoutes = ['Login', 'Register', 'ForgotPassword', 'ResetPassword'];
  if (!listRoutes.includes(to.name) && !isAuthenticated) {
    next({ name: 'Login' });
  } else {
    next();
  }
});

export default router;
