<template>
  <div class="container-fluid register">
    <div class="row">
      <div class="col-md-3 register-left">
        <img src="@/assets/images/logo.png" alt="" />
        <h3>Welcome</h3>
        <p>Please enter information about the trip you want to book</p>
      </div>
      <div class="col-md-9 register-right">
        <h3 class="register-heading">Call Center</h3>
        <div class="row register-form">
          <div class="col-md-6">
            <!-- name -->
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="phone">Phone</label>
              <input
                class="form-control"
                :class="{ 'is-invalid': isPresent(errors.phone) }"
                type="text"
                id="phone"
                @blur="handleChangeForPhone"
                v-model="phone"
                autocomplete="off" />
              <div class="error">{{ errors.phone }}</div>
            </div>
            <!-- email
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="email">Email</label>
              <input
                class="form-control"
                :class="{ 'is-invalid': isPresent(errors.email) }"
                type="email"
                id="email"
                @blur="handleChangeForEmail"
                v-model="email"
                autocomplete="off" />
              <div class="error">{{ errors.email }}</div>
            </div> -->
            <!-- phone -->
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="name">Name</label>
              <input
                class="form-control"
                :class="{ 'is-invalid': isPresent(errors.name) }"
                type="text"
                id="name"
                @blur="handleChangeForName"
                v-model="name"
                autocomplete="off" />
              <div class="error">{{ errors.name }}</div>
            </div>
          </div>
          <div class="col-md-6">
            <!-- pickUp address -->
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="pickUpAddress">Where to pick</label>
              <input
                class="form-control"
                :class="{ 'is-invalid': isPresent(errors.pickUpAddress) }"
                type="text"
                id="pickUpAddress"
                @blur="handleChangeForPickUpAddress"
                v-model="pickUpAddress"
                autocomplete="off" />
              <div class="error">{{ errors.pickUpAddress }}</div>
            </div>
            <!-- dropOff address -->
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="dropOffAddress">Where to go</label>
              <input
                class="form-control"
                :class="{ 'is-invalid': isPresent(errors.dropOffAddress) }"
                type="text"
                id="dropOffAddress"
                @blur="handleChangeForDropOffAddress"
                v-model="dropOffAddress"
                autocomplete="off" />
              <div class="error">{{ errors.dropOffAddress }}</div>
              <button class="btnRegister" :class="{ disabled: isButtonDisabled }" @click="submit">Submit</button>
            </div>
            <!-- type of car
            <div class="d-flex flex-column justify-content-start align-items-start mb-3">
              <label class="label-text" for="typeOfCar">Type of Car</label>
              <ButtonDropdown
                class="dropdown-custom"
                :selected="selectedTypeOfCar"
                :options="listTypeOfCar"
                v-on:select="changeSelectedTypeOfCar" />
            </div> -->
          </div>
        </div>
      </div>
    </div>
    <PopupHolder type="error" class="error-popup" ref="errorPopup" data-bs-backdrop="static">
      <template v-slot:body>
        <p>Không tìm được tài xế ! Vui lòng thử lại sau!</p>
      </template>
      <template v-slot:footer>
        <button type="button" class="button-success" data-bs-dismiss="modal">OK</button>
      </template>
    </PopupHolder>
    <PopupHolder type="error" class="error-popup" ref="successPopup" data-bs-backdrop="static">
      <template v-slot:body>
        <p>Điều phối thành công!</p>
      </template>
      <template v-slot:footer>
        <button type="button" class="button-success" data-bs-dismiss="modal">OK</button>
      </template>
    </PopupHolder>
  </div>
</template>

<script>
import { useStore } from 'vuex';
import { computed, ref } from 'vue';
import { useForm, useField } from 'vee-validate';
import * as yup from 'yup';
import PopupHolder from '@/components/popups/default/PopupHolder.vue';
import ButtonDropdown from '@/components/form/ButtonDropdown.vue';
import { isPresent, isBlank } from '@/utils/lang.js';

export default {
  name: 'Home',
  components: {
    PopupHolder,
    ButtonDropdown,
  },
  setup() {
    const store = useStore();
    const errorPopup = ref(null);
    const successPopup = ref(null);

    const schema = yup.object({
      name: yup.string().required('Please enter your name'),
      phone: yup.string().required('Please enter your phone'),
      pickUpAddress: yup.string().required('Please enter your where to pick'),
      dropOffAddress: yup.string().required('Please enter your where to go'),
    });

    const { errors, setErrors } = useForm({
      validationSchema: schema,
    });

    const { value: name, handleChange: handleChangeForName } = useField('name');
    const { value: phone, handleChange: handleChangeForPhone } = useField('phone');
    const { value: pickUpAddress, handleChange: handleChangeForPickUpAddress } = useField('pickUpAddress');
    const { value: dropOffAddress, handleChange: handleChangeForDropOffAddress } = useField('dropOffAddress');

    // TODO return list car from server
    const listTypeOfCar = ref([
      { id: '1', name: '4 seats' },
      { id: '2', name: '7 seats' },
      { id: '3', name: 'Grab Bike' },
    ]);
    const selectedTypeOfCar = ref({ id: '1', name: '4 seats' });
    const changeSelectedTypeOfCar = (condition) => {
      selectedTypeOfCar.value = condition;
    };
    const isButtonDisabled = computed(() => {
      return (
        isPresent(errors.value) ||
        isBlank(name.value) ||
        isBlank(phone.value) ||
        isBlank(pickUpAddress.value) ||
        isBlank(dropOffAddress.value)
      );
    });

    const submit = () => {
      store.dispatch('loading/showLoading');
      let formData = {
        name: name.value,
        phone: phone.value,
        pickUpAddress: pickUpAddress.value,
        dropOffAddress: dropOffAddress.value,
        typeOfCar: selectedTypeOfCar.value.id,
      };
      store
        .dispatch('user/registerTrip', formData)
        .then((result) => {
          successPopup.value.show();
          store.dispatch('loading/hideLoading');
        })
        .catch((error) => {
          errorPopup.value.show();
          store.dispatch('loading/hideLoading');
        });
    };

    return {
      //Variables
      errors,
      name,
      phone,
      pickUpAddress,
      dropOffAddress,
      handleChangeForPhone,
      handleChangeForName,
      handleChangeForPickUpAddress,
      handleChangeForDropOffAddress,
      errorPopup,
      successPopup,
      listTypeOfCar,
      selectedTypeOfCar,

      //Computed
      isButtonDisabled,

      //Methods
      submit,
      changeSelectedTypeOfCar,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.dropdown-custom {
  height: 55px;
}
.label-text {
  font-weight: 700;
  font-size: 1rem;
  margin-bottom: 10px;
  color: #172a6e;
}
.form-control {
  border-radius: 8px;
  height: 55px;
  border: 1px solid #e5e5e5;
  margin-bottom: 0;
  color: #172a6e;
  &:focus {
    background: #eeeeee;
    outline: none !important;
    border: 2px solid #d2ad09;
    box-shadow: 0 0 0 #d2ad09;
  }
  &.is-invalid {
    background: #fdf0f0;
    outline: none !important;
    border: 2px solid #ec6868;
    box-shadow: 0 0 0 #ec6868;
  }
}
.error {
  margin-top: 10px;
  color: #e23146;
  font-size: 15px;
}

.error-popup {
  :deep(.modal-body) {
    p {
      margin-bottom: 10px;
      text-align: left;
    }
  }
  :deep(.modal-footer) {
    .button-success {
      @include btnSubmit;
      width: 150px;
      padding: 0.5rem 0;
    }
  }
}

.register {
  background: -webkit-linear-gradient(left, #3931af, #00c6ff);
  padding: 3%;
}
.register-left {
  text-align: center;
  color: #fff;
  margin-top: 4%;
}
.register-left input {
  border: none;
  border-radius: 1.5rem;
  padding: 2%;
  width: 60%;
  background: #f8f9fa;
  font-weight: bold;
  color: #383d41;
  margin-top: 30%;
  margin-bottom: 3%;
  cursor: pointer;
}
.register-right {
  background: #f8f9fa;
  border-top-left-radius: 10% 50%;
  border-bottom-left-radius: 10% 50%;
}
.register-left img {
  margin-top: 15%;
  margin-bottom: 5%;
  width: 25%;
  -webkit-animation: mover 2s infinite alternate;
  animation: mover 1s infinite alternate;
}
@-webkit-keyframes mover {
  0% {
    transform: translateY(0);
  }
  100% {
    transform: translateY(-20px);
  }
}
@keyframes mover {
  0% {
    transform: translateY(0);
  }
  100% {
    transform: translateY(-20px);
  }
}
.register-left p {
  font-weight: lighter;
  padding: 12%;
  margin-top: -9%;
}
.register .register-form {
  padding: 10%;
  margin-top: 10%;
}

.register-heading {
  border: none;
  text-align: center;
  margin-top: 8%;
  margin-bottom: -15%;
  color: #495057;
}
.btnRegister {
  float: right;
  margin-top: 10%;
  border: none;
  border-radius: 1.5rem;
  padding: 2%;
  background: #0062cc;
  color: #fff;
  font-weight: 600;
  width: 50%;
  cursor: pointer;
  &.disabled {
    pointer-events: none;
    opacity: 0.6;
  }
}
</style>
