<template>
  <div class="form-wrapper">
    <div class="form">
      <p class="main-text">Forgot Password</p>
      <label for="email">Email</label>
      <input
        class="form-control"
        :class="{ 'is-invalid': isPresent(errors.email) }"
        type="email"
        id="email"
        @blur="handleChangeForEmail"
        v-model="email"
        autocomplete="off" />
      <div class="error">{{ errors.email }}</div>
      <button class="forgot-btn" :class="{ disabled: isButtonDisabled }" @click="forgotPassword">SEND OTP</button>
    </div>
    <ShowInfoForgotPassword ref="showInfoForgotPassword" />
  </div>
</template>

<script>
import { computed, ref } from 'vue';
import { useStore } from 'vuex';
import { useForm, useField } from 'vee-validate';
import * as yup from 'yup';
import { isPresent, isBlank } from '@/utils/lang.js';
import ShowInfoForgotPassword from '@/components/popups/ShowInfoForgotPassword.vue';

export default {
  name: 'ForgotPassword',
  components: {
    ShowInfoForgotPassword,
  },
  setup() {
    const store = useStore();
    const showInfoForgotPassword = ref(null);
    const schema = yup.object({
      email: yup.string().required('Please enter your e-mail address').email('Please enter a valid email address'),
    });

    const { errors, setErrors, handleReset } = useForm({
      validationSchema: schema,
    });
    const { value: email, handleChange: handleChangeForEmail } = useField('email');
    const isButtonDisabled = computed(() => {
      return isPresent(errors.value) || isBlank(email.value);
    });

    const forgotPassword = () => {
      store.dispatch('loading/showLoading');
      let formData = {
        email: email.value,
        role: 'employee',
      };
      store
        .dispatch('user/forgotPassword', formData)
        .then(() => {
          showInfoForgotPassword.value.show({ name: 'ResetPassword' });
          store.dispatch('loading/hideLoading');
          handleReset();
        })
        .catch((error) => {
          setErrors({
            email: 'This e-mail address is not registered.',
          });
          store.dispatch('loading/hideLoading');
        });
    };

    return {
      //Variables
      errors,
      email,
      showInfoForgotPassword,
      handleChangeForEmail,

      //Computed
      isButtonDisabled,

      //Methods
      forgotPassword,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.form-wrapper {
  display: flex;
  height: 100vh;
  @include responsiveFrom(medium) {
    justify-content: center;
    align-items: center;
  }
  .form {
    background: #fff;
    border: 1px solid #e5e5e5;
    height: auto;
    width: 100%;
    padding: 50px 65px;
    @include responsiveFrom(medium) {
      width: 60%;
    }
    @include responsiveFrom(xlarge) {
      width: 45%;
    }
    .main-text {
      color: #172a6e;
      font-weight: bold;
      font-size: 1.2rem;
      margin-bottom: 1rem;
    }
    label {
      display: block;
      text-align: left;
      font-weight: 700;
      font-size: 0.875rem;
      margin-bottom: 10px;
      color: #172a6e;
    }
    .form-control {
      border-radius: 8px;
      height: 55px;
      border: 1px solid #e5e5e5;
      margin-bottom: 0;
      color: #172a6e;
      &:focus {
        outline: none !important;
        border: 2px solid #d2ad09;
        box-shadow: 0 0 0 #d2ad09;
      }
      &.is-invalid {
        background: #fdf0f0;
        outline: none !important;
        border: 2px solid #ec6868;
        box-shadow: 0 0 0 #ec6868;
      }
    }
    .error {
      margin-top: 10px;
      align-self: flex-end;
      color: #e23146;
      font-size: 15px;
    }
    .forgot-btn {
      margin-top: 1.5rem;
      @include btnSubmit;
      height: 50px;
      &:hover {
        border-style: solid;
        border-width: 2px;
        border-color: #d2ad09;
      }
      &.disabled {
        opacity: 0.6;
        &:hover {
          border-style: solid;
          border-width: 2px;
          border-color: #d2ad09;
        }
      }
    }
  }
}
</style>
