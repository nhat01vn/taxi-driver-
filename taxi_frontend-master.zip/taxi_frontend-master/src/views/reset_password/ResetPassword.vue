<template>
  <div class="form-wrapper">
    <div class="form">
      <div class="d-flex flex-column justify-content-start align-items-start">
        <label class="label-text" for="otp">OTP</label>
        <input
          class="form-control"
          :class="{ 'is-invalid': isPresent(errors.otp) }"
          type="text"
          id="otp"
          @blur="handleChangeForOtp"
          v-model="otp"
          autocomplete="off" />
        <div class="error">{{ errors.otp }}</div>
      </div>
      <div class="d-flex flex-column justify-content-start align-items-start">
        <label>New Password</label>
        <input
          class="form-control"
          :class="{ 'is-invalid': isPresent(errors.password) }"
          type="password"
          v-model="password"
          autocomplete="off" />
        <div class="error">{{ errors.password }}</div>
      </div>
      <div class="d-flex flex-column justify-content-start align-items-start">
        <label>Confirm password</label>
        <input
          class="form-control"
          :class="{ 'is-invalid': isPresent(errors.confirmationPassword) }"
          type="password"
          v-model="confirmationPassword"
          autocomplete="off" />
        <div class="error">{{ errors.confirmationPassword }}</div>
      </div>
      <button class="reset-button" :class="{ disabled: isButtonDisabled }" @click="resetPassword">UPDATE</button>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useStore } from 'vuex';
import { useForm, useField } from 'vee-validate';
import * as yup from 'yup';
import { isPresent, isBlank } from '@/utils/lang.js';

export default {
  name: 'ResetPasswordTie',

  setup() {
    const store = useStore();
    const router = useRouter();
    const route = useRoute();

    const schema = yup.object({
      otp: yup.string().required('Please enter your otp'),
      password: yup
        .string()
        .required('Please enter your password')
        .min(8, 'Please enter at least 8 characters')
        .max(20, 'Please enter 20 characters or less')
        .matches(/^[a-zA-Z0-9]+$/, 'Please enter alphanumeric characters'),
      confirmationPassword: yup
        .string()
        .required('Please enter your password')
        .min(8, 'Please enter at least 8 characters')
        .max(20, 'Please enter 20 characters or less')
        .matches(/^[a-zA-Z0-9]+$/, 'Please enter alphanumeric characters')
        .oneOf([yup.ref('password')], 'Passwords do not match'),
    });

    const { errors, setErrors } = useForm({
      validationSchema: schema,
    });

    const { value: confirmationPassword } = useField('confirmationPassword');
    const { value: password } = useField('password');
    const { value: otp } = useField('otp');

    const isButtonDisabled = computed(() => {
      return (
        isPresent(errors.value) ||
        confirmationPassword.value !== password.value ||
        isBlank(password.value) ||
        isBlank(otp.value)
      );
    });

    const resetPassword = () => {
      store.dispatch('loading/showLoading');
      let formData = {
        resetToken: otp.value,
        password: password.value,
        confirmationPassword: confirmationPassword.value,
        role: 'employee',
      };
      store
        .dispatch('user/resetPassword', formData)
        .then(() => {
          store.dispatch('loading/hideLoading');
          router.push({ name: 'Login' }).catch((error) => {
            if (error.name === 'NavigationDuplicated') {
              throw error;
            }
          });
        })
        .catch((error) => {
          if (error.error === 'invalid password') {
            setErrors({
              password: 'invalid password',
            });
          } else {
            setErrors({
              password: 'Reset failed. Please try again.',
            });
          }
          store.dispatch('loading/hideLoading');
        });
    };

    return {
      //Variables
      errors,
      confirmationPassword,
      password,
      otp,

      // computed
      isButtonDisabled,

      //Methods
      resetPassword,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.form-wrapper {
  display: flex;
  height: 100vh;
  @include responsiveFrom(medium) {
    justify-content: center;
    align-items: center;
  }
  .form {
    background: #fff;
    border: 1px solid #e5e5e5;
    height: auto;
    width: 100%;
    padding: 50px 65px;
    @include responsiveFrom(medium) {
      width: 60%;
    }
    @include responsiveFrom(xlarge) {
      width: 33%;
    }
    .logo {
      width: 70px;
      margin: 0px auto 20px auto;
      @include responsiveFrom(medium) {
        width: 90px;
      }
    }
    label {
      font-weight: 700;
      font-size: 1rem;
      margin-bottom: 10px;
      color: #172a6e;
    }
    .form-control {
      border-radius: 8px;
      height: 55px;
      border: 1px solid #e5e5e5;
      margin-bottom: 0;
      &:focus {
        outline: none !important;
        border: 2px solid #d2ad09;
        box-shadow: 0 0 0 #d2ad09;
      }
      &.is-invalid {
        background: #fdf0f0;
        outline: none !important;
        border: 2px solid #ec6868;
        box-shadow: 0 0 0 #ec6868;
      }
    }
    .error {
      margin-top: 10px;
      align-self: flex-end;
      color: #e23146;
      font-size: 15px;
    }
    .reset-button {
      margin-top: 1.5rem;
      @include btnSubmit;
      height: 50px;
      &:hover {
        border-style: solid;
        border-width: 2px;
        border-color: #d2ad09;
      }
      &.disabled {
        pointer-events: none;
        opacity: 0.6;
        &:hover {
          border-style: solid;
          border-width: 2px;
          border-color: #d2ad09;
        }
      }
    }
  }
}
</style>
