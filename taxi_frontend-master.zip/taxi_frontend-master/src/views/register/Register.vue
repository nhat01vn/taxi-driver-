<template>
  <div>
    <div class="form-wrapper">
      <div class="form">
        <div class="header">
          <p class="text">Create new Account</p>
        </div>
        <div class="d-flex flex-column justify-content-start align-items-start mb-3">
          <label class="label-text" for="name">Name</label>
          <input
            class="form-control"
            :class="{ 'is-invalid': isPresent(errors.name) }"
            type="text"
            id="name"
            @blur="handleChangeForName"
            v-model="name"
            autocomplete="off" />
        </div>
        <div class="d-flex flex-column justify-content-start align-items-start mb-3">
          <label class="label-text" for="name">Phone</label>
          <input
            class="form-control"
            :class="{ 'is-invalid': isPresent(errors.phone) }"
            type="text"
            id="phone"
            @blur="handleChangeForPhone"
            v-model="phone"
            autocomplete="off" />
        </div>
        <div class="d-flex flex-column justify-content-start align-items-start mb-3">
          <label class="label-text" for="email">Email</label>
          <input
            class="form-control"
            :class="{ 'is-invalid': isPresent(errors.email) }"
            type="email"
            id="email"
            @blur="handleChangeForEmail"
            v-model="email"
            autocomplete="off" />
          <div class="error">{{ errors.email }}</div>
        </div>
        <div class="d-flex flex-column justify-content-start align-items-start">
          <label class="label-text">Password</label>
          <div class="input-group" :class="{ 'is-invalid': isPresent(errors.password) }">
            <input
              class="form-control"
              :type="passwordFieldType"
              id="password"
              @blur="handleChangeForPassword"
              v-model="password"
              autocomplete="off" />
            <span class="input-group-text" @click="switchVisibilityPassword">
              <img src="@/assets/images/login/hint.svg" v-if="passwordFieldType === 'password'" />
              <img src="@/assets/images/login/un_hint.svg" v-else />
            </span>
          </div>
          <div class="error">{{ errors.password }}</div>
        </div>
        <button class="login-button" :class="{ disabled: isButtonDisabled }" @click="register">REGISTER</button>
        <div class="forgot-password">
          <router-link to="/login">or Login with your Account</router-link>
        </div>
      </div>
    </div>
    <PopupHolder type="error" class="error-popup" ref="errorPopup" data-bs-backdrop="static">
      <template v-slot:body>
        <p>It looks like your email address or phone is existed. Please type again</p>
        <p>Make sure Caps Lock is enabled and entered correctly.</p>
      </template>
      <template v-slot:footer>
        <button type="button" class="button-success" data-bs-dismiss="modal">OK</button>
      </template>
    </PopupHolder>
  </div>
</template>

<script>
import { computed, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import { useForm, useField } from 'vee-validate';
import * as yup from 'yup';
import PopupHolder from '@/components/popups/default/PopupHolder.vue';
import { isPresent, isBlank } from '@/utils/lang.js';

export default {
  name: 'Register',
  components: {
    PopupHolder,
  },
  setup() {
    const store = useStore();
    const router = useRouter();

    const errorPopup = ref(null);
    const passwordFieldType = ref('password');
    const schema = yup.object({
      name: yup.string().required('Please enter your name'),
      phone: yup.string().required('Please enter your phone'),
      email: yup.string().required('Please enter your e-mail address').email('Please enter a valid email address'),
      password: yup
        .string()
        .required('Please enter your password')
        .min(8, 'Please enter at least 8 characters')
        .max(20, 'Please enter 20 characters or less')
        .matches(/^[a-zA-Z0-9]+$/, 'Please enter alphanumeric characters'),
    });

    const { errors, setErrors } = useForm({
      validationSchema: schema,
    });

    const { value: name, handleChange: handleChangeForName } = useField('name');
    const { value: phone, handleChange: handleChangeForPhone } = useField('phone');
    const { value: email, handleChange: handleChangeForEmail } = useField('email');
    const { value: password, handleChange: handleChangeForPassword } = useField('password');

    const isButtonDisabled = computed(() => {
      return (
        isPresent(errors.value) ||
        isBlank(email.value) ||
        isBlank(password.value) ||
        isBlank(name.value) ||
        isBlank(phone.value)
      );
    });

    const switchVisibilityPassword = () => {
      passwordFieldType.value = passwordFieldType.value === 'password' ? 'text' : 'password';
    };

    const register = () => {
      store.dispatch('loading/showLoading');
      let formData = {
        name: name.value,
        phone: phone.value,
        email: email.value,
        password: password.value,
        role: 'employee',
      };
      store
        .dispatch('user/register', formData)
        .then(() => {
          store.dispatch('loading/hideLoading');
          router.push({ name: 'Login' });
        })
        .catch(() => {
          errorPopup.value.show();
          store.dispatch('loading/hideLoading');
        });
    };

    return {
      //Variables
      errors,
      name,
      phone,
      email,
      password,
      passwordFieldType,
      handleChangeForName,
      handleChangeForPhone,
      handleChangeForEmail,
      handleChangeForPassword,
      errorPopup,

      //Computed
      isButtonDisabled,

      //Methods
      register,
      switchVisibilityPassword,
    };
  },
};
</script>

<style lang="scss" scoped>
@import '@/assets/stylesheets/app.scss';

.form-wrapper {
  display: flex;
  height: 100vh;
  @include responsiveFrom(medium) {
    justify-content: center;
    align-items: center;
  }
  .form {
    background: #fff;
    border: 1px solid #e5e5e5;
    height: auto;
    width: 100%;
    max-width: 500px;
    padding: 40px 65px;
    @include responsiveFrom(medium) {
      width: 60%;
    }
    @include responsiveFrom(xlarge) {
      width: 33%;
    }
    .header {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      gap: 1rem;
      margin-bottom: 2rem;
      .text {
        font-family: 'Noto Sans JP';
        font-style: normal;
        font-weight: 700;
        font-size: 1.25rem;
        color: #172a6e;
      }
    }
    .label-text {
      font-weight: 700;
      font-size: 1rem;
      margin-bottom: 10px;
      color: #172a6e;
    }
    .form-control {
      border-radius: 8px;
      height: 55px;
      border: 1px solid #e5e5e5;
      margin-bottom: 0;
      color: #172a6e;
      &:focus {
        background: #eeeeee;
        outline: none !important;
        border: 2px solid #d2ad09;
        box-shadow: 0 0 0 #d2ad09;
      }
      &.is-invalid {
        background: #fdf0f0;
        outline: none !important;
        border: 2px solid #ec6868;
        box-shadow: 0 0 0 #ec6868;
      }
    }
    .input-group {
      border-radius: 8px;
      &:focus-within {
        outline: none !important;
        border: 2px solid #d2ad09;
        box-shadow: 0 0 0 #d2ad09;
        .input-group-text {
          background: #eeeeee;
          outline: none !important;
          border: none;
          box-shadow: 0 0 0 #d2ad09;
        }
      }
      &.is-invalid {
        background: #fff;
        outline: none !important;
        border: 2px solid #ec6868;
        box-shadow: 0 0 0 #ec6868;
        .form-control {
          background: #fdf0f0;
        }
        .input-group-text {
          background: #fdf0f0;
        }
      }
      .form-control {
        border-right: none;
        &:focus-within {
          outline: none !important;
          border: none;
          box-shadow: 0 0 0 #d2ad09;
        }
      }
      .input-group-text {
        background-color: #fff;
        border: 1px solid #e5e5e5;
        border-left: none;
        border-radius: 8px;
        &:hover {
          cursor: pointer;
        }
      }
    }
    .error {
      margin-top: 10px;
      align-self: center;
      color: #e23146;
      font-size: 15px;
    }
    .login-button {
      margin-top: 1.5rem;
      @include btnSubmit;
      height: 50px;
      &:hover {
        border-style: solid;
        border-width: 2px;
        border-color: #d2ad09;
      }
      &.disabled {
        pointer-events: none;
        opacity: 0.6;
        &:hover {
          border-style: solid;
          border-width: 2px;
          border-color: #d2ad09;
        }
      }
    }
    .forgot-password {
      margin-top: 1.6rem;
      text-align: center;
      color: #172a6e;
      font-size: 1rem;
      font-weight: 400;
      text-decoration: underline;
      line-height: 21px;
    }
  }
}
.error-popup {
  :deep(.modal-body) {
    p {
      margin-bottom: 10px;
      text-align: left;
    }
  }
  :deep(.modal-footer) {
    .button-success {
      @include btnSubmit;
      width: 150px;
      padding: 0.5rem 0;
    }
  }
}
</style>
