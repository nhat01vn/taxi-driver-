import { backendAPI } from '@/services/base_api';
import { loadLocalUser } from '@/services/localStorage';

export const login = (formData) => {
  return new Promise((resolve, reject) => {
    let userData = {
      email: formData.email,
      password: formData.password,
      role: formData.role,
    };

    return backendAPI('POST', 'auth/login', userData)
      .then((resp) => {
        const data = resp.status == 201 ? resp.data : {};
        resolve(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const auth = () => {
  return new Promise((resolve, reject) => {
    const userData = loadLocalUser();
    if (!userData || !userData.token) reject({});

    return backendAPI('GET', 'auth')
      .then((resp) => {
        const data = resp.status == 200 ? resp.data : {};
        resolve(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
