import store from '@/store/index.js';

const KEYS = {
  USER: 'localUser',
};

//  STORE LOCAL DATA
export const storeLocalUser = (user) => {
  return setItem(KEYS.USER, user);
};

// LOAD FROM LOCAL DATA
export const loadLocalUser = () => {
  return getItem(KEYS.USER);
};

//  CLEAR LOCAL DATA
export const clearLocalUser = () => {
  return removeItem(KEYS.USER);
};

// PRIVATE
const getItem = (key) => {
  try {
    let dataString = localStorage.getItem(key);

    return JSON.parse(dataString) || {};
  } catch {
    return {};
  }
};

const setItem = (key, data) => {
  localStorage.setItem(key, JSON.stringify(data));
};

const removeItem = (key) => {
  localStorage.removeItem(key);
};
