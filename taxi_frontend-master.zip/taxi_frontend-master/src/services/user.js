import { backendAPI } from '@/services/base_api';

export const forgotPassword = (formData) => {
  return backendAPI('POST', 'user/forgot-password', formData);
};

export const resetPassword = (formData) => {
  return backendAPI('POST', 'user/reset-password', formData);
};

export const register = (formData) => {
  return backendAPI('POST', 'user/employee', formData);
};

export const registerTrip = (formData) => {
  return backendAPI('POST', 'user/register-trip', formData);
};
