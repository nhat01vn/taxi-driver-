import axios from 'axios';
import store from '@/store';
import qs from 'qs';
import NProgress from 'nprogress';
import { isBlank } from '@/utils/lang.js';

axios.interceptors.request.use((config) => {
  NProgress.start();
  return config;
});

axios.interceptors.response.use(
  (response) => {
    NProgress.done();
    return response;
  },
  function (error) {
    NProgress.done();
    return Promise.reject(error);
  }
);

export const backendAPI = (method, path, data = {}, headers = {}, responseType = null) => {
  return new Promise((resolve, reject) => {
    requester(method, path, data, headers, responseType)
      .then((resp) => {
        if (resp.status === 200 || resp.status === 201) {
          resolve(resp);
        }
      })
      .catch((error) => {
        reject(axiosErrorParse(error));
      });
  });
};

export const axiosErrorParse = (error) => {
  return error.response.data;
};

// TODO: Remove this function after all backend API is ready
export const toastTodo = (apiName, data) => {
  return new Promise((resolve) => {
    store.dispatch('loading/showToastedTodo', apiName);
    setTimeout(() => {
      resolve({ data: data });
    }, 500);
  });
};

// PRIVATE
const requester = (method, path, data = {}, headers = {}, responseType = null) => {
  // Attach tokens to headers
  headers = attachBearToken(headers);

  const axiosDefaultSetting = defaultAxiosDefaultSetting(method, path, data, headers, responseType);

  return axios(axiosDefaultSetting);
};

const attachBearToken = (headers) => {
  const userData = store.getters['auth/currentUser'] || {};
  const userToken = userData.token;
  if (isBlank(userToken)) return headers;
  if (headers.attachUserToken === false) return headers;

  return {
    ...headers,
    'Api-Token': userToken,
  };
};

const defaultAxiosDefaultSetting = (method, path, data = {}, headers = {}, responseType = null) => {
  let axiosSetting = {
    method: method,
    url: import.meta.env.VITE_APP_BACKEND_END_POINT + path,
    withCredentials: false,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...headers,
    },
  };

  // Set request parameter or body
  if (method.toLowerCase() == 'get') {
    axiosSetting.params = data;
    axiosSetting.paramsSerializer = (params) => {
      return qs.stringify(params);
    };
  } else {
    axiosSetting.data = data;
  }

  if (responseType) {
    axiosSetting.responseType = responseType;
  }

  return axiosSetting;
};
