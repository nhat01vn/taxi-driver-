package com.thanhphan.driversapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
