import 'package:flutter/cupertino.dart';
import 'package:flutter_driver/src/presentation/screens/forgot_password/forgot_password_screen.dart';
import 'package:flutter_driver/src/presentation/screens/home/home_screen.dart';
import 'package:flutter_driver/src/presentation/screens/login/login_screen.dart';
import 'package:flutter_driver/src/presentation/screens/new_trip/new_trip_page.dart';
import 'package:flutter_driver/src/presentation/screens/register/register_screen.dart';
import 'package:flutter_driver/src/presentation/screens/reset_password/reset_password_screen.dart';
import 'package:flutter_driver/src/presentation/screens/splash/splash_screen.dart';
import 'package:go_router/go_router.dart';

class Routes {
  static final router = GoRouter(
    initialLocation: '/splash',
    routes: <GoRoute>[
      GoRoute(
        name: 'SplashScreen',
        path: '/splash',
        builder: (BuildContext context, GoRouterState state) {
          return const SplashScreen();
        },
      ),
      GoRoute(
        name: 'RegisterScreen',
        path: '/register',
        builder: (BuildContext context, GoRouterState state) {
          return const RegisterScreen();
        },
      ),
      GoRoute(
        name: 'LoginScreen',
        path: '/login',
        builder: (BuildContext context, GoRouterState state) {
          return const LoginScreen();
        },
      ),
      GoRoute(
        name: 'ForgotPasswordScreen',
        path: '/forgot-password',
        builder: (BuildContext context, GoRouterState state) {
          return const ForgotPasswordScreen();
        },
      ),
      GoRoute(
        name: 'ResetPasswordScreen',
        path: '/reset-password',
        builder: (BuildContext context, GoRouterState state) {
          return const ResetPasswordScreen();
        },
      ),
      GoRoute(
        name: 'HomeScreen',
        path: '/home',
        builder: (BuildContext context, GoRouterState state) {
          return HomeScreen(
            bottomNavSelected:
                _fetchParam(state, 'bottomNavSelected', defaultValue: 0),
          );
        },
      ),
      GoRoute(
        name: 'NewTripPage',
        path: '/new-trip',
        builder: (BuildContext context, GoRouterState state) {
          return NewTripPage(
            newTripDetailsInfo: _fetchParam(state, 'newTripDetailsInfo'),
          );
        },
      ),
    ],
  );

  static _fetchParam(GoRouterState state, String key, {dynamic defaultValue}) {
    final params = (state.extra ?? {}) as Map;
    if (params.containsKey(key)) return params[key];
    if (defaultValue != null) return defaultValue;

    // TODO: Handle exception required parameter (without default value). So I think:
    // 1. Redirect to Homepage and show popup error
    // 2. Cancel routing and show error
    return defaultValue;
  }
}
