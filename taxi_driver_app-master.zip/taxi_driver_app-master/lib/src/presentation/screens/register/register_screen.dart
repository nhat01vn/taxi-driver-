import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_driver/src/application/user_service.dart';
import 'package:flutter_driver/src/core/constants/app_asset.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/constants/app_size.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';
import 'package:flutter_driver/src/core/helpers/comon_helper.dart';
import 'package:flutter_driver/src/core/helpers/image_helper.dart';
import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/presentation/widgets/common/loading_dialog.dart';
import 'package:flutter_driver/src/presentation/widgets/common/rounded_button.dart';
import 'package:flutter_driver/src/presentation/widgets/form/form_text_field.dart';
import 'package:flutter_driver/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  bool _isPasswordVisible = false;
  CommonHelper cCommonHelperMethods = CommonHelper();
  XFile? imageFile;
  String urlOfUploadedImage = '';

  Future<String> uploadImageToStorage() async {
    String imageIDName = DateTime.now().millisecondsSinceEpoch.toString();
    Reference referenceImage =
        FirebaseStorage.instance.ref().child('Images').child(imageIDName);

    UploadTask uploadTask = referenceImage.putFile(File(imageFile!.path));
    TaskSnapshot snapshot = await uploadTask;
    urlOfUploadedImage = await snapshot.ref.getDownloadURL();
    return urlOfUploadedImage;
  }

  void submitForm() async {
    try {
      cCommonHelperMethods.checkConnectivity(context);
      if (imageFile == null) //image validation
      {
        cCommonHelperMethods.displaySnackBar(
          'Please choose image first.',
          context,
        );
      } else {
        if (_form.currentState!.saveAndValidate()) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) =>
                const LoadingDialog(messageText: 'Registering your account...'),
          );
          await uploadImageToStorage();
          var value = _form.currentState!.value;
          await ref.read(userServiceProvider).createUser(
                ICreateUserParams(
                  name: value['name'],
                  email: value['email'],
                  password: value['password'],
                  phone: value['phone'],
                  carModel: value['carModel'],
                  carNumber: value['carNumber'],
                  photo: urlOfUploadedImage,
                ),
              );
          if (!context.mounted) return;
          Navigator.pop(context);
          context.goNamed('LoginScreen');
        }
      }
    } catch (err) {
      if (mounted) {
        Navigator.pop(context);
        cCommonHelperMethods.displaySnackBar(
          (err as Map)['error'].toString(),
          context,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      safeAreaColor: AppColor.white,
      child: Container(
        color: AppColor.white,
        padding: const EdgeInsets.all(20),
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(
                height: 40,
              ),
              imageFile == null
                  ? const CircleAvatar(
                      radius: 86,
                      backgroundImage:
                          AssetImage('assets/images/avatarman.png'),
                    )
                  : Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.grey,
                        image: DecorationImage(
                          fit: BoxFit.fitHeight,
                          image: FileImage(
                            File(
                              imageFile!.path,
                            ),
                          ),
                        ),
                      ),
                    ),
              const SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  chooseImageFromGallery();
                },
                child: const Text(
                  'Choose Image',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: AppSize.formMarginBottom),
              FormBuilder(
                key: _form,
                child: Column(
                  children: [
                    FormTextField(
                      name: 'name',
                      placeholder: 'register.namePlaceholder'.tr(),
                      validator: FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'register.validationForName'.tr(),
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                    FormTextField(
                      name: 'phone',
                      placeholder: 'register.phonePlaceholder'.tr(),
                      validator: FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'register.validationForPhone'.tr(),
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                    FormTextField(
                      name: 'email',
                      placeholder: 'register.emailPlaceholder'.tr(),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: 'form.validation.empty'.tr(
                            namedArgs: {
                              'fieldName': 'register.validationForEmail'.tr(),
                            },
                          ),
                        ),
                        FormBuilderValidators.email(
                          errorText: 'form.validation.email'.tr(),
                        ),
                      ]),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                    FormTextField(
                      name: 'password',
                      obscureText: !_isPasswordVisible,
                      suffixIcon: Align(
                        widthFactor: 1.0,
                        heightFactor: 1.0,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isPasswordVisible = !_isPasswordVisible;
                            });
                          },
                          child: ImageHelper.loadFromAsset(
                            AppAsset.icoHintPassword,
                            tintColor: AppColor.defaultText,
                            height: 25,
                          ),
                        ),
                      ),
                      placeholder: 'register.passwordPlaceholder'.tr(),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: 'form.validation.empty'.tr(
                            namedArgs: {
                              'fieldName':
                                  'register.validationForPassword'.tr(),
                            },
                          ),
                        ),
                        FormBuilderValidators.minLength(
                          4,
                          errorText: 'form.validation.min'.tr(
                            namedArgs: {
                              'fieldName':
                                  'register.validationForPassword'.tr(),
                              'length': '4',
                            },
                          ),
                        ),
                        FormBuilderValidators.maxLength(
                          20,
                          errorText: 'form.validation.max'.tr(
                            namedArgs: {
                              'fieldName':
                                  'register.validationForPassword'.tr(),
                              'length': '20',
                            },
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                    FormTextField(
                      name: 'carModel',
                      placeholder: 'Car Model',
                      validator: FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'Car Model',
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                    FormTextField(
                      name: 'carNumber',
                      placeholder: 'Car Number',
                      validator: FormBuilderValidators.required(
                        errorText: 'form.validation.empty'.tr(
                          namedArgs: {
                            'fieldName': 'Car Number',
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.formMarginBottom),
                  ],
                ),
              ),
              const SizedBox(height: AppSize.formMarginBottom),
              RoundedButton(
                buttonText: 'register.buttonSubmit'.tr(),
                borderSize: const BorderSide(color: AppColor.success),
                onPressed: submitForm,
              ),
              const SizedBox(height: AppSize.formMarginBottom),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'register.formOr'.tr(),
                    textAlign: TextAlign.center,
                    style: TextStyles.defaultStyle.h6,
                  ),
                  GestureDetector(
                    onTap: () => {
                      context.goNamed(
                        'LoginScreen',
                      ),
                    },
                    child: Text(
                      'register.loginWitLink'.tr(),
                      textAlign: TextAlign.center,
                      style: TextStyles.defaultStyle.h6.primaryColor.fWBold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 120),
            ],
          ),
        ),
      ),
    );
  }

  chooseImageFromGallery() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        imageFile = pickedFile;
      });
    }
  }
}
