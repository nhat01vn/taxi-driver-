import 'package:flutter/material.dart';
import 'package:flutter_driver/src/application/user_service.dart';
import 'package:flutter_driver/src/core/constants/app_config.dart';
import 'package:flutter_driver/src/core/helpers/comon_helper.dart';
import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:restart_app/restart_app.dart';

class PaymentDialog extends ConsumerStatefulWidget {
  final String fareAmount;

  const PaymentDialog({
    super.key,
    required this.fareAmount,
  });

  @override
  ConsumerState<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends ConsumerState<PaymentDialog> {
  CommonHelper cMethods = CommonHelper();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCurrentDriver();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      backgroundColor: Colors.black54,
      child: Container(
        margin: const EdgeInsets.all(5.0),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.black87,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 21),
            const Text(
              'COLLECT CASH',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 21),
            const Divider(
              height: 1.5,
              color: Colors.white70,
              thickness: 1.0,
            ),
            const SizedBox(height: 16),
            Text(
              '\$${widget.fareAmount}',
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 36,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'This is fare amount ( \$ ${widget.fareAmount} ) to be charged from the user.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey),
              ),
            ),
            const SizedBox(height: 31),
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(context);
                Navigator.pop(context);

                cMethods.turnOnLocationUpdatesForHomePage(currentDriver!.uid);
                Geofire.removeLocation(currentDriver!.uid);
                await ref.read(userServiceProvider).updateUser(
                      IUpdateUserParams(
                        id: currentDriver!.id.toString(),
                        newTripStatus: '',
                        status: 'false',
                      ),
                    );
                Restart.restartApp(webOrigin: 'HomeScreen');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
              child: const Text('COLLECT CASH'),
            ),
            const SizedBox(height: 41),
          ],
        ),
      ),
    );
  }

  fetchCurrentDriver() async {
    final currentDriverResp = await ref.read(userServiceProvider).fetchUser(
          IFetchUserParams(uid: currentDriver!.uid.toString()),
        );

    setState(() {
      currentDriver = currentDriverResp;
    });
  }
}
