import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_driver/src/application/user_service.dart';
import 'package:flutter_driver/src/core/constants/app_config.dart';
import 'package:flutter_driver/src/core/helpers/comon_helper.dart';
import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/domain/direction_details_model.dart';
import 'package:flutter_driver/src/domain/trip_details.dart';
import 'package:flutter_driver/src/presentation/screens/new_trip/payment_dialog.dart';
import 'package:flutter_driver/src/presentation/widgets/common/loading_dialog.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class NewTripPage extends ConsumerStatefulWidget {
  final TripDetails? newTripDetailsInfo;

  const NewTripPage({
    super.key,
    this.newTripDetailsInfo,
  });

  @override
  ConsumerState<NewTripPage> createState() => _NewTripPageState();
}

class _NewTripPageState extends ConsumerState<NewTripPage> {
  final Completer<GoogleMapController> googleMapCompleterController =
      Completer<GoogleMapController>();
  bool isLoadingData = true;
  GoogleMapController? controllerGoogleMap;
  double googleMapPaddingFromBottom = 262;
  List<LatLng> coordinatesPolylineLatLngList = [];
  PolylinePoints polylinePoints = PolylinePoints();
  Set<Marker> markersSet = <Marker>{};
  Set<Circle> circlesSet = <Circle>{};
  Set<Polyline> polyLinesSet = <Polyline>{};
  BitmapDescriptor? carMarkerIcon;
  bool directionRequested = false;
  String statusOfTrip = 'accepted';
  String durationText = '', distanceText = '';
  String buttonTitleText = 'ARRIVED';
  Color buttonColor = Colors.indigoAccent;
  CommonHelper cMethods = CommonHelper();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    saveDriverDataToTripInfo();
  }

  @override
  Widget build(BuildContext context) {
    makeMarker();
    return Scaffold(
      body: isLoadingData
          ? const SizedBox.shrink()
          : Stack(
              children: [
                ///google map
                GoogleMap(
                  padding: EdgeInsets.only(bottom: googleMapPaddingFromBottom),
                  mapType: MapType.normal,
                  myLocationEnabled: true,
                  markers: markersSet,
                  circles: circlesSet,
                  polylines: polyLinesSet,
                  initialCameraPosition: googlePlexInitialPosition,
                  onMapCreated: (GoogleMapController mapController) async {
                    controllerGoogleMap = mapController;
                    googleMapCompleterController.complete(controllerGoogleMap);

                    var driverCurrentLocationLatLng = LatLng(
                      driverCurrentPosition!.latitude,
                      driverCurrentPosition!.longitude,
                    );

                    var userPickUpLocationLatLng =
                        widget.newTripDetailsInfo!.pickUpLatLng;

                    await obtainDirectionAndDrawRoute(
                      driverCurrentLocationLatLng,
                      userPickUpLocationLatLng,
                      location: 1,
                    );

                    getLiveLocationUpdatesOfDriver();
                  },
                ),

                ///trip details
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(17),
                        topLeft: Radius.circular(17),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 17,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7),
                        ),
                      ],
                    ),
                    height: 256,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 18,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //trip duration
                          Center(
                            child: Text(
                              '$durationText - $distanceText',
                              style: const TextStyle(
                                color: Colors.green,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(height: 5),
                          //user name - call user icon btn
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              //user name
                              Text(
                                widget.newTripDetailsInfo!.userName!,
                                style: const TextStyle(
                                  color: Colors.green,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              //call user icon btn
                              GestureDetector(
                                onTap: () {
                                  launchUrl(
                                    Uri.parse(
                                      'tel://${widget.newTripDetailsInfo!.userPhone.toString()}',
                                    ),
                                  );
                                },
                                child: const Padding(
                                  padding: EdgeInsets.only(right: 10),
                                  child: Icon(
                                    Icons.phone_android_outlined,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 15),
                          //pickup icon and location
                          Row(
                            children: [
                              Image.asset(
                                'assets/images/initial.png',
                                height: 16,
                                width: 16,
                              ),
                              Expanded(
                                child: Text(
                                  widget.newTripDetailsInfo!.pickupAddress
                                      .toString(),
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 15),
                          //drop-off icon and location
                          Row(
                            children: [
                              Image.asset(
                                'assets/images/final.png',
                                height: 16,
                                width: 16,
                              ),
                              Expanded(
                                child: Text(
                                  widget.newTripDetailsInfo!.dropOffAddress
                                      .toString(),
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 25),
                          Center(
                            child: ElevatedButton(
                              onPressed: () async {
                                //arrived button
                                if (statusOfTrip == 'accepted') {
                                  setState(() {
                                    buttonTitleText = 'START TRIP';
                                    buttonColor = Colors.green;
                                  });
                                  statusOfTrip = 'arrived';
                                  await FirebaseDatabase.instance
                                      .ref()
                                      .child('tripRequests')
                                      .child(widget.newTripDetailsInfo!.tripID!)
                                      .child('status')
                                      .set('arrived');
                                  if (mounted) {
                                    showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) =>
                                          const LoadingDialog(
                                        messageText: 'Please wait...',
                                      ),
                                    );
                                  }
                                  await obtainDirectionAndDrawRoute(
                                    widget.newTripDetailsInfo!.pickUpLatLng,
                                    widget.newTripDetailsInfo!.dropOffLatLng,
                                    location: 2,
                                  );
                                  if (mounted) Navigator.pop(context);
                                }
                                //start trip button
                                else if (statusOfTrip == 'arrived') {
                                  setState(() {
                                    buttonTitleText = 'END TRIP';
                                    buttonColor = Colors.amber;
                                  });
                                  statusOfTrip = 'ontrip';
                                  await FirebaseDatabase.instance
                                      .ref()
                                      .child('tripRequests')
                                      .child(widget.newTripDetailsInfo!.tripID!)
                                      .child('status')
                                      .set('ontrip');
                                }
                                //end trip button
                                else if (statusOfTrip == 'ontrip') {
                                  //end the trip
                                  endTripNow();
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: buttonColor,
                              ),
                              child: Text(
                                buttonTitleText,
                                style: const TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  makeMarker() {
    if (carMarkerIcon == null) {
      ImageConfiguration configuration =
          createLocalImageConfiguration(context, size: const Size(2, 2));

      BitmapDescriptor.fromAssetImage(
        configuration,
        'assets/images/tracking.png',
      ).then((valueIcon) {
        carMarkerIcon = valueIcon;
      });
    }
  }

  obtainDirectionAndDrawRoute(
    sourceLocationLatLng,
    destinationLocationLatLng, {
    int location = 1,
  }) async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const LoadingDialog(
        messageText: 'Please wait...',
      ),
    );

    var tripDetailsInfo = await CommonHelper.getDirectionDetailsFromAPI(
      sourceLocationLatLng,
      destinationLocationLatLng,
      test: location,
    );

    if (!mounted) return;
    Navigator.pop(context);

    PolylinePoints pointsPolyline = PolylinePoints();
    List<PointLatLng> latLngPoints =
        pointsPolyline.decodePolyline(tripDetailsInfo!.encodedPoints!);

    coordinatesPolylineLatLngList.clear();

    if (latLngPoints.isNotEmpty) {
      for (var pointLatLng in latLngPoints) {
        coordinatesPolylineLatLngList
            .add(LatLng(pointLatLng.latitude, pointLatLng.longitude));
      }
    }

    //draw polyline
    polyLinesSet.clear();

    Polyline polyline = Polyline(
      polylineId: const PolylineId('routeID'),
      color: Colors.amber,
      points: coordinatesPolylineLatLngList,
      jointType: JointType.round,
      width: 5,
      startCap: Cap.roundCap,
      endCap: Cap.roundCap,
      geodesic: true,
    );

    polyLinesSet.add(polyline);

    //fit the polyline on google map
    LatLngBounds boundsLatLng;

    if (sourceLocationLatLng.latitude > destinationLocationLatLng.latitude &&
        sourceLocationLatLng.longitude > destinationLocationLatLng.longitude) {
      boundsLatLng = LatLngBounds(
        southwest: destinationLocationLatLng,
        northeast: sourceLocationLatLng,
      );
    } else if (sourceLocationLatLng.longitude >
        destinationLocationLatLng.longitude) {
      boundsLatLng = LatLngBounds(
        southwest: LatLng(
          sourceLocationLatLng.latitude,
          destinationLocationLatLng.longitude,
        ),
        northeast: LatLng(
          destinationLocationLatLng.latitude,
          sourceLocationLatLng.longitude,
        ),
      );
    } else if (sourceLocationLatLng.latitude >
        destinationLocationLatLng.latitude) {
      boundsLatLng = LatLngBounds(
        southwest: LatLng(
          destinationLocationLatLng.latitude,
          sourceLocationLatLng.longitude,
        ),
        northeast: LatLng(
          sourceLocationLatLng.latitude,
          destinationLocationLatLng.longitude,
        ),
      );
    } else {
      boundsLatLng = LatLngBounds(
        southwest: sourceLocationLatLng,
        northeast: destinationLocationLatLng,
      );
    }

    controllerGoogleMap!
        .animateCamera(CameraUpdate.newLatLngBounds(boundsLatLng, 72));

    //add marker
    Marker sourceMarker = Marker(
      markerId: const MarkerId('sourceID'),
      position: sourceLocationLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
    );

    Marker destinationMarker = Marker(
      markerId: const MarkerId('destinationID'),
      position: destinationLocationLatLng,
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange),
    );

    markersSet.add(sourceMarker);
    markersSet.add(destinationMarker);

    //add circle
    Circle sourceCircle = Circle(
      circleId: const CircleId('sourceCircleID'),
      strokeColor: Colors.orange,
      strokeWidth: 4,
      radius: 14,
      center: sourceLocationLatLng,
      fillColor: Colors.green,
    );

    Circle destinationCircle = Circle(
      circleId: const CircleId('destinationCircleID'),
      strokeColor: Colors.green,
      strokeWidth: 4,
      radius: 14,
      center: destinationLocationLatLng,
      fillColor: Colors.orange,
    );

    setState(() {
      circlesSet.add(sourceCircle);
      circlesSet.add(destinationCircle);
      polyLinesSet;
      markersSet;
    });
  }

  getLiveLocationUpdatesOfDriver() {
    positionStreamNewTripPage =
        Geolocator.getPositionStream().listen((Position positionDriver) async {
      driverCurrentPosition = positionDriver;

      LatLng driverCurrentPositionLatLng = LatLng(
        driverCurrentPosition!.latitude,
        driverCurrentPosition!.longitude,
      );

      Marker carMarker = Marker(
        markerId: const MarkerId('carMarkerID'),
        position: driverCurrentPositionLatLng,
        icon: carMarkerIcon!,
        infoWindow: const InfoWindow(title: 'My Location'),
      );

      //update Trip Details Information
      if (!directionRequested) {
        directionRequested = true;
        if (driverCurrentPosition == null) return;

        var driverLocationLatLng = LatLng(
          driverCurrentPosition!.latitude,
          driverCurrentPosition!.longitude,
        );

        LatLng dropOffDestinationLocationLatLng;
        if (statusOfTrip == 'accepted') {
          dropOffDestinationLocationLatLng =
              widget.newTripDetailsInfo!.pickUpLatLng!;
        } else {
          dropOffDestinationLocationLatLng =
              widget.newTripDetailsInfo!.dropOffLatLng!;
        }
        // TODO for debug
        DirectionDetailsModel? directionDetailsInfo;
        if (dropOffDestinationLocationLatLng ==
            widget.newTripDetailsInfo!.dropOffLatLng!) {
          directionDetailsInfo = await CommonHelper.getDirectionDetailsFromAPI(
            driverLocationLatLng,
            dropOffDestinationLocationLatLng,
            test: 2,
          );
        } else {
          directionDetailsInfo = await CommonHelper.getDirectionDetailsFromAPI(
            driverLocationLatLng,
            dropOffDestinationLocationLatLng,
          );
        }
        // var directionDetailsInfo = await CommonHelper.getDirectionDetailsFromAPI(
        //   driverLocationLatLng,
        //   dropOffDestinationLocationLatLng,
        // );

        if (directionDetailsInfo != null) {
          directionRequested = false;

          setState(() {
            CameraPosition cameraPosition =
                CameraPosition(target: driverCurrentPositionLatLng, zoom: 16);
            controllerGoogleMap!
                .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

            markersSet.removeWhere(
              (element) => element.markerId.value == 'carMarkerID',
            );
            markersSet.add(carMarker);
            durationText = directionDetailsInfo!.durationTextString!;
            distanceText = directionDetailsInfo.distanceTextString!;
          });
        } else {
          setState(() {
            CameraPosition cameraPosition =
                CameraPosition(target: driverCurrentPositionLatLng, zoom: 16);
            controllerGoogleMap!
                .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

            markersSet.removeWhere(
              (element) => element.markerId.value == 'carMarkerID',
            );
            markersSet.add(carMarker);
          });
        }
      }

      //update driver location to tripRequest
      Map updatedLocationOfDriver = {
        'latitude': driverCurrentPosition!.latitude,
        'longitude': driverCurrentPosition!.longitude,
      };
      FirebaseDatabase.instance
          .ref()
          .child('tripRequests')
          .child(widget.newTripDetailsInfo!.tripID!)
          .child('driverLocation')
          .set(updatedLocationOfDriver);
    });
  }

  endTripNow() async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const LoadingDialog(
        messageText: 'Please wait...',
      ),
    );

    var driverCurrentLocationLatLng = LatLng(
      driverCurrentPosition!.latitude,
      driverCurrentPosition!.longitude,
    );

    var directionDetailsEndTripInfo =
        await CommonHelper.getDirectionDetailsFromAPI(
      widget.newTripDetailsInfo!.pickUpLatLng!, //pickup
      driverCurrentLocationLatLng, //destination
      test: 2,
    );

    if (!mounted) return;
    Navigator.pop(context);

    String fareAmount =
        (cMethods.calculateFareAmount(directionDetailsEndTripInfo!)).toString();

    await FirebaseDatabase.instance
        .ref()
        .child('tripRequests')
        .child(widget.newTripDetailsInfo!.tripID!)
        .child('fareAmount')
        .set(fareAmount);

    await FirebaseDatabase.instance
        .ref()
        .child('tripRequests')
        .child(widget.newTripDetailsInfo!.tripID!)
        .child('status')
        .set('ended');

    positionStreamNewTripPage!.cancel();

    //dialog for collecting fare amount
    displayPaymentDialog(fareAmount);

    //save fare amount to driver total earnings
    saveFareAmountToDriverTotalEarnings(fareAmount);
  }

  displayPaymentDialog(fareAmount) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => PaymentDialog(fareAmount: fareAmount),
    );
  }

  saveFareAmountToDriverTotalEarnings(String fareAmount) async {
    double totalEarnings = 0;
    if (currentDriver!.earnings > 0) {
      double previousTotalEarnings = currentDriver!.earnings;
      double fareAmountForTrip = double.parse(fareAmount);
      totalEarnings = previousTotalEarnings + fareAmountForTrip;
    } else {
      totalEarnings = double.parse(fareAmount);
    }
    await ref.read(userServiceProvider).updateUser(
          IUpdateUserParams(
            id: currentDriver!.id.toString(),
            earnings: totalEarnings,
          ),
        );
  }

  saveDriverDataToTripInfo() async {
    Map<String, dynamic> driverDataMap = {
      'status': 'accepted',
      'driverID': currentDriver?.uid,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'driverPhoto': driverPhoto,
      'carDetails': '$carModel - $carNumber',
    };

    Map<String, dynamic> driverCurrentLocation = {
      'latitude': driverCurrentPosition!.latitude.toString(),
      'longitude': driverCurrentPosition!.longitude.toString(),
    };

    await FirebaseDatabase.instance
        .ref()
        .child('tripRequests')
        .child(widget.newTripDetailsInfo!.tripID!)
        .update(driverDataMap);

    await FirebaseDatabase.instance
        .ref()
        .child('tripRequests')
        .child(widget.newTripDetailsInfo!.tripID!)
        .child('driverLocation')
        .update(driverCurrentLocation);

    setState(() {
      isLoadingData = false;
      googleMapPaddingFromBottom = 262;
    });
  }
}
