import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_asset.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/constants/app_config.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';
import 'package:flutter_driver/src/core/helpers/image_helper.dart';
import 'package:flutter_driver/src/core/utilities/local_storage.dart';
import 'package:flutter_driver/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:go_router/go_router.dart';

class AccountBottomNav extends StatefulWidget {
  const AccountBottomNav({Key? key}) : super(key: key);

  @override
  State<AccountBottomNav> createState() => _AccountBottomNavState();
}

class _AccountBottomNavState extends State<AccountBottomNav> {
  @override
  Widget build(BuildContext context) {
    return AppContainer(
      appBar: AppBar(
        backgroundColor: AppColor.primary,
        shadowColor: AppColor.transparent,
        title: const Text('Account'),
        titleTextStyle: TextStyles.defaultAppBarTitle,
      ),
      child: Column(
        children: [
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
            margin: const EdgeInsets.only(bottom: 1),
            child: Center(
              child: driverPhoto != ''
                  ? Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.grey,
                        image: DecorationImage(
                          fit: BoxFit.fitHeight,
                          image: NetworkImage(
                            driverPhoto,
                          ),
                        ),
                      ),
                    )
                  : Container(
                      width: 180,
                      height: 180,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.grey,
                      ),
                    ),
            ),
          ),
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
            margin: const EdgeInsets.only(bottom: 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.person,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Name',
                      style: TextStyles.defaultStyle.h6,
                    ),
                  ],
                ),
                Text(
                  driverName,
                  style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                ),
              ],
            ),
          ),
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
            margin: const EdgeInsets.only(bottom: 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.phone_android_outlined,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Phone',
                      style: TextStyles.defaultStyle.h6,
                    ),
                  ],
                ),
                Text(
                  driverPhone,
                  style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                ),
              ],
            ),
          ),
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
            margin: const EdgeInsets.only(bottom: 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.email,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Email',
                      style: TextStyles.defaultStyle.h6,
                    ),
                  ],
                ),
                Text(
                  currentDriver!.email.toString(),
                  style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                ),
              ],
            ),
          ),
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
            margin: const EdgeInsets.only(bottom: 1),
            child: GestureDetector(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.drive_eta_outlined,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'Car',
                        style: TextStyles.defaultStyle.h6,
                      ),
                    ],
                  ),
                  Text(
                    '$carNumber - $carModel',
                    style: TextStyles.defaultStyle.primaryColor.fWBold.h6,
                  ),
                ],
              ),
            ),
          ),
          Container(
            color: AppColor.white,
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 18),
            margin: const EdgeInsets.only(bottom: 1),
            child: GestureDetector(
              onTap: _logout,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.logout,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'Logout',
                        style: TextStyles.defaultStyle.fWNormal.h6,
                      ),
                    ],
                  ),
                  ImageHelper.loadFromAsset(
                    AppAsset.icoArrowRight,
                    tintColor: AppColor.primary,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _logout() async {
    await localStorage.clearUserToken();
    if (mounted) context.goNamed('LoginScreen');
  }
}
