import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/constants/app_config.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';
import 'package:flutter_driver/src/presentation/screens/trips_history/trips_history_page.dart';
import 'package:flutter_driver/src/presentation/widgets/layouts/app_container/app_container.dart';

class TripsBottomNav extends StatefulWidget {
  const TripsBottomNav({Key? key}) : super(key: key);

  @override
  State<TripsBottomNav> createState() => _TripsBottomNavState();
}

class _TripsBottomNavState extends State<TripsBottomNav> {
  String currentDriverTotalTripsCompleted = '';
  bool isLoading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentDriverTotalNumberOfTripsCompleted();
  }

  getCurrentDriverTotalNumberOfTripsCompleted() async {
    DatabaseReference tripRequestsRef =
        FirebaseDatabase.instance.ref().child('tripRequests');

    await tripRequestsRef.once().then((snap) async {
      if (snap.snapshot.value != null) {
        Map<dynamic, dynamic> allTripsMap = snap.snapshot.value as Map;
        List<String> tripsCompletedByCurrentDriver = [];
        allTripsMap.forEach((key, value) {
          if (value['status'] != null &&
              value['status'] == 'ended' &&
              value['driverID'] == currentDriver?.uid) {
            tripsCompletedByCurrentDriver.add(key);
          }
        });
        setState(() {
          isLoading = false;
          currentDriverTotalTripsCompleted =
              tripsCompletedByCurrentDriver.length.toString();
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : AppContainer(
            appBar: AppBar(
              backgroundColor: AppColor.primary,
              shadowColor: AppColor.transparent,
              title: const Text('Trips History'),
              titleTextStyle: TextStyles.defaultAppBarTitle,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                //Total Trips
                Center(
                  child: Container(
                    color: Colors.indigo,
                    width: 300,
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Column(
                        children: [
                          Image.asset(
                            'assets/images/totaltrips.png',
                            width: 120,
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Total Trips:',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            currentDriverTotalTripsCompleted,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                //check trip history
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (c) => const TripsHistoryPage(),
                      ),
                    );
                  },
                  child: Center(
                    child: Container(
                      color: Colors.indigo,
                      width: 300,
                      child: Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/images/tripscompleted.png',
                              width: 150,
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              'Check Trips History',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
  }
}
