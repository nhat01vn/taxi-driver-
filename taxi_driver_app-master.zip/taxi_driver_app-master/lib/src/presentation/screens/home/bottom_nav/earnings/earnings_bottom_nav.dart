import 'package:flutter/material.dart';
import 'package:flutter_driver/src/application/user_service.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/constants/app_config.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';
import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/core/utilities/local_storage.dart';
import 'package:flutter_driver/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class EarningsBottomNav extends ConsumerStatefulWidget {
  const EarningsBottomNav({super.key});

  @override
  ConsumerState<EarningsBottomNav> createState() => _EarningsBottomNavState();
}

class _EarningsBottomNavState extends ConsumerState<EarningsBottomNav> {
  String driverEarnings = '';
  bool isLoading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getTotalEarningsOfCurrentDriver();
  }

  getTotalEarningsOfCurrentDriver() async {
    final userToken = await localStorage.loadUserToken();

    final currentDriverResp = await ref.read(userServiceProvider).fetchUser(
          IFetchUserParams(uid: userToken.uid.toString()),
        );

    setState(() {
      currentDriver = currentDriverResp;
      driverEarnings = currentDriver!.earnings.toString();
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : AppContainer(
            appBar: AppBar(
              backgroundColor: AppColor.primary,
              shadowColor: AppColor.transparent,
              title: const Text('Earnings'),
              titleTextStyle: TextStyles.defaultAppBarTitle,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Container(
                    color: Colors.indigo,
                    width: 300,
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Column(
                        children: [
                          Image.asset(
                            'assets/images/totalearnings.png',
                            width: 120,
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Total Earnings:',
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            '\$ $driverEarnings',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
  }
}
