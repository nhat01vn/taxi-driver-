import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';

class FormInputGroup extends StatelessWidget {
  const FormInputGroup({
    super.key,
    required this.controller,
    this.prefixIcon,
    this.suffixIcon,
    this.placeholder = '',
  });

  final TextEditingController controller;
  final String placeholder;
  final Widget? prefixIcon;
  final Widget? suffixIcon;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      style: TextStyles.defaultStyle,
      decoration: InputDecoration(
        contentPadding: const EdgeInsets.all(15),
        filled: true,
        fillColor: AppColor.white,
        prefixIcon: Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 5),
          child: prefixIcon,
        ),
        prefixIconConstraints:
            const BoxConstraints(minHeight: 10, maxHeight: 40),
        suffixIcon: Padding(
          padding: const EdgeInsets.only(left: 5, right: 15.0),
          child: suffixIcon,
        ),
        suffixIconConstraints:
            const BoxConstraints(minHeight: 10, maxHeight: 40),
        hintText: placeholder,
        hintStyle: TextStyle(
          color: AppColor.defaultText.withOpacity(0.5),
        ),
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(8.0)),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
