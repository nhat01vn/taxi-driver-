import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';

// ignore: must_be_immutable
class RoundedButton extends StatelessWidget {
  RoundedButton({
    Key? key,
    required this.buttonText,
    this.fontSize = 16,
    this.textColor = AppColor.white,
    this.backgroundColor = AppColor.success,
    this.circularBorderRadius = const BorderRadius.all(Radius.circular(50)),
    this.padding = const EdgeInsets.all(15.0),
    this.disabledColor,
    this.borderSize = const BorderSide(),
    this.fontWeight = FontWeight.normal,
    required this.onPressed,
  }) : super(key: key);

  final String? buttonText;
  final double? fontSize;
  final Color? textColor;
  final Color? backgroundColor;
  final Color? disabledColor;
  final BorderRadiusGeometry circularBorderRadius;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onPressed;
  final BorderSide borderSize;
  final FontWeight? fontWeight;

  bool _isButtonDisabled = false;

  void triggerEvent(VoidCallback triggerFunction) {
    triggerFunction();

    _isButtonDisabled = true;
    Future.delayed(const Duration(seconds: 2), () {
      _isButtonDisabled = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      padding: padding,
      onPressed: onPressed != null
          ? () =>
              _isButtonDisabled ? null : triggerEvent(onPressed ?? (() => {}))
          : null,
      color: backgroundColor,
      disabledColor: disabledColor,
      shape: RoundedRectangleBorder(
        borderRadius: circularBorderRadius,
        side: borderSize,
      ),
      child: Center(
        child: Text(
          buttonText!,
          style: TextStyle(
            fontWeight: fontWeight,
            color: textColor,
            fontSize: fontSize,
          ),
        ),
      ),
    );
  }
}
