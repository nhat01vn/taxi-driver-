import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';

class FormTextField extends StatelessWidget {
  FormTextField({
    Key? key,
    required this.name,
    this.initialValue,
    this.controller,
    this.maxLines = 1,
    this.obscureText = false,
    required this.placeholder,
    this.suffixIcon,
    this.contentPadding = const EdgeInsets.only(
      left: 0.0,
      right: 15.0,
      bottom: 15.0,
      top: 15.0,
    ),
    this.placeHolderStyle = const TextStyle(
      color: AppColor.gray500,
    ),
    this.backgroundColor = AppColor.gray100,
    this.border = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide.none,
    ),
    this.enabledBorder = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide(width: 1, color: AppColor.gray200),
    ),
    this.validator,
    this.keyboardType,
    this.inputFormatters,
    this.onChanged,
    this.errors,
  }) : super(key: key);

  final bool obscureText;
  final String name;
  final String? initialValue;
  final TextEditingController? controller;
  final int? maxLines;
  final String placeholder;
  final Color? backgroundColor;
  final EdgeInsetsGeometry? contentPadding;
  final Widget? suffixIcon;
  final TextStyle? placeHolderStyle;
  final InputBorder? border;
  final InputBorder? enabledBorder;
  final String? Function(String?)? validator;
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final Function(String? value)? onChanged;
  final String? errors;

  @override
  Widget build(BuildContext context) {
    return FormBuilderTextField(
      name: name,
      initialValue: initialValue,
      maxLines: maxLines,
      obscureText: obscureText,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      decoration: InputDecoration(
        contentPadding: contentPadding,
        prefix: const Padding(padding: EdgeInsets.only(left: 15.0)),
        suffixIcon: suffixIcon,
        filled: true,
        fillColor: backgroundColor,
        hintText: placeholder,
        hintStyle: placeHolderStyle,
        border: border,
        enabledBorder: enabledBorder,
        errorText: errors,
      ),
      onChanged: (value) {
        if (onChanged != null) {
          onChanged!(value);
        }

        _form.currentState != null
            ? _form.currentState?.fields[name]?.validate()
            : null; // Trigger validation on change
      },
      validator: validator,
    );
  }
}
