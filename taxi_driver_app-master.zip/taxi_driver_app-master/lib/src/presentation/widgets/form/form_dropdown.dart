import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';

class FormDropdown<T> extends StatelessWidget {
  const FormDropdown({
    Key? key,
    required this.name,
    this.initialValue,
    this.icon,
    this.contentPadding = const EdgeInsets.only(
      left: 0.0,
      right: 15.0,
      bottom: 15.0,
      top: 15.0,
    ),
    this.fillColor = AppColor.white,
    this.border = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide.none,
    ),
    this.enabledBorder = const OutlineInputBorder(
      borderRadius: BorderRadius.all(Radius.circular(10.0)),
      borderSide: BorderSide(width: 1, color: AppColor.gray200),
    ),
    this.onChanged,
    required this.items,
    this.validator,
  }) : super(key: key);

  final String name;
  final T? initialValue;
  final Widget? icon;
  final EdgeInsetsGeometry? contentPadding;
  final Color? fillColor;
  final InputBorder? border;
  final InputBorder? enabledBorder;
  final String? Function(T?)? validator;
  final void Function(T?)? onChanged;
  final List<DropdownMenuItem<T>> items;

  @override
  Widget build(BuildContext context) {
    return FormBuilderDropdown<T>(
      name: name,
      initialValue: _selectedValue(),
      icon: icon,
      decoration: InputDecoration(
        contentPadding: contentPadding,
        prefix: const Padding(padding: EdgeInsets.only(left: 15.0)),
        filled: true,
        fillColor: fillColor,
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(5.0)),
          borderSide: BorderSide(color: AppColor.gray200),
        ),
        border: border,
        enabledBorder: enabledBorder,
      ),
      onChanged: onChanged,
      items: items,
      validator: validator,
    );
  }

  _selectedValue() {
    return initialValue ?? items.first.value;
  }
}
