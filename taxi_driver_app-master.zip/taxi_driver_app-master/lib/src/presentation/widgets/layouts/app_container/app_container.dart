import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/constants/app_size.dart';
import 'package:flutter_driver/src/core/utilities/app_config.dart';

class AppContainer extends StatelessWidget {
  const AppContainer({
    super.key,
    this.safeAreaColor = AppColor.primary,
    this.appBar,
    required this.child,
    this.bottomBannerBar,
    this.bottomNavigationBar,
    this.padding,
    this.floatingActionButton,
    this.floatingActionButtonLocation,
  });

  final Color safeAreaColor;
  final Widget child;
  final AppBar? appBar;
  final EdgeInsets? padding;
  final Widget? bottomBannerBar;
  final BottomAppBar? bottomNavigationBar;
  final Widget? floatingActionButton;
  final FloatingActionButtonLocation? floatingActionButtonLocation;

  @override
  Widget build(BuildContext context) {
    AppConfig.showStatusBar();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBody: true,
      backgroundColor: AppColor.mainBackground,
      appBar: appBar,
      body: Container(
        color: safeAreaColor,
        child: SafeArea(
          bottom: false,
          child: Container(
            color: AppColor.mainBackground,
            child: Stack(
              children: [
                Container(
                  padding: padding,
                  child: child,
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  width: AppSize.fullWidth,
                  child: bottomBannerBar ?? const SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: floatingActionButton,
      floatingActionButtonLocation: floatingActionButtonLocation,
      bottomNavigationBar: bottomNavigationBar,
    );
  }
}
