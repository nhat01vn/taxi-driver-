import 'package:flutter/material.dart';
import 'package:flutter_driver/src/core/constants/app_color.dart';
import 'package:flutter_driver/src/core/extensions/textstyle_ext.dart';
import 'package:flutter_driver/src/core/helpers/image_helper.dart';

class BottomAppBarItem extends StatelessWidget {
  const BottomAppBarItem({
    super.key,
    required this.navKey,
    required this.asset,
    required this.label,
    required this.onBottomNavSelected,
    this.currentBottomNavSelected = 0,
    this.assetHeight = 25,
  });

  final int navKey;
  final String asset;
  final double assetHeight;
  final String label;
  final int currentBottomNavSelected;
  final Function(int navKey) onBottomNavSelected;

  @override
  Widget build(BuildContext context) {
    Color color = currentBottomNavSelected == navKey
        ? AppColor.primary
        : AppColor.defaultText;

    return Expanded(
      child: SizedBox.fromSize(
        size: const Size(50, 50),
        child: Material(
          color: AppColor.white,
          child: InkWell(
            focusColor: AppColor.white,
            hoverColor: AppColor.white,
            highlightColor: AppColor.white,
            splashColor: AppColor.white,
            onTap: () {
              onBottomNavSelected(navKey);
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                ImageHelper.loadFromAsset(
                  asset,
                  tintColor: color,
                  height: assetHeight,
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  label,
                  style: TextStyle(color: color).fWBold.h9,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
