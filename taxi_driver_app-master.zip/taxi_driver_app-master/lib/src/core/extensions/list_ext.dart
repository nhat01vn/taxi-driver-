extension ExtendedList<T> on List<T> {
  List differentFrom(List anotherList) {
    final ownSet = Set.from(this);
    final anotherSet = Set.from(anotherList);
    return List<T>.from(ownSet.difference(anotherSet));
  }
}
