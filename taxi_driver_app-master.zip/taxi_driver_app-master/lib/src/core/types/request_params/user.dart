import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.freezed.dart';

@freezed
class ICreateUserParams with _$ICreateUserParams {
  factory ICreateUserParams({
    required String name,
    required String email,
    required String phone,
    required String password,
    required String carNumber,
    required String carModel,
    required String photo,
  }) = _ICreateUserParams;
}

@freezed
class IForgotPasswordParams with _$IForgotPasswordParams {
  factory IForgotPasswordParams({required String email}) =
      _IForgotPasswordParams;
}

@freezed
class IResetPasswordParams with _$IResetPasswordParams {
  factory IResetPasswordParams({
    required String resetToken,
    required String password,
    required String passwordConfirmation,
  }) = _IResetPasswordParams;
}

@freezed
class IFetchUserParams with _$IFetchUserParams {
  factory IFetchUserParams({
    required String uid,
  }) = _IFetchUserParams;
}

@freezed
class IUpdateUserParams with _$IUpdateUserParams {
  factory IUpdateUserParams({
    required String id,
    String? newTripStatus,
    double? lat,
    double? long,
    double? earnings,
    String? deviceToken,
    String? status,
  }) = _IUpdateUserParams;
}

@freezed
class IUpdatePasswordParams with _$IUpdatePasswordParams {
  factory IUpdatePasswordParams({
    required String currentPassword,
    required String password,
    required String passwordConfirmation,
  }) = _IUpdatePasswordParams;
}

@freezed
class IUpdateInfoParams with _$IUpdateInfoParams {
  factory IUpdateInfoParams({required String fullName}) = _IUpdateInfoParams;
}

@freezed
class IFetchUsersParams with _$IFetchUsersParams {
  factory IFetchUsersParams({
    String? exceptWalletId,
    String? keyword,
    int? page,
    int? perPage,
  }) = _IFetchUsersParams;
}
