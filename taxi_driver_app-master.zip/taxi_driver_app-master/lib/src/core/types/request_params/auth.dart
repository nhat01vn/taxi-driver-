import 'package:freezed_annotation/freezed_annotation.dart';

part 'auth.freezed.dart';

@freezed
class ILoginParams with _$ILoginParams {
  factory ILoginParams({
    required String email,
    required String password,
  }) = _ILoginParams;
}
