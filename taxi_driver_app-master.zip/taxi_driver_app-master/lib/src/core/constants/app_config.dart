import 'dart:async';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:flutter_driver/src/domain/user.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

String userName = '';

String googleMapKey = 'AIzaSyBX4Lgs9JjEONsbApnU6Xy3bA-_6vTyQoI';

const CameraPosition googlePlexInitialPosition = CameraPosition(
  target: LatLng(10.76295706120165, 106.68246310611696),
  zoom: 14.4746,
);

StreamSubscription<Position>? positionStreamHomePage;
StreamSubscription<Position>? positionStreamNewTripPage;

int driverTripRequestTimeout = 20;

final audioPlayer = AssetsAudioPlayer();

User? currentDriver;
Position? driverCurrentPosition;

String driverName = '';
String driverPhone = '';
String driverPhoto = '';
String carColor = '';
String carModel = '';
String carNumber = '';
