import 'package:flutter/material.dart';

class AppColor {
  static const Color transparent = Colors.transparent;
  static const Color white = Color(0xffffffff);
  static const Color gray100 = Color(0xfff8f9fa);
  static const Color gray200 = Color(0xffE7E7E7);
  static const Color gray300 = Color(0xffc8c8c8);
  static const Color gray400 = Color(0xffced4da);
  static const Color gray500 = Color(0xffadb5bd);
  static const Color gray600 = Color(0xff737274);
  static const Color gray700 = Color(0xff495057);
  static const Color gray800 = Color(0xff3E3E3E);
  static const Color gray900 = Color(0xff232323);

  static const Color black = Color(0xff0f0f0f);
  static const Color blue = Color(0xff137DDF);
  static const Color indigo = Color(0xff6610f2);
  static const Color purple = Color(0xff6f42c1);
  static const Color pink = Color(0xffd63384);
  static const Color red = Color(0xffDC3535);
  static const Color orange = Color(0xfffd7e14);
  static const Color yellow = Color(0xffffc107);
  static const Color lightGreen = Color(0xff7BC293);
  static const Color green = Color(0xff5DB075);
  static const Color teal = Color(0xff20c997);
  static const Color cyan = Color(0xff0dcaf0);

  static const primary = lightGreen;
  static const secondary = blue;
  static const success = green;
  static const info = cyan;
  static const warning = yellow;
  static const danger = red;

  static const defaultText = gray600;
  static const mainBackground = gray200;
}
