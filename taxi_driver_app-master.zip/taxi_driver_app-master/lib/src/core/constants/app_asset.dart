class AppAsset {
  //Assets in icons
  static String icoHistory = 'assets/icons/history.svg';
  static String icoHome = 'assets/icons/home.svg';
  static String icoAccount = 'assets/icons/account.svg';
  static String icoSettings = 'assets/icons/settings.svg';
  static String icoHintPassword = 'assets/icons/hint_password.svg';
  static String icoArrowLeft = 'assets/icons/arrow_left.svg';
  static String icoArrowRight = 'assets/icons/arrow_right.svg';
  static String icoMoney = 'assets/icons/money.svg';
  static String icoThreeDots = 'assets/icons/three_dots.svg';
  static String icoSearch = 'assets/icons/search.svg';
  static String icoTriangleDown = 'assets/icons/triangle_down.svg';
  static String icoClose = 'assets/icons/close.svg';
  static String icoSymbolUsd = 'assets/icons/symbol_usd.svg';
  static String icoCamera = 'assets/icons/camera.svg';
  static String icoInfinity = 'assets/icons/infinity.svg';

  //Assets in images
  static String logo = 'assets/images/logo.png';
}
