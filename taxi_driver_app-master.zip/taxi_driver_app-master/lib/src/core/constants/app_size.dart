import 'package:flutter/widgets.dart';

class AppSize {
  static const double formMarginBottom = 20;

  static final defaultView =
      WidgetsBinding.instance.platformDispatcher.views.first;
  static Size screenSize = defaultView.physicalSize;
  static double devicePixelRatio = defaultView.devicePixelRatio;
  static double fullWidth = screenSize.width / devicePixelRatio;
  static double fullHeight = screenSize.height / devicePixelRatio;
}
