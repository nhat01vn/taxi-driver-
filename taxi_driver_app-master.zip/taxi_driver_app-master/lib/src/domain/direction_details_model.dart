class DirectionDetailsModel {
  String? distanceTextString;
  String? durationTextString;
  int? distanceValueDigits;
  int? durationValueDigits;
  String? encodedPoints;

  DirectionDetailsModel({
    this.distanceTextString,
    this.durationTextString,
    this.distanceValueDigits,
    this.durationValueDigits,
    this.encodedPoints,
  });

  @override
  String toString() {
    return 'DirectionDetailsModel(distanceTextString: $distanceTextString, durationTextString: $durationTextString, distanceValueDigits: $distanceValueDigits, durationValueDigits: $durationValueDigits, encodedPoints: $encodedPoints)';
  }

  @override
  bool operator ==(covariant DirectionDetailsModel other) {
    if (identical(this, other)) return true;

    return other.distanceTextString == distanceTextString &&
        other.durationTextString == durationTextString &&
        other.distanceValueDigits == distanceValueDigits &&
        other.durationValueDigits == durationValueDigits &&
        other.encodedPoints == encodedPoints;
  }

  @override
  int get hashCode {
    return durationTextString.hashCode ^
        distanceTextString.hashCode ^
        distanceValueDigits.hashCode ^
        durationValueDigits.hashCode ^
        encodedPoints.hashCode;
  }
}
