import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_driver/src/core/types/request_params/auth.dart';
import 'package:flutter_driver/src/domain/user_token.dart';

abstract class AuthRepository {
  Future<UserToken> login(ILoginParams params);

  Future<UserToken> refreshToken();
}

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  throw UnimplementedError();
});
