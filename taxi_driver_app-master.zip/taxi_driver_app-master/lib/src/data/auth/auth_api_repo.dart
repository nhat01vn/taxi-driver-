import 'package:flutter_driver/src/core/types/request_params/auth.dart';
import 'package:flutter_driver/src/core/utilities/backend_api.dart';
import 'package:flutter_driver/src/data/auth/auth_repo.dart';
import 'package:flutter_driver/src/domain/user_token.dart';

class AuthApiRepository implements AuthRepository {
  @override
  Future<UserToken> login(ILoginParams params) async {
    final token = await BackendAPI.makeRequest(
      'POST',
      '/auth/login',
      data: {
        'email': params.email,
        'password': params.password,
        'role': 'driver',
      },
    );

    return UserToken.fromMap(token);
  }

  @override
  Future<UserToken> refreshToken() async {
    final token = await BackendAPI.makeRequest(
      'GET',
      '/auth',
      data: {},
    );

    return UserToken.fromMap(token);
  }
}
