import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/domain/user.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

abstract class UserRepository {
  Future<User> createUser(ICreateUserParams params);

  Future<dynamic> forgotPassword(IForgotPasswordParams params);

  Future<dynamic> resetPassword(IResetPasswordParams params);

  Future<User> fetchUser(IFetchUserParams params);

  Future<dynamic> updateUser(IUpdateUserParams params);
}

final userRepositoryProvider = Provider<UserRepository>((ref) {
  throw UnimplementedError();
});
