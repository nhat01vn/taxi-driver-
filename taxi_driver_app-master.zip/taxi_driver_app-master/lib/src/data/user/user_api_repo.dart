import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/core/utilities/backend_api.dart';
import 'package:flutter_driver/src/data/user/user_repo.dart';
import 'package:flutter_driver/src/domain/user.dart';

class UserApiRepository implements UserRepository {
  @override
  Future<User> createUser(ICreateUserParams params) async {
    final user = await BackendAPI.makeRequest(
      'POST',
      '/user/driver',
      data: {
        'name': params.name,
        'email': params.email,
        'password': params.password,
        'phone': params.phone,
        'carModel': params.carModel,
        'carNumber': params.carNumber,
        'photo': params.photo,
        'role': 'driver',
      },
    );

    return User.fromMap(user);
  }

  @override
  Future<User> fetchUser(IFetchUserParams params) async {
    final user = await BackendAPI.makeRequest(
      'GET',
      '/driver/${params.uid}',
      data: {},
    );

    return User.fromMap(user);
  }

  @override
  Future<dynamic> updateUser(
    IUpdateUserParams params,
  ) async {
    return await BackendAPI.makeRequest(
      'PATCH',
      '/driver/update',
      data: {
        'id': params.id,
        if (params.newTripStatus != null) 'newTripStatus': params.newTripStatus,
        if (params.lat != null) 'lat': params.lat,
        if (params.long != null) 'long': params.long,
        if (params.deviceToken != null) 'deviceToken': params.deviceToken,
        if (params.status != null) 'status': params.status,
        if (params.earnings != null) 'earnings': params.earnings,
      },
    );
  }

  @override
  Future<dynamic> forgotPassword(IForgotPasswordParams params) async {
    return await BackendAPI.makeRequest(
      'POST',
      '/user/forgot-password',
      data: {
        'email': params.email,
        'role': 'driver',
      },
    );
  }

  @override
  Future<dynamic> resetPassword(IResetPasswordParams params) async {
    return BackendAPI.makeRequest(
      'POST',
      '/user/reset-password',
      data: {
        'resetToken': params.resetToken,
        'role': 'driver',
        'password': params.password,
        'confirmationPassword': params.passwordConfirmation,
      },
    );
  }
}
