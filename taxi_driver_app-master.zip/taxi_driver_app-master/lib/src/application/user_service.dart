import 'package:flutter_driver/src/core/types/request_params/user.dart';
import 'package:flutter_driver/src/data/user/user_repo.dart';
import 'package:flutter_driver/src/domain/user.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class UserService {
  UserService(this.ref);

  final Ref ref;
  Future<User> createUser(ICreateUserParams params) async {
    try {
      return await ref.read(userRepositoryProvider).createUser(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<User> fetchUser(IFetchUserParams params) async {
    try {
      return await ref.read(userRepositoryProvider).fetchUser(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<dynamic> forgotPassword(IForgotPasswordParams params) async {
    try {
      return await ref.read(userRepositoryProvider).forgotPassword(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<dynamic> resetPassword(IResetPasswordParams params) async {
    try {
      return await ref.read(userRepositoryProvider).resetPassword(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<dynamic> updateUser(
    IUpdateUserParams params,
  ) async {
    try {
      return await ref.read(userRepositoryProvider).updateUser(params);
    } catch (error) {
      return Future.error(error);
    }
  }
}

final userServiceProvider = Provider<UserService>((ref) {
  return UserService(ref);
});
