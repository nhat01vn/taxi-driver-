import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first

class User {
  User({
    required this.id,
    required this.uid,
    required this.name,
    required this.phone,
    required this.email,
    required this.status,
    required this.blockStatus,
    required this.lat,
    required this.long,
    required this.carModel,
    required this.carNumber,
    required this.photo,
    required this.deviceToken,
    required this.newTripStatus,
    required this.earnings,
  });

  final int id;
  final String uid;
  final String name;
  final String phone;
  final String email;
  final bool status;
  final String blockStatus;
  final double lat;
  final double long;
  final String carModel;
  final String carNumber;
  final String photo;
  final String deviceToken;
  final String newTripStatus;
  final double earnings;

  static User createEmpty() {
    return User(
      id: 0,
      uid: '',
      name: '',
      phone: '',
      email: '',
      status: false,
      blockStatus: 'no',
      lat: 0,
      long: 0,
      carModel: '',
      carNumber: '',
      photo: '',
      deviceToken: '',
      newTripStatus: '',
      earnings: 0,
    );
  }

  static List<User> fromListMap(List users) {
    if (users.isEmpty) return List<User>.from([]);
    return List<User>.from(
      users.map((user) => User.fromMap(Map<String, dynamic>.from(user!))),
    );
  }

  User copyWith({
    int? id,
    String? uid,
    String? name,
    String? phone,
    String? email,
    bool? status,
    String? blockStatus,
    double? lat,
    double? long,
    String? carModel,
    String? carNumber,
    String? photo,
    String? deviceToken,
    String? newTripStatus,
    double? earnings,
  }) {
    return User(
      id: id ?? this.id,
      uid: uid ?? this.uid,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      status: status ?? this.status,
      lat: lat ?? this.lat,
      long: long ?? this.long,
      blockStatus: blockStatus ?? this.blockStatus,
      carModel: carModel ?? this.carModel,
      carNumber: carNumber ?? this.carNumber,
      photo: photo ?? this.photo,
      deviceToken: deviceToken ?? this.deviceToken,
      newTripStatus: newTripStatus ?? this.newTripStatus,
      earnings: earnings ?? this.earnings,
    );
  }

  @override
  String toString() {
    return 'User(id: $id, uid: $uid, name: $name, phone: $phone, email: $email, status: $status, blockStatus: $blockStatus, lat: $lat, long: $long, carModel: $carModel, carNumber: $carNumber, photo: $photo, deviceToken: $deviceToken, newTripStatus: $newTripStatus, earnings: $earnings)';
  }

  @override
  bool operator ==(covariant User other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.uid == uid &&
        other.name == name &&
        other.phone == phone &&
        other.email == email &&
        other.status == status &&
        other.lat == lat &&
        other.long == long &&
        other.carModel == carModel &&
        other.carNumber == carNumber &&
        other.photo == photo &&
        other.deviceToken == deviceToken &&
        other.newTripStatus == newTripStatus &&
        other.earnings == earnings &&
        other.blockStatus == blockStatus;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        uid.hashCode ^
        name.hashCode ^
        phone.hashCode ^
        email.hashCode ^
        status.hashCode ^
        lat.hashCode ^
        long.hashCode ^
        photo.hashCode ^
        newTripStatus.hashCode ^
        deviceToken.hashCode ^
        earnings.hashCode ^
        blockStatus.hashCode;
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'uid': uid,
      'name': name,
      'phone': phone,
      'email': email,
      'status': status,
      'blockStatus': blockStatus,
      'lat': lat,
      'long': long,
      'photo': photo,
      'carModel': carModel,
      'carNumber': carNumber,
      'deviceToken': deviceToken,
      'newTripStatus': newTripStatus,
      'earnings': earnings,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'] as int,
      uid: map['uid'] as String,
      name: map['name'] as String,
      phone: map['phone'] as String,
      email: map['email'] as String,
      status: map['status'] != null ? map['status'] as bool : false,
      blockStatus: map['blockStatus'] as String,
      lat: map['lat'] != null
          ? ((map['lat'] is double)
              ? map['lat']
              : (map['lat'] as int).toDouble())
          : 0.0,
      long: map['long'] != null
          ? ((map['long'] is double)
              ? map['long']
              : (map['long'] as int).toDouble())
          : 0.0,
      photo: map['photo'] != null ? map['photo'] as String : '',
      carNumber: map['carNumber'] != null ? map['carNumber'] as String : '',
      carModel: map['carModel'] != null ? map['carModel'] as String : '',
      earnings: map['earnings'] != null
          ? ((map['earnings'] is double)
              ? map['earnings']
              : (map['earnings'] as int).toDouble())
          : 0.0,
      newTripStatus:
          map['newTripStatus'] != null ? map['newTripStatus'] as String : '',
      deviceToken:
          map['deviceToken'] != null ? map['deviceToken'] as String : '',
    );
  }

  String toJson() => json.encode(toMap());

  factory User.fromJson(String source) =>
      User.fromMap(json.decode(source) as Map<String, dynamic>);
}
