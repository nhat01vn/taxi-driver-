// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class UserToken {
  UserToken({
    required this.id,
    required this.uid,
    required this.role,
    required this.token,
    required this.isAdmin,
  });

  final int id;
  final String uid;
  final String role;
  final String token;
  final bool isAdmin;

  static UserToken createEmpty() {
    return UserToken(
      role: 'client',
      token: '',
      uid: '',
      id: 0,
      isAdmin: false,
    );
  }

  UserToken copyWith({
    String? role,
    String? token,
    String? uid,
    int? id,
    bool? isAdmin,
  }) {
    return UserToken(
      role: role ?? this.role,
      token: token ?? this.token,
      uid: uid ?? this.uid,
      id: id ?? this.id,
      isAdmin: isAdmin ?? this.isAdmin,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'role': role,
      'token': token,
      'uid': uid,
      'id': id,
      'isAdmin': isAdmin,
    };
  }

  factory UserToken.fromMap(Map<String, dynamic> map) {
    return UserToken(
      role: map['role'] != null ? map['role'] as String : '',
      token: map['token'] != null ? map['token'] as String : '',
      uid: map['uid'] != null ? map['uid'] as String : '',
      id: map['id'] != null ? map['id'] as int : 0,
      isAdmin: map['isAdmin'] != null ? map['isAdmin'] as bool : false,
    );
  }

  String toJson() => json.encode(toMap());

  factory UserToken.fromJson(String source) =>
      UserToken.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() =>
      'UserToken(role: $role, token: $token, id: $id, uid: $uid, isAdmin: $isAdmin)';

  @override
  bool operator ==(covariant UserToken other) {
    if (identical(this, other)) return true;

    return other.role == role &&
        other.uid == uid &&
        other.isAdmin == isAdmin &&
        other.token == token &&
        other.id == id;
  }

  @override
  int get hashCode =>
      role.hashCode ^
      uid.hashCode ^
      token.hashCode ^
      id.hashCode ^
      isAdmin.hashCode;
}
