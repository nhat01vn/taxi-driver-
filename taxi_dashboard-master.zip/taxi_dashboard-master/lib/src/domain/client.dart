import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first

class Client {
  Client({
    required this.id,
    required this.uid,
    required this.name,
    required this.phone,
    required this.email,
    required this.blockStatus,
  });

  final int id;
  final String uid;
  final String name;
  final String phone;
  final String email;
  final String blockStatus;

  static Client createEmpty() {
    return Client(
      id: 0,
      uid: '',
      name: '',
      email: '',
      blockStatus: 'no',
      phone: '',
    );
  }

  static List<Client> fromListMap(List clients) {
    if (clients.isEmpty) return List<Client>.from([]);

    return List<Client>.from(
      clients
          .map((client) => Client.fromMap(Map<String, dynamic>.from(client!))),
    );
  }

  Client copyWith({
    int? id,
    String? uid,
    String? name,
    String? phone,
    String? email,
    String? blockStatus,
  }) {
    return Client(
      id: id ?? this.id,
      uid: uid ?? this.uid,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      blockStatus: blockStatus ?? this.blockStatus,
    );
  }

  @override
  String toString() {
    return 'Client(id: $id, uid: $uid, name: $name, phone: $phone, email: $email, blockStatus: $blockStatus)';
  }

  @override
  bool operator ==(covariant Client other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.uid == uid &&
        other.name == name &&
        other.phone == phone &&
        other.email == email &&
        other.blockStatus == blockStatus;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        uid.hashCode ^
        name.hashCode ^
        phone.hashCode ^
        email.hashCode ^
        blockStatus.hashCode;
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'uid': uid,
      'name': name,
      'phone': phone,
      'email': email,
      'blockStatus': blockStatus,
    };
  }

  factory Client.fromMap(Map<String, dynamic> map) {
    return Client(
      id: map['id'] as int,
      uid: map['uid'] != null ? map['uid'] as String : '',
      name: map['name'] != null ? map['name'] as String : '',
      phone: map['phone'] != null ? map['phone'] as String : '',
      email: map['email'] != null ? map['email'] as String : '',
      blockStatus:
          map['blockStatus'] != null ? map['blockStatus'] as String : '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Client.fromJson(String source) =>
      Client.fromMap(json.decode(source) as Map<String, dynamic>);
}
