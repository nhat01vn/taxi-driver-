import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:futter_user/src/application/auth_service.dart';
import 'package:futter_user/src/core/constants/app_asset.dart';
import 'package:futter_user/src/core/constants/app_color.dart';
import 'package:futter_user/src/core/constants/app_size.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/helpers/image_helper.dart';
import 'package:futter_user/src/core/types/request_params/auth.dart';
import 'package:futter_user/src/presentation/widgets/common/loading_dialog.dart';
import 'package:futter_user/src/presentation/widgets/common/rounded_button.dart';
import 'package:futter_user/src/presentation/widgets/form/form_text_field.dart';
import 'package:futter_user/src/presentation/widgets/layouts/app_container/app_container.dart';
import 'package:go_router/go_router.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final GlobalKey<FormBuilderState> _form = GlobalKey<FormBuilderState>();
  bool _isPasswordVisible = false;
  CommonHelper cCommonHelperMethods = CommonHelper();

  void submitForm() async {
    try {
      cCommonHelperMethods.checkConnectivity(context);
      if (_form.currentState!.saveAndValidate()) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) =>
              const LoadingDialog(messageText: 'Allowing you to Login...'),
        );
        var value = _form.currentState!.value;
        final userToken = await ref.read(authServiceProvider).login(
              ILoginParams(
                email: value['email'],
                password: value['password'],
              ),
            );
        if (!context.mounted) return;
        Navigator.pop(context);
        if (userToken.isAdmin) {
          context.goNamed('SideNavigationDrawer');
        } else {
          cCommonHelperMethods.displaySnackBar(
            'you are not admin. Contact admin: qthanh18tn@gmail.com',
            context,
          );
        }
      }
    } catch (err) {
      if (mounted) {
        Navigator.pop(context);
        cCommonHelperMethods.displaySnackBar(
          (err as Map)['error'].toString(),
          context,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppContainer(
      safeAreaColor: AppColor.white,
      child: Container(
        color: AppColor.white,
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 140,
              height: 140,
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            Text(
              'Login',
              textAlign: TextAlign.center,
              style: TextStyles.defaultAppBarTitle.primaryColor,
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            FormBuilder(
              key: _form,
              child: Column(
                children: [
                  SizedBox(
                    width: 500,
                    child: FormTextField(
                      name: 'email',
                      placeholder: 'login.emailPlaceholder'.tr(),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: 'form.validation.empty'.tr(
                            namedArgs: {
                              'fieldName': 'login.validationForEmail'.tr(),
                            },
                          ),
                        ),
                        FormBuilderValidators.email(
                          errorText: 'form.validation.email'.tr(),
                        ),
                      ]),
                    ),
                  ),
                  const SizedBox(height: AppSize.formMarginBottom),
                  SizedBox(
                    width: 500,
                    child: FormTextField(
                      name: 'password',
                      obscureText: !_isPasswordVisible,
                      suffixIcon: Align(
                        widthFactor: 1.0,
                        heightFactor: 1.0,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isPasswordVisible = !_isPasswordVisible;
                            });
                          },
                          child: ImageHelper.loadFromAsset(
                            AppAsset.icoHintPassword,
                            tintColor: AppColor.defaultText,
                            height: 25,
                          ),
                        ),
                      ),
                      placeholder: 'login.passwordPlaceholder'.tr(),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: 'form.validation.empty'.tr(
                            namedArgs: {
                              'fieldName': 'login.validationForPassword'.tr(),
                            },
                          ),
                        ),
                        FormBuilderValidators.minLength(
                          4,
                          errorText: 'form.validation.min'.tr(
                            namedArgs: {
                              'fieldName': 'login.validationForPassword'.tr(),
                              'length': '4',
                            },
                          ),
                        ),
                        FormBuilderValidators.maxLength(
                          20,
                          errorText: 'form.validation.max'.tr(
                            namedArgs: {
                              'fieldName': 'login.validationForPassword'.tr(),
                              'length': '20',
                            },
                          ),
                        ),
                      ]),
                    ),
                  ),
                  SizedBox(
                    height: AppSize.formMarginBottom,
                    width: AppSize.fullWidth,
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSize.formMarginBottom),
            SizedBox(
              width: 500,
              child: RoundedButton(
                padding: const EdgeInsets.all(25),
                buttonText: 'login.buttonSubmit'.tr(),
                borderSize: const BorderSide(color: AppColor.success),
                onPressed: submitForm,
              ),
            ),
            const SizedBox(height: AppSize.formMarginBottom),
          ],
        ),
      ),
    );
  }
}
