import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:futter_user/src/domain/user.dart';

class DriversDataList extends ConsumerStatefulWidget {
  const DriversDataList({super.key});

  @override
  ConsumerState<DriversDataList> createState() => _DriversDataListState();
}

class _DriversDataListState extends ConsumerState<DriversDataList> {
  List<User>? driversRecordsFromDatabase;
  bool isLoading = true;
  @override
  void initState() {
    fetchAllDriver();
    super.initState();
  }

  fetchAllDriver() async {
    final allDriver = await ref.read(userServiceProvider).fetchAllUser();
    setState(() {
      isLoading = false;
      driversRecordsFromDatabase = allDriver;
    });
  }

  CommonHelper cMethods = CommonHelper();

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : ListView.builder(
            shrinkWrap: true,
            itemCount: driversRecordsFromDatabase?.length,
            itemBuilder: ((context, index) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  cMethods.data(
                    2,
                    Text(driversRecordsFromDatabase![index].uid.toString()),
                  ),
                  cMethods.data(
                    1,
                    driversRecordsFromDatabase![index].photo.isNotEmpty
                        ? Image.network(
                            driversRecordsFromDatabase![index].photo.toString(),
                            width: 50,
                            height: 50,
                          )
                        : Container(
                            width: 20,
                            height: 20,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey,
                            ),
                          ),
                  ),
                  cMethods.data(
                    1,
                    Text(driversRecordsFromDatabase![index].name.toString()),
                  ),
                  cMethods.data(
                    1,
                    Text(
                      '${driversRecordsFromDatabase![index].carModel} - ${driversRecordsFromDatabase![index].carNumber}',
                    ),
                  ),
                  cMethods.data(
                    1,
                    Text(driversRecordsFromDatabase![index].phone.toString()),
                  ),
                  cMethods.data(
                    1,
                    driversRecordsFromDatabase![index].earnings != null
                        ? Text(
                            '\$ ${driversRecordsFromDatabase![index].earnings}',
                          )
                        : const Text('\$ 0'),
                  ),
                  cMethods.data(
                    1,
                    driversRecordsFromDatabase![index].blockStatus == 'no'
                        ? ElevatedButton(
                            onPressed: () async {
                              await ref.read(userRepositoryProvider).updateUser(
                                    IUpdateUserParams(
                                      id: driversRecordsFromDatabase![index]
                                          .id
                                          .toString(),
                                      blockStatus: 'yes',
                                    ),
                                  );
                              fetchAllDriver();
                            },
                            child: const Text(
                              'Block',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                        : ElevatedButton(
                            onPressed: () async {
                              await ref.read(userRepositoryProvider).updateUser(
                                    IUpdateUserParams(
                                      id: driversRecordsFromDatabase![index]
                                          .id
                                          .toString(),
                                      blockStatus: 'no',
                                    ),
                                  );
                              fetchAllDriver();
                            },
                            child: const Text(
                              'Approve',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                  ),
                ],
              );
            }),
          );
  }
}
