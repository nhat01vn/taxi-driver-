import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/application/user_service.dart';
import 'package:futter_user/src/core/helpers/comon_helper.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:futter_user/src/domain/client.dart';

class UsersDataList extends ConsumerStatefulWidget {
  const UsersDataList({super.key});

  @override
  ConsumerState<UsersDataList> createState() => _UsersDataListState();
}

class _UsersDataListState extends ConsumerState<UsersDataList> {
  List<Client>? usersRecordsFromDatabase;
  bool isLoading = true;
  @override
  void initState() {
    fetchAllUser();
    super.initState();
  }

  fetchAllUser() async {
    final allUser = await ref.read(userServiceProvider).fetchAllClient();
    setState(() {
      isLoading = false;
      usersRecordsFromDatabase = allUser;
    });
  }

  CommonHelper cMethods = CommonHelper();

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator())
        : ListView.builder(
            shrinkWrap: true,
            itemCount: usersRecordsFromDatabase?.length,
            itemBuilder: ((context, index) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  cMethods.data(
                    2,
                    Text(usersRecordsFromDatabase![index].uid.toString()),
                  ),
                  cMethods.data(
                    1,
                    Text(usersRecordsFromDatabase![index].name.toString()),
                  ),
                  cMethods.data(
                    1,
                    Text(usersRecordsFromDatabase![index].email.toString()),
                  ),
                  cMethods.data(
                    1,
                    Text(usersRecordsFromDatabase![index].phone.toString()),
                  ),
                  cMethods.data(
                    1,
                    usersRecordsFromDatabase![index].blockStatus == 'no'
                        ? ElevatedButton(
                            onPressed: () async {
                              await ref
                                  .read(userRepositoryProvider)
                                  .updateClient(
                                    IUpdateUserParams(
                                      id: usersRecordsFromDatabase![index]
                                          .id
                                          .toString(),
                                      blockStatus: 'yes',
                                    ),
                                  );
                              fetchAllUser();
                            },
                            child: const Text(
                              'Block',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                        : ElevatedButton(
                            onPressed: () async {
                              await ref
                                  .read(userRepositoryProvider)
                                  .updateClient(
                                    IUpdateUserParams(
                                      id: usersRecordsFromDatabase![index]
                                          .id
                                          .toString(),
                                      blockStatus: 'no',
                                    ),
                                  );
                              fetchAllUser();
                            },
                            child: const Text(
                              'Approve',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                  ),
                ],
              );
            }),
          );
  }
}
