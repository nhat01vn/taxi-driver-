import 'package:flutter_riverpod/flutter_riverpod.dart';

class ErrorController extends StateNotifier<dynamic> {
  ErrorController() : super({});

  void setError(dynamic newError) {
    state = newError;
  }
}

final errorControllerProvider =
    StateNotifierProvider<ErrorController, dynamic>((ref) {
  return ErrorController();
});
