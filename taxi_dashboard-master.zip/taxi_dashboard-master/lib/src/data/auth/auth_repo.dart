import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/types/request_params/auth.dart';
import 'package:futter_user/src/domain/user_token.dart';

abstract class AuthRepository {
  Future<UserToken> login(ILoginParams params);

  Future<UserToken> refreshToken();
}

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  throw UnimplementedError();
});
