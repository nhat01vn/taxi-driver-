import 'package:futter_user/src/core/types/request_params/auth.dart';
import 'package:futter_user/src/core/utilities/backend_api.dart';
import 'package:futter_user/src/data/auth/auth_repo.dart';
import 'package:futter_user/src/domain/user_token.dart';

class AuthApiRepository implements AuthRepository {
  @override
  Future<UserToken> login(ILoginParams params) async {
    final token = await BackendAPI.makeRequest(
      'POST',
      '/auth/login',
      data: {
        'email': params.email,
        'password': params.password,
        'role': 'employee',
      },
    );

    return UserToken.fromMap(token);
  }

  @override
  Future<UserToken> refreshToken() async {
    final token = await BackendAPI.makeRequest(
      'GET',
      '/auth',
      data: {},
    );

    return UserToken.fromMap(token);
  }
}
