import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/core/utilities/backend_api.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:futter_user/src/domain/client.dart';
import 'package:futter_user/src/domain/user.dart';

class UserApiRepository implements UserRepository {
  @override
  Future<User> fetchUser(IFetchUserParams params) async {
    final user = await BackendAPI.makeRequest(
      'GET',
      '/driver/${params.uid}',
      data: {},
    );

    return User.fromMap(user);
  }

  @override
  Future<dynamic> updateUser(
    IUpdateUserParams params,
  ) async {
    return await BackendAPI.makeRequest(
      'PATCH',
      '/driver/update',
      data: {
        'id': params.id,
        if (params.newTripStatus != null) 'newTripStatus': params.newTripStatus,
        if (params.lat != null) 'lat': params.lat,
        if (params.long != null) 'long': params.long,
        if (params.deviceToken != null) 'deviceToken': params.deviceToken,
        if (params.status != null) 'status': params.status,
        if (params.earnings != null) 'earnings': params.earnings,
        if (params.blockStatus != null) 'blockStatus': params.blockStatus,
      },
    );
  }

  @override
  Future<dynamic> updateClient(
    IUpdateUserParams params,
  ) async {
    return await BackendAPI.makeRequest(
      'PATCH',
      '/client/update',
      data: {
        'id': params.id,
        if (params.blockStatus != null) 'blockStatus': params.blockStatus,
      },
    );
  }

  @override
  Future<List<User>> fetchAllUser() async {
    final users = await BackendAPI.makeRequest(
      'GET',
      '/driver',
      data: {},
    );
    return User.fromListMap(users);
  }

  @override
  Future<List<Client>> fetchAllClient() async {
    final users = await BackendAPI.makeRequest(
      'GET',
      '/client',
      data: {},
    );
    return Client.fromListMap(users);
  }
}
