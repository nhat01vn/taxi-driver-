import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/domain/client.dart';
import 'package:futter_user/src/domain/user.dart';

abstract class UserRepository {
  Future<User> fetchUser(IFetchUserParams params);
  Future<List<User>> fetchAllUser();
  Future<List<Client>> fetchAllClient();
  Future<dynamic> updateUser(IUpdateUserParams params);
  Future<dynamic> updateClient(IUpdateUserParams params);
}

final userRepositoryProvider = Provider<UserRepository>((ref) {
  throw UnimplementedError();
});
