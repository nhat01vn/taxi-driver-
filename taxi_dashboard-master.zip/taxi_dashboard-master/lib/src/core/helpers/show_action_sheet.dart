import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:futter_user/src/core/extensions/textstyle_ext.dart';

class ShowActionSheetHelper {
  static void showActionSheet({
    required Widget title,
    required Widget content,
    required BuildContext context,
  }) {
    showCupertinoModalPopup<void>(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: title,
        content: content,
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'popupActionSheet.buttonOkPopup'.tr(),
              style: TextStyles.defaultStyle.secondaryColor,
            ),
          ),
        ],
      ),
    );
  }
}
