class AppCurrency {
  static List<String> currencies = ['USD', 'VND', 'JPY'];
}
