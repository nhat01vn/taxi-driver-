import 'package:flutter/material.dart';

class AppConfigLocalization {
  static Map<String, Map<String, String>> localizations = {
    'en': {'languageName': 'English', 'currency': 'USD', 'localeCode': 'en'},
    'vi': {'languageName': 'Tiếng Việt', 'currency': 'VND', 'localeCode': 'vi'},
    'ja': {'languageName': '日本語', 'currency': 'JPY', 'localeCode': 'ja'},
  };

  static final supportedLocales = [
    const Locale('en'),
    const Locale('ja'),
    const Locale('vi'),
  ];
}
