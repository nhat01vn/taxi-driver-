import 'package:flutter/foundation.dart';
import 'package:futter_user/src/domain/user_token.dart';
import 'package:hive/hive.dart';

class LocalStorage {
  final box = Hive.openBox<Map>('applicationStorage');

  //  STORE LOCAL DATA
  storeSettings(String settingName, dynamic settingValue) async {
    final Map<String, dynamic> data = {
      ...await _getItem('settings'),
      ...{
        settingName: settingValue,
      },
    };

    return _setItem('settings', data);
  }

  storeUserToken(UserToken userToken) async {
    return _setItem('userToken', userToken.toMap());
  }

  // LOAD FROM LOCAL DATA
  loadSettings(
    String settingName, {
    defaultValue,
  }) async {
    return (await _getItem('settings'))[settingName] ?? defaultValue;
  }

  Future<UserToken> loadUserToken() async {
    final userToken = await _getItem('userToken');
    if (mapEquals(userToken, {})) return UserToken.createEmpty();

    return UserToken.fromMap(userToken);
  }

  //  CLEAR LOCAL DATA
  clearSettings() async {
    return _removeItem('settings');
  }

  clearUserToken() async {
    return _removeItem('userToken');
  }

  _getItem(String key) async {
    final result = (await box).get(key);
    if (!mapEquals(result, {}) && result != null) {
      return Map<String, dynamic>.from(result);
    }
    return {};
  }

  _setItem(String key, Map<String, dynamic> data) async {
    (await box).put(key, data);

    return _getItem(key);
  }

  _removeItem(String key) async {
    return (await box).delete(key);
  }
}

final localStorage = LocalStorage();
