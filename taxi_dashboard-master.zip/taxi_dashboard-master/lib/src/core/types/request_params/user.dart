import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.freezed.dart';

@freezed
class IFetchUserParams with _$IFetchUserParams {
  factory IFetchUserParams({
    required String uid,
  }) = _IFetchUserParams;
}

@freezed
class IUpdateUserParams with _$IUpdateUserParams {
  factory IUpdateUserParams({
    required String id,
    String? newTripStatus,
    double? lat,
    double? long,
    double? earnings,
    String? deviceToken,
    String? status,
    String? blockStatus,
  }) = _IUpdateUserParams;
}
