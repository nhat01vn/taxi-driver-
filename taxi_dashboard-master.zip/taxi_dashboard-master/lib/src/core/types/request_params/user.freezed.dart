// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$IFetchUserParams {
  String get uid => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IFetchUserParamsCopyWith<IFetchUserParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IFetchUserParamsCopyWith<$Res> {
  factory $IFetchUserParamsCopyWith(
          IFetchUserParams value, $Res Function(IFetchUserParams) then) =
      _$IFetchUserParamsCopyWithImpl<$Res, IFetchUserParams>;
  @useResult
  $Res call({String uid});
}

/// @nodoc
class _$IFetchUserParamsCopyWithImpl<$Res, $Val extends IFetchUserParams>
    implements $IFetchUserParamsCopyWith<$Res> {
  _$IFetchUserParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? uid = null,
  }) {
    return _then(_value.copyWith(
      uid: null == uid
          ? _value.uid
          : uid // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IFetchUserParamsImplCopyWith<$Res>
    implements $IFetchUserParamsCopyWith<$Res> {
  factory _$$IFetchUserParamsImplCopyWith(_$IFetchUserParamsImpl value,
          $Res Function(_$IFetchUserParamsImpl) then) =
      __$$IFetchUserParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String uid});
}

/// @nodoc
class __$$IFetchUserParamsImplCopyWithImpl<$Res>
    extends _$IFetchUserParamsCopyWithImpl<$Res, _$IFetchUserParamsImpl>
    implements _$$IFetchUserParamsImplCopyWith<$Res> {
  __$$IFetchUserParamsImplCopyWithImpl(_$IFetchUserParamsImpl _value,
      $Res Function(_$IFetchUserParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? uid = null,
  }) {
    return _then(_$IFetchUserParamsImpl(
      uid: null == uid
          ? _value.uid
          : uid // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$IFetchUserParamsImpl implements _IFetchUserParams {
  _$IFetchUserParamsImpl({required this.uid});

  @override
  final String uid;

  @override
  String toString() {
    return 'IFetchUserParams(uid: $uid)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IFetchUserParamsImpl &&
            (identical(other.uid, uid) || other.uid == uid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, uid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IFetchUserParamsImplCopyWith<_$IFetchUserParamsImpl> get copyWith =>
      __$$IFetchUserParamsImplCopyWithImpl<_$IFetchUserParamsImpl>(
          this, _$identity);
}

abstract class _IFetchUserParams implements IFetchUserParams {
  factory _IFetchUserParams({required final String uid}) =
      _$IFetchUserParamsImpl;

  @override
  String get uid;
  @override
  @JsonKey(ignore: true)
  _$$IFetchUserParamsImplCopyWith<_$IFetchUserParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IUpdateUserParams {
  String get id => throw _privateConstructorUsedError;
  String? get newTripStatus => throw _privateConstructorUsedError;
  double? get lat => throw _privateConstructorUsedError;
  double? get long => throw _privateConstructorUsedError;
  double? get earnings => throw _privateConstructorUsedError;
  String? get deviceToken => throw _privateConstructorUsedError;
  String? get status => throw _privateConstructorUsedError;
  String? get blockStatus => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $IUpdateUserParamsCopyWith<IUpdateUserParams> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IUpdateUserParamsCopyWith<$Res> {
  factory $IUpdateUserParamsCopyWith(
          IUpdateUserParams value, $Res Function(IUpdateUserParams) then) =
      _$IUpdateUserParamsCopyWithImpl<$Res, IUpdateUserParams>;
  @useResult
  $Res call(
      {String id,
      String? newTripStatus,
      double? lat,
      double? long,
      double? earnings,
      String? deviceToken,
      String? status,
      String? blockStatus});
}

/// @nodoc
class _$IUpdateUserParamsCopyWithImpl<$Res, $Val extends IUpdateUserParams>
    implements $IUpdateUserParamsCopyWith<$Res> {
  _$IUpdateUserParamsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? newTripStatus = freezed,
    Object? lat = freezed,
    Object? long = freezed,
    Object? earnings = freezed,
    Object? deviceToken = freezed,
    Object? status = freezed,
    Object? blockStatus = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      newTripStatus: freezed == newTripStatus
          ? _value.newTripStatus
          : newTripStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double?,
      long: freezed == long
          ? _value.long
          : long // ignore: cast_nullable_to_non_nullable
              as double?,
      earnings: freezed == earnings
          ? _value.earnings
          : earnings // ignore: cast_nullable_to_non_nullable
              as double?,
      deviceToken: freezed == deviceToken
          ? _value.deviceToken
          : deviceToken // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      blockStatus: freezed == blockStatus
          ? _value.blockStatus
          : blockStatus // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IUpdateUserParamsImplCopyWith<$Res>
    implements $IUpdateUserParamsCopyWith<$Res> {
  factory _$$IUpdateUserParamsImplCopyWith(_$IUpdateUserParamsImpl value,
          $Res Function(_$IUpdateUserParamsImpl) then) =
      __$$IUpdateUserParamsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String? newTripStatus,
      double? lat,
      double? long,
      double? earnings,
      String? deviceToken,
      String? status,
      String? blockStatus});
}

/// @nodoc
class __$$IUpdateUserParamsImplCopyWithImpl<$Res>
    extends _$IUpdateUserParamsCopyWithImpl<$Res, _$IUpdateUserParamsImpl>
    implements _$$IUpdateUserParamsImplCopyWith<$Res> {
  __$$IUpdateUserParamsImplCopyWithImpl(_$IUpdateUserParamsImpl _value,
      $Res Function(_$IUpdateUserParamsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? newTripStatus = freezed,
    Object? lat = freezed,
    Object? long = freezed,
    Object? earnings = freezed,
    Object? deviceToken = freezed,
    Object? status = freezed,
    Object? blockStatus = freezed,
  }) {
    return _then(_$IUpdateUserParamsImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      newTripStatus: freezed == newTripStatus
          ? _value.newTripStatus
          : newTripStatus // ignore: cast_nullable_to_non_nullable
              as String?,
      lat: freezed == lat
          ? _value.lat
          : lat // ignore: cast_nullable_to_non_nullable
              as double?,
      long: freezed == long
          ? _value.long
          : long // ignore: cast_nullable_to_non_nullable
              as double?,
      earnings: freezed == earnings
          ? _value.earnings
          : earnings // ignore: cast_nullable_to_non_nullable
              as double?,
      deviceToken: freezed == deviceToken
          ? _value.deviceToken
          : deviceToken // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      blockStatus: freezed == blockStatus
          ? _value.blockStatus
          : blockStatus // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$IUpdateUserParamsImpl implements _IUpdateUserParams {
  _$IUpdateUserParamsImpl(
      {required this.id,
      this.newTripStatus,
      this.lat,
      this.long,
      this.earnings,
      this.deviceToken,
      this.status,
      this.blockStatus});

  @override
  final String id;
  @override
  final String? newTripStatus;
  @override
  final double? lat;
  @override
  final double? long;
  @override
  final double? earnings;
  @override
  final String? deviceToken;
  @override
  final String? status;
  @override
  final String? blockStatus;

  @override
  String toString() {
    return 'IUpdateUserParams(id: $id, newTripStatus: $newTripStatus, lat: $lat, long: $long, earnings: $earnings, deviceToken: $deviceToken, status: $status, blockStatus: $blockStatus)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IUpdateUserParamsImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.newTripStatus, newTripStatus) ||
                other.newTripStatus == newTripStatus) &&
            (identical(other.lat, lat) || other.lat == lat) &&
            (identical(other.long, long) || other.long == long) &&
            (identical(other.earnings, earnings) ||
                other.earnings == earnings) &&
            (identical(other.deviceToken, deviceToken) ||
                other.deviceToken == deviceToken) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.blockStatus, blockStatus) ||
                other.blockStatus == blockStatus));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, newTripStatus, lat, long,
      earnings, deviceToken, status, blockStatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$IUpdateUserParamsImplCopyWith<_$IUpdateUserParamsImpl> get copyWith =>
      __$$IUpdateUserParamsImplCopyWithImpl<_$IUpdateUserParamsImpl>(
          this, _$identity);
}

abstract class _IUpdateUserParams implements IUpdateUserParams {
  factory _IUpdateUserParams(
      {required final String id,
      final String? newTripStatus,
      final double? lat,
      final double? long,
      final double? earnings,
      final String? deviceToken,
      final String? status,
      final String? blockStatus}) = _$IUpdateUserParamsImpl;

  @override
  String get id;
  @override
  String? get newTripStatus;
  @override
  double? get lat;
  @override
  double? get long;
  @override
  double? get earnings;
  @override
  String? get deviceToken;
  @override
  String? get status;
  @override
  String? get blockStatus;
  @override
  @JsonKey(ignore: true)
  _$$IUpdateUserParamsImplCopyWith<_$IUpdateUserParamsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
