import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:futter_user/src/core/types/request_params/user.dart';
import 'package:futter_user/src/data/user/user_repo.dart';
import 'package:futter_user/src/domain/client.dart';
import 'package:futter_user/src/domain/user.dart';

class UserService {
  UserService(this.ref);

  final Ref ref;
  Future<User> fetchUser(IFetchUserParams params) async {
    try {
      return await ref.read(userRepositoryProvider).fetchUser(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<List<User>> fetchAllUser() async {
    try {
      return await ref.read(userRepositoryProvider).fetchAllUser();
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<List<Client>> fetchAllClient() async {
    try {
      return await ref.read(userRepositoryProvider).fetchAllClient();
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<dynamic> updateUser(
    IUpdateUserParams params,
  ) async {
    try {
      return await ref.read(userRepositoryProvider).updateUser(params);
    } catch (error) {
      return Future.error(error);
    }
  }

  Future<dynamic> updateClient(
    IUpdateUserParams params,
  ) async {
    try {
      return await ref.read(userRepositoryProvider).updateClient(params);
    } catch (error) {
      return Future.error(error);
    }
  }
}

final userServiceProvider = Provider<UserService>((ref) {
  return UserService(ref);
});
