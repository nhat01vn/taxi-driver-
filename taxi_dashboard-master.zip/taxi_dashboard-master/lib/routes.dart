import 'package:flutter/cupertino.dart';
import 'package:futter_user/src/presentation/screens/dashboard/side_navigation_drawer.dart';
import 'package:futter_user/src/presentation/screens/login/login_screen.dart';
import 'package:go_router/go_router.dart';

class Routes {
  static final router = GoRouter(
    initialLocation: '/login',
    routes: <GoRoute>[
      GoRoute(
        name: 'LoginScreen',
        path: '/login',
        builder: (BuildContext context, GoRouterState state) {
          return const LoginScreen();
        },
      ),
      GoRoute(
        name: 'SideNavigationDrawer',
        path: '/home',
        builder: (BuildContext context, GoRouterState state) {
          return const SideNavigationDrawer();
        },
      ),
    ],
  );
}
